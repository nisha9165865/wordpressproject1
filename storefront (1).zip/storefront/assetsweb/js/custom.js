

//=============Header Fixed Start=============//

$(window).scroll(function(){
  var sticky = $('.main_header'),
      scroll = $(window).scrollTop();

  if (scroll >= 100) sticky.addClass('sticky');
  else sticky.removeClass('sticky');
});


//=============Header Fixed End=============//

/*=========stellarnav Main Nav Bar===========*/

  jQuery(document).ready(function ($) {
            jQuery('.stellarnav').stellarNav({
                theme: 'dark',
                breakpoint: 1080,
                position: 'right',
                phoneBtn: '9711260230'
            });
        });



//=============Main Slider Start=============//

$(document).ready(function() {
  $('.main_slider').owlCarousel({
    loop: true,
    autoplay: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    margin: 0,
    dots:false,
    animateOut: 'fadeOut',
    mouseDrag :false,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 1,
        nav: true
      },
      1000: {
        items: 1,
        nav: true,
        loop: true,
        margin: 0
      }
    }
  })
})

//=============Main Slider End=============//

//=============Catering Slider Start=============//
 $(document).ready(function() {
              $('.product_slider').owlCarousel({
                loop: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                margin: 10,
                responsiveClass: true,
                responsive: {
                  0: {
                    items: 1,
                    nav: false
                  },
                  600: {
                    items: 2,
                    nav: true,
                    margin:20
                  },
                  768: {
                    items: 2,
                    nav: true,
                    margin:20
                  },
                  1000: {
                    items: 3,
                    nav: true,
                    margin: 20
                  },
                  1200: {
                    items: 4,
                    nav: true,
                    margin: 10
                  }
                }
              })
            })
//=============Catering Slider End=============//	
		
//=============Testim Slider Start=============//
			
			$(document).ready(function() {
              $('.testim_slide').owlCarousel({
                loop: true,
                autoplay: true,
                autoplayTimeout: 3000,
                autoplayHoverPause: true,
                margin: 20,
                responsiveClass: true,
                responsive: {
                  0: {
                    items: 1,
                    nav: false
                  },
                  600: {
                    items: 1,
                    nav: false
                  },
                  1000: {
                    items: 2,
                    nav: false,
                    loop: false,
                    margin: 10
                  },
                  1200: {
                    items: 2,
                    nav: false,
                    loop: false,
                    margin: 10
                  }
                }
              })
            })
			
//=============Testim Slider End=============//	
//=======Cart Popup Open ==========//

jQuery( "body" ).delegate( "#shopping-cart", "click", function(e){

     e.preventDefault();

// $( "#shopping-cart" ).click(function() {

    $( "#cart-floating-box" ).addClass( "open");

  });



jQuery( "body" ).delegate( "#cart-close", "click", function(e){

     e.preventDefault();

//   $( "#cart-close" ).click(function() {

     

    $( "#cart-floating-box" ).removeClass( "open");

  });
	
	
// $( "#shopping-cart" ).click(function(e) {
//     e.preventDefault()
//   $( ".cart-floating-box" ).addClass( "open", function() {
//     // Animation complete.
//   });
// });

// $( ".cart-close" ).click(function(e) {
//     e.preventDefault()
//   $( ".cart-floating-box" ).removeClass( "open", function() {
//     // Animation complete.
//   });
// });

//*-----Number Counter-----*//
$(document).ready(function(){
  "use strict";
  function count($this){
  var current = parseInt($this.html(), 10);
  current = current + 1; /* Where 50 is increment */	
  $this.html(++current);
      if(current > $this.data('count')){
          $this.html($this.data('count'));
      } else {    
          setTimeout(function(){count($this)}, 10);
      }
  }        	
  $(".stat-count").each(function() {
    $(this).data('count', parseInt($(this).html(), 10));
    $(this).html('5');
    count($(this));
  });
});
	
//=============Scroll Top=============//	

$(document).ready(function(){
    
    //Check to see if the window is top if not then display button
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100) {
            $('.scrollToTop').fadeIn();
        } else {
            $('.scrollToTop').fadeOut();
        }
    });
    
    //Click event to scroll to top
    $('.scrollToTop').click(function(){
        $('html, body').animate({scrollTop : 0},800);
        return false;
    });
    
});




		
