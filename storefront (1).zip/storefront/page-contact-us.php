<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package storefront
 */

get_header(); ?>

    <section class="inner_banner">
        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt="">
        <div class="inner_caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="breadcrum_title"><?php echo get_the_title(); ?></h1>
                        <nav aria-label="breadcrumb" class="breadcrumb mt-3">
                            <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>"><i class="bi bi-house-door-fill me-2"></i> Home</a></li>
                              <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                            </ol>
                          </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
      <section class="contact_inner sec_padding">
        <div class="container">
            <div class="contact_infoArea">
            <div class="row gx-3 gy-3">
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="contact_info">
                        <i class="bi bi-telephone"></i>
                         <h3>Phone Number</h3>
                        <a href="tel:919311681559">+91-9311681559</a>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="contact_info">
                        <i class="bi bi-envelope"></i>
                        <h3>Our Eamil</h3>
                       <a href="mailto:info@jltshop.in">info@jltshop.in</a>
                   </div>
                </div> 
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="contact_info">
                        <i class="bi bi-geo-alt"></i>
                        <h3>Our Location</h3>
                       <a href="javascript:void(0)">8,1st Floor, A - Square Complex,
                          <br> Sector 73, Noida, Uttar Pradesh 201301
                       </a>
                   </div>
                </div>

            </div>
        </div>

        <div class="contact_formArea mt-5">
            <div class="row gx-3 gy-3">
                <div class="col-md-7 col-sm-7 col-12">
                    <div class="contact_form">
                        <div class="sec_title text-left">
                            <h2 class="heading">Contact <span>Us</span></h2>
                        </div>
                        <?php echo do_shortcode('[contact-form-7 id="120" title="contact"]'); ?>
                        <!--<div class="row gx-4 gy-4">-->
                        <!--    <div class="form-group col-md-6 col-sm-6 col-12">-->
                        <!--        <i class="bi bi-person-circle"></i>-->
                        <!--        <input type="text" name="" id="" class="form-control" placeholder="First Name*">-->
                        <!--    </div>-->
                        <!--    <div class="form-group col-md-6 col-sm-6 col-12">-->
                        <!--        <i class="bi bi-person-circle"></i>-->
                        <!--        <input type="text" name="" id="" class="form-control" placeholder="Last Name*">-->
                        <!--    </div>-->
                        <!--    <div class="form-group col-md-6 col-sm-6 col-12">-->
                        <!--        <i class="bi bi-envelope"></i>-->
                        <!--        <input type="text" name="" id="" class="form-control" placeholder="Your Email*">-->
                        <!--    </div>-->
                        <!--    <div class="form-group col-md-6 col-sm-6 col-12">-->
                        <!--        <i class="bi bi-telephone"></i>-->
                        <!--        <input type="text" name="" id="" class="form-control" placeholder="Phone*">-->
                        <!--    </div>-->
                        <!--    <div class="form-group col-md-12 col-sm-12 col-12">-->
                        <!--        <textarea type="message" name="" id="" rows="5" class="form-control" placeholder="Enter your message*"></textarea>-->
                        <!--    </div>-->
                        <!--    <div class="form-group col-md-12 col-sm-12 col-12">-->
                        <!--        <button type="button" class="btn btn-theme text-uppercase">Submit</button>-->
                        <!--    </div>-->
                        <!--</div>-->
                    </div>
                </div>
                <div class="col-md-5 col-sm-5 col-12">
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.2748040191523!2d77.3788363154946!3d28.59153169268532!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce58a8852cd89%3A0xa3f1398d76e90cbf!2sV2Web%20Hosting%20Pvt.%20Ltd.%20-%20Registered%20Office!5e0!3m2!1sen!2sin!4v1651562502731!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>



<?php get_footer(); ?>
