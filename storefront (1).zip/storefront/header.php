<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!--<title>JLT Shop</title>-->
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
         <?php wp_head(); ?>
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/bootstrap.min.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/stellarnav.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/owl.carousel.min.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/owl.theme.default.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/lightcase.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/style.css" rel="stylesheet">
      <link type="text/css" href="<?=get_template_directory_uri()?>/assetsweb/css/responsive.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
      <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KSYH078CWS"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KSYH078CWS');
</script>

   </head>
   <body>

    <header class="main_header">
        <div class="container">
            <div class="row gx-0 gy-0">
                <div class="col-md-3 col-sm-3 col-12 header_left">
                    <a href="<?php echo site_url(); ?>" class="navbar-brand">
                                          <?php
                     $custom_logo_id = get_theme_mod( 'custom_logo' );
                     $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );

                     if ( has_custom_logo() ) 
                     {
                     echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '">';
                     } 
                     else 
                     {
                     echo '<h1>' . get_bloginfo('name') . '</h1>';
                     }
                  ?>
                    
                        
                        </a>                    
                </div>
                <div class="col-md-9 col-sm-9 col-12 header_right">
                    <div class="headerRight_top clearfix">
                        <h3 class="welcome-text">Welcome to Handmade Shop</h3>
                        <div class="search_top">
                            <?php aws_get_search_form( true ); ?>
                            <!--<input type="search" id="" class="form-control" placeholder="Search...">-->
                            <!--<button type="button" class="btn"><i class="bi bi-search"></i></button>-->
                        </div>
                       
                <div class="login_cart">
                                                     
               <div class="dropdown-body">
                    <a href="<?=site_url()?>/my-account" class="login-btn" title="Login">
    <i class="bi bi-person-circle"></i>
    <?php 
        global $current_user; 
        wp_get_current_user();
        if ( is_user_logged_in() ) { 
            echo $current_user->display_name; 
    ?>
    <!-- Dropdown for logged-in user -->
    <div class="user-dropdown">
        <a href="<?=site_url()?>/my-account">My Account</a>
        <a href="<?= site_url() ?>/my-account/orders/">Orders</a>
        <a href="#">Coupons</a>
        <a href="#">Gift Cards</a>
        <a href="#">Notifications</a>
        <a href="<?php echo wp_logout_url(); ?>">Logout</a>
    </div>
    <?php
        } else { 
            echo "Login"; 
        } 
    ?>
</a>
               </div>

                            <div class="cart_top">
                               <div class="shopping-cart" id="shopping-cart">
                                  <?php echo do_shortcode('[WooAjaxCartCount]'); ?>
                               </div>
                   <div class="cart-floating-box" id="cart-floating-box">
                         <a href="#" id="cart-close" class="cart-close"><i class="bi bi-x"></i></a>
                         <?php echo woocommerce_mini_cart(); ?> 
                       
                        </div>
                                 </div>
                            
                            
                         </div>
                         
                         
                    </div>
                    <div class="headerRight_bottom">
                        <div class="stellarnav">
                                <?php wp_nav_menu( array( 'container'=>false,'container_class' => false, 'theme_location' => 'primary' ) );?>
                            <!--<ul>-->
                            <!--    <li><a href="#">Home</a></li>-->
                            <!--    <li><a href="#">About Us</a></li>-->
                            <!--    <li><a href="#">Our Products</a>-->
                            <!--    <ul>-->
                            <!--        <li><a href="#">Products1</a></li>-->
                            <!--        <li><a href="#">Products1</a></li>-->
                            <!--        <li><a href="#">Products1</a></li>-->
                            <!--    </ul>-->
                            <!--    </li>-->
                            <!--    <li><a href="#">Handicrafts bag</a></li>-->
                            <!--    <li><a href="#">House old painting</a></li>-->
                            <!--    <li><a href="#">Organic soap</a></li>-->
                            <!--    <li><a href="#">Tribal Paintings</a></li>-->
                            <!--</ul>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </header>
