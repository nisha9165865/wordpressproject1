<?php
/**
 * The template for displaying all single posts.
 *
 * @package storefront
 */

get_header(); ?>

    <section class="inner_banner">
        <img src="https://devwork.v2web.in/jltweb/wp-content/uploads/2022/05/about-inner.jpg" class="img-fluid" alt="">
        <div class="inner_caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="breadcrum_title"><?php echo get_the_title(); ?></h1>
                        <nav aria-label="breadcrumb" class="breadcrumb mt-3">
                            <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>"><i class="bi bi-house-door-fill me-2"></i> Home</a></li>
                              <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                            </ol>
                          </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="sec_padding">
        <div class="container">
            <div class="row gy-4">
                <div class="col-md-8">
                    <?php the_content(); ?>
                </div>
                <div class="col-md-4">
    <div class="sidebar-area">
                        <!--<div class="widget widget_search">-->
                        <!--    <form class="search-form">-->
                        <!--        <div class="form-group">-->
                        <!--            <input type="text" placeholder="Search your itmes">-->
                        <!--        </div>-->
                        <!--        <button class="submit-btn" type="submit"><i class="bi bi-search"></i></button>-->
                        <!--    </form>-->
                        <!--</div>-->
                        <div class="widget widget-recent-post">
                            <h4 class="widget-title">Recent Post</h4>
                            
                                    <ul>
			<?php $query=new WP_query(array('cat'=>'22','order'=>'DESC','posts_per_page'=>'4'));
                            while($query->have_posts()){
                            $query->the_post();?>
         
                                          <li>
                                    <div class="media">
                                        <div class="media-left">
                                            <img src="<?php echo get_the_post_thumbnail_url();?>" alt="widget">
                                        </div>
                                        <div class="media-body">
                                            <h6 class="title"><a href="<?php echo get_the_permalink();?>"><?php the_title();?></a></h6>
                                        </div>
                                    </div>
                                </li>
          
          
		<?php } ?>
        <?php wp_reset_postdata();?>
</ul>
                 
                        </div>
                        <!--<div class="widget widget_categories">-->
                        <!--    <h4 class="widget-title">Categories</h4>-->
                        <!--    <ul>-->
                        <!--        <li><a href="#">Inspiration <span>(5)</span></a></li>-->
                        <!--        <li><a href="#">Recipes <span>(9)</span> </a></li>-->
                        <!--        <li><a href="#">Others <span>(18)</span></a></li>-->
                        <!--    </ul>-->
                        <!--</div>-->
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <
<?php
do_action( 'storefront_sidebar' );
get_footer();
