<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package storefront
 */

get_header(); ?>

    <section class="inner_banner">
        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt="">
        <div class="inner_caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="breadcrum_title"><?php echo get_the_title(); ?></h1>
                        <nav aria-label="breadcrumb" class="breadcrumb mt-3">
                            <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>"><i class="bi bi-house-door-fill me-2"></i> Home</a></li>
                              <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                            </ol>
                          </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    <section class="about_inner sec_padding">
        <div class="container">
            <div class="row gy-4">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="aboutInner_img">
                        <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/about-inner.png" class="img-responsive" alt="">
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="aboutInnerwraper">
                        <div class="sec_title text-left">
                            <h2 class="heading">About <span>Us</span></h2>
                        </div>
                        <?php echo $value = get_field( "description", 5 ); ?>
                        <!--<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Corrupti veritatis incidunt eligendi ipsum dolorem quod cum non dignissimos ab pariatur blanditiis debitis mollitia deleniti ea at, rem, iste ratione magni! Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro, sapiente ullam? Culpa, eos. Sit dignissimos quis tempora sequi tenetur, veniam, dolor omnis quasi beatae voluptas rerum id ea vero cumque. Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore quaerat harum officiis dolorum dolore. Id sapiente asperiores debitis a ea cupiditate libero at necessitatibus quibusdam? Nobis soluta ducimus laborum quis. Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur atque quos officia repudiandae cum odit. Sunt expedita at quia, saepe enim molestiae sequi aperiam, odit sit facilis totam rem sed?</p>-->
                        <!--<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Explicabo eligendi dolorum minus enim, sit animi totam iste corrupti odit, aut hic excepturi doloremque qui dolor repellendus dignissimos voluptas tenetur beatae!</p>-->
                        <div class="row gx-3 gy-3 mt-4">
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="milestone-counter">
                                    <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/001-product.png" alt="">
                                    <p><span class="stat-count highlight">324</span>+</p>
                                    <h3 class="milestone-title">Products</h3>
                                    </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="milestone-counter">
                                    <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/002-revenue.png" alt="">
                                    <p>$<span class="stat-count highlight">3</span>M</p>
                                    <h3 class="milestone-title">Revenue</h3>
                                    </div>
                            </div> 
                            <div class="col-md-4 col-sm-4 col-6">
                                <div class="milestone-counter">
                                    <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/003-awards.png" alt="">
                                    <p><span class="stat-count highlight">379</span>+</p>
                                    <h3 class="milestone-title">Awards</h3>
                                    </div>
                            </div>
            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Inner Area End -->

    <!-- Why Choose Us Area Start -->
    <section class="whyus_area sec_padding">
        <div class="container">
            <div class="row gx-4 gy-4">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="sec_title text-center">
                        <h2 class="heading">Why Choose <span>Us</span></h2>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="whyus_wraper">
                        <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/002-delivery.png" class="w-auto mb-3" alt="">
                        <h3>Home Fast <strong>Delivery</strong></h3>
                        <!--<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt natus suscipit, non illum dignissimos repellendus eligendi odit blanditiis nemo vitae accusamus. Laborum illo quaerat quo adipisci minus tempore odio porro!</p>-->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="whyus_wraper">
                        <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/001-wallet.png" class="w-auto mb-3" alt="">
                        <h3>Secure <strong>Payment</strong></h3>
                        <!--<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt natus suscipit, non illum dignissimos repellendus eligendi odit blanditiis nemo vitae accusamus. Laborum illo quaerat quo adipisci minus tempore odio porro!</p>-->
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="whyus_wraper">
                        <img src="<?=get_template_directory_uri()?>/assetsweb/images/home/003-24-7.png" class="w-auto mb-3" alt="">
                        <h3>24/7 Customer <strong>Support</strong></h3>
                        <!--<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt natus suscipit, non illum dignissimos repellendus eligendi odit blanditiis nemo vitae accusamus. Laborum illo quaerat quo adipisci minus tempore odio porro!</p>-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Why Choose Us Area End -->
    
    
  <!-- Testimonials Area Start-->
  
        <section class="testimonial-area sec_padding">
          <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="sec_title text-center">
                        <h2 class="heading text-light">Testimo<span>nials</span></h2>
                    </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-12">
                      <div class="testim_slide owl-carousel owl-theme">
                           <?php
                     $args = array(  
                    'post_type' => 'testimonial',
                    'post_status' => 'publish',
                    'posts_per_page' => 8, 
                    'orderby' => 'title', 
                    'order' => 'ASC', 
                );
            
                $loop = new WP_Query( $args ); 
                    
                while ( $loop->have_posts() ) : $loop->the_post();  ?>
                   
               
         <div class="item">
                              <div class="testimonial_wraper row">
                                  <div class="col-md-4 col-sm-4 col-12 testimonial_img">
                                      <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                                      <div class="rating">  
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>                                        
                                      </div>
                                  </div>
                                  <div class="col-md-8 col-sm-8 col-12 testimonial_text">
                                      <div class="author">
                                          <h3><?php echo get_the_title(); ?></h3>
                                          <h6><?php echo get_post_meta($post->ID,'Position', true ); ?></h6>
                                      </div>
                                      <p><?php echo get_the_content(); ?></p>
                                  </div>
                              </div>
                          </div>
         
         
         
            <?php    endwhile; 
            
              wp_reset_postdata(); 
                    ?>
         
              
                      <!-- item end -->
                      </div>
                  </div>
              </div>
          </div>
      </section>
  

<!-- Testimonials Area End -->
    


<?php get_footer(); ?>
