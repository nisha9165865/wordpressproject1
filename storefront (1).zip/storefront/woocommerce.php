   <?php get_header(); ?>

   <section class="inner_banner">
        <img src="https://jltshop.in/wp-content/uploads/2022/05/about-inner.jpg" class="img-fluid" alt="">
        <div class="inner_caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="breadcrum_title"><?php if( is_product_category() ) {
echo woocommerce_page_title();
} else if(is_shop()){
    echo "SHOP";
} else {
echo	woocommerce_template_single_title();
} ;?></h1>
                        	<?php woocommerce_breadcrumb(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="innerPage_wraper sec_padding">
        <div class="container">
              <div class="row">
                  
                  
                   <?php if(!is_single()) {?>
                  				<div class="col-md-3 col-sm-3">

				<div class="list_menu_left">
						<h3 class="mb-3">Categories</h3>
						<div class="accordion" id="accordionMenu">
						    	<?php
$orderby = 'name';
$order = 'asc';
$hide_empty = 0;


$cat_args = array(
    'orderby'    => $orderby,
    'order'      => $order,
    'hide_empty' => $hide_empty,
);
 
$product_categories = get_terms( 'product_cat', $cat_args );
 
$i=1;
   
    foreach ($product_categories as $key => $category) { ?>
   <div class="accordion-item">
							  <h2 class="accordion-header" id="headingOne<?php echo $i; ?>">
								<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="false" aria-controls="collapse<?php echo $i; ?>">
									<?php echo $category->name; ?>
								</button>
							  </h2>
							  <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php if($i=='1'){echo "";} ?>" aria-labelledby="heading<?php echo $i; ?>" data-bs-parent="#accordionMenu">
								<div class="accordion-body">
								<div class="sub_category">
								    	<ul>
								                  <?php

                                $args = array( 'post_type' => 'product', 'stock' => 1, 'posts_per_page' => 15,'product_cat' => $category->name, 'orderby' =>'date','order' => 'ASC' );
                                  $loop = new WP_Query( $args );
                                while ( $loop->have_posts() ) : $loop->the_post();
                                global $product; 
                                ?>
								    		
										<li><a href="<?php echo get_permalink();?>"><?php echo get_the_title();?></a></li>
									
							
								   
							<?php endwhile; wp_reset_query(); ?>	    
						
	                     	</ul>
								</div>
								
								</div>
							  </div>
							</div>
   <?php $i++; } ?>
						    
							<!--<div class="accordion-item">-->
							<!--  <h2 class="accordion-header" id="headingOne">-->
							<!--	<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">-->
							<!--		Samosa-->
							<!--	</button>-->
							<!--  </h2>-->
							<!--  <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionMenu">-->
							<!--	<div class="accordion-body">-->
							<!--	<div class="sub_category">-->
							<!--		<ul>-->
							<!--			<li><a href="#">Aloo Samosa</a></li>-->
							<!--			<li><a href="#">Chilli Cheese Samosa</a></li>-->
							<!--			<li><a href="#">Chocolate Samosa</a></li>-->
							<!--			<li><a href="#">Paneer Samosa</a></li>-->
							<!--			<li><a href="#">Keema Samosa</a></li>-->
							<!--			<li><a href="#">Egg Samosa</a></li>-->
							<!--			<li><a href="#">Pizza Samosa</a></li>-->
							<!--		</ul>-->

							<!--	</div>-->
								
							<!--	</div>-->
							<!--  </div>-->
							<!--</div>-->
							<!--<div class="accordion-item">-->
							<!--  <h2 class="accordion-header" id="headingTwo">-->
							<!--	<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">-->
							<!--		Cake-->
							<!--	</button>-->
							<!--  </h2>-->
							<!--  <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionMenu">-->
							<!--	<div class="accordion-body">-->
							<!--		<div class="sub_category">-->
							<!--			<ul>-->
							<!--				<li><a href="#">Aloo Samosa</a></li>-->
							<!--				<li><a href="#">Chilli Cheese Samosa</a></li>-->
							<!--				<li><a href="#">Chocolate Samosa</a></li>-->
							<!--				<li><a href="#">Paneer Samosa</a></li>-->
							<!--				<li><a href="#">Keema Samosa</a></li>-->
							<!--				<li><a href="#">Egg Samosa</a></li>-->
							<!--				<li><a href="#">Pizza Samosa</a></li>-->
							<!--			</ul>-->
	
							<!--		</div>-->
							
							<!--	</div>-->
							<!--  </div>-->
							<!--</div>-->
							<!--<div class="accordion-item">-->
							<!--  <h2 class="accordion-header" id="headingThree">-->
							<!--	<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">-->
							<!--		Samosa-->
							<!--	</button>-->
							<!--  </h2>-->
							<!--  <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionMenu">-->
							<!--	<div class="accordion-body">-->
							<!--		<div class="sub_category">-->
							<!--			<ul>-->
							<!--				<li><a href="#">Aloo Samosa</a></li>-->
							<!--				<li><a href="#">Chilli Cheese Samosa</a></li>-->
							<!--				<li><a href="#">Chocolate Samosa</a></li>-->
							<!--				<li><a href="#">Paneer Samosa</a></li>-->
							<!--				<li><a href="#">Keema Samosa</a></li>-->
							<!--				<li><a href="#">Egg Samosa</a></li>-->
							<!--				<li><a href="#">Pizza Samosa</a></li>-->
							<!--			</ul>-->
	
							<!--		</div>-->
							<!--	</div>-->
							<!--  </div>-->
							<!--</div>-->
						  </div>

					</div>

				</div>
                  
                  
                  
                  
                  				<div class="col-md-9 col-sm-9">
				    
					<div class="row">
						<div class="col-md-12 col-sm-12">
                  
                  
            			<div class="product_list_header">
							
								<div class="sort-wrapper">
								     <?php do_action( 'woocommerce_before_shop_loop' );?>
								
								</div>
						</div>
            
             
            
            <div class="row gx-3 gy-3">
               		    	<?php
                       global $product;
                       	if ( wc_get_loop_prop( 'total' ) ) {
            		while ( have_posts() ) {
            			the_post();?> 
                
                <div class="col-md-4 col-sm-4">
                    <div class="product_wraper">
                        <div class="product_figure">
                           <a href="<?=get_the_permalink()?>"><img src="<?=get_the_post_thumbnail_url()?>" alt=""></a>
                        </div>
                        <div class="product_text text-center">
                            <h4><?php echo get_the_title(); ?></h4>
                            <div class="price">
                                <?php echo $product->get_price_html();?>
                            </div>
                            <a  href="<?php echo $product->add_to_cart_url()?>" value="<?php echo esc_attr( $product->get_id() )?>" class="btn-light-grey single_add_to_cart_button alt product_type_simple  ajax_add_to_cart add_to_cart_button btn btn-outline-primary added" data-product_id="<?php echo get_the_ID(); ?>" data-product_sku="<?php echo esc_attr($sku); ?>" aria-label="<?php the_title_attribute(); ?>">Add To Cart</a>
                        </div>
                    </div>
                </div>
                
                
            <?php

        }} else {
            echo __( 'No products found' );
        }
        wp_reset_query();

    ?>
            </div>
            
            							<div class="row mt-4">
								<div class="col-md-12 colsm-12">
								    <div class="page_navi"><?php  wp_pagenavi(); ?></div>
								
								</div>
							</div>
            </div>
            		</div>
							</div>
            </div>
        </div>
    </section><?php }else{
        
        
woocommerce_content();
    echo'</div>';
    
      echo'</section>';
    
}

?>
    <?php get_footer(); ?>