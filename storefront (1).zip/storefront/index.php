<?php get_header(); ?>

      <!-- Start Slider BODY section -->
      <div class="main_slider owl-carousel owl-theme">
         
         
                          <?php
                     $args = array(  
                    'post_type' => 'slider',
                    'post_status' => 'publish',
                    'posts_per_page' => 8, 
                    'orderby' => 'title', 
                    'order' => 'ASC', 
                );
            
                $loop = new WP_Query( $args ); 
                    
                while ( $loop->have_posts() ) : $loop->the_post();  ?>
                   
                        <div class="item">
            <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt="">
            <div class="owl-caption">
                <div class="container">
                    
                    <div class="owl-captionInner">
                       <h1 class="title_caption"><?php echo get_the_title(); ?></h1>
                       <a href="<?php echo site_url() ?>/shop" class="btn bg-light text-dark">Shop Now <i class="bi bi-arrow-right"></i></a>
                    </div>
                 </div>
            </div>
         </div>
         
            <?php    endwhile; 
            
              wp_reset_postdata(); 
                    ?>
         

      </div>
      <!-- End Slider BODY section -->

      <!-- New Arivals Area Start -->
      <section class="arivals_area sec_padding">
          <div class="container">
              <div class="row gx-4 gy-4">
                <div class="col-md-4 col-sm-4 col-12">
                    <div class="sec_title text-left mb-0">
                        <h2 class="heading">New <span>Arrivals</span></h2>
                    </div>
                </div>
                  <div class="col-md-8 col-sm-8 col-12">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <button class="nav-link active" id="nav-featured-tab" data-bs-toggle="tab" data-bs-target="#nav-featured" type="button" role="tab" aria-controls="nav-featured" aria-selected="true">Featured</button>
                          <button class="nav-link" id="nav-latest-tab" data-bs-toggle="tab" data-bs-target="#nav-latest" type="button" role="tab" aria-controls="nav-latest" aria-selected="false">Latest</button>
                          <button class="nav-link" id="nav-bestsellers-tab" data-bs-toggle="tab" data-bs-target="#nav-bestsellers" type="button" role="tab" aria-controls="nav-bestsellers" aria-selected="false">Best Sellers</button>
                        </div>
                      </nav>
                  </div>
                  <div class="col-md-12 col-sm-12 col-12">
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-featured" role="tabpanel" aria-labelledby="nav-featured-tab">
                            <div class="product_slider owl-carousel owl-theme">
                                
                                			    <?php
			    
                                			    // The tax query
                                $tax_query[] = array(
                                    'taxonomy' => 'product_visibility',
                                    'field'    => 'name',
                                    'terms'    => 'featured',
                                    'operator' => 'IN', // or 'NOT IN' to exclude feature products
                                );
                                
                                // The query
                                $loop = new WP_Query( array(
                                    'post_type'           => 'product',
                                    'post_status'         => 'publish',
                                    'ignore_sticky_posts' => 1,
                                    'posts_per_page'      => 5,
                                 'orderby' => 'meta_value_num',
                                        'order' => 'DESC',
                                    'tax_query'           => $tax_query // <===
                                ) );
                                		 
                                while ( $loop->have_posts() ) : $loop->the_post();
                                global $product; 
                                ?>	    
			    
			  
                      			             <div class="item">
                                    <div class="product_wraper">
                                        <div class="product_figure">
                                             <a href="<?php echo get_the_permalink();?>"> <img src="<?php echo get_the_post_thumbnail_url();?>" alt=""></a>
                                        </div>
                                        <div class="product_text text-center">
                                           <a href="<?php echo get_the_permalink();?>"> <h4><?php echo get_the_title();?></h4></a>
                                            <div class="price">
                                                <?php echo $product->get_price_html();?>
                                            </div>
                                            <a href="<?php echo $product->add_to_cart_url()?>" class="btn-light-grey single_add_to_cart_button alt product_type_simple  ajax_add_to_cart add_to_cart_button btn btn-outline-primary" value="<?php echo esc_attr( $product->get_id() )?>" data-product_id="<?php echo get_the_ID(); ?>" data-product_sku="<?php echo esc_attr($sku); ?>" aria-label="<?php the_title_attribute(); ?>">Add To Cart</a>
                                        </div>
                                    </div>
                                </div>

			    
			    
			    <?php endwhile; wp_reset_query(); ?>
                                
                                
                                
                                
                                
                           
                            
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-latest" role="tabpanel" aria-labelledby="nav-latest-tab">
                            <div class="product_slider owl-carousel owl-theme">
                                	    <?php
			    
                                $loop = new WP_Query( array(
                                    'post_type'           => 'product',
                                    'post_status'         => 'publish',
                                    'ignore_sticky_posts' => 10,
                                    'posts_per_page'      => 5,
                                 'orderby' => 'meta_value_num',
                                        'order' => 'DESC',
                                  
                                ) );
                                		 
                                while ( $loop->have_posts() ) : $loop->the_post();
                                global $product; 
                                ?>	    
			    
			  
                      			             <div class="item">
                                    <div class="product_wraper">
                                        <div class="product_figure">
                                              <a href="<?php echo get_the_permalink();?>"><img src="<?php echo get_the_post_thumbnail_url();?>" alt=""></a>
                                        </div>
                                        <div class="product_text text-center">
                                             <a href="<?php echo get_the_permalink();?>"> <h4><?php echo get_the_title();?></h4></a>
                                            <div class="price">
                                                <?php echo $product->get_price_html();?>
                                            </div>
                                            <a href="<?php echo $product->add_to_cart_url()?>" class="btn-light-grey single_add_to_cart_button alt product_type_simple  ajax_add_to_cart add_to_cart_button btn btn-outline-primary" value="<?php echo esc_attr( $product->get_id() )?>" data-product_id="<?php echo get_the_ID(); ?>" data-product_sku="<?php echo esc_attr($sku); ?>" aria-label="<?php the_title_attribute(); ?>">Add To Cart</a>
                                        </div>
                                    </div>
                                </div>

			    
			    
			    <?php endwhile; wp_reset_query(); ?>
                       
                            </div>
                            
                        </div>
                        <div class="tab-pane fade" id="nav-bestsellers" role="tabpanel" aria-labelledby="nav-bestsellers-tab">
                            
                            <div class="product_slider owl-carousel owl-theme">
                                
                                 	    <?php
			    
                                $loop = new WP_Query( array(
                                           'posts_per_page' => 12,
                                            'post_type' => 'product',
                                            'post_status' => 'publish',
                                            'ignore_sticky_posts' => 1,
                                             'posts_per_page'      => 10,
                                            'meta_key' => 'total_sales',
                                            'orderby' => 'meta_value_num',
                                            'order' => 'DESC',
                                  
                                ) );
                                		 
                                while ( $loop->have_posts() ) : $loop->the_post();
                                global $product; 
                                ?>	    
			    
			  
                      			             <div class="item">
                                    <div class="product_wraper">
                                        <div class="product_figure">
                                              <a href="<?php echo get_the_permalink();?>"><img src="<?php echo get_the_post_thumbnail_url();?>" alt=""></a>
                                        </div>
                                        <div class="product_text text-center">
                                            <a href="<?php echo get_the_permalink();?>"> <h4><?php echo get_the_title();?></h4></a>
                                            <div class="price">
                                                <?php echo $product->get_price_html();?>
                                            </div>
                                            <a href="<?php echo $product->add_to_cart_url()?>" class="btn-light-grey single_add_to_cart_button alt product_type_simple  ajax_add_to_cart add_to_cart_button btn btn-outline-primary" value="<?php echo esc_attr( $product->get_id() )?>" data-product_id="<?php echo get_the_ID(); ?>" data-product_sku="<?php echo esc_attr($sku); ?>" aria-label="<?php the_title_attribute(); ?>">Add To Cart</a>
                                        </div>
                                    </div>
                                </div>

			    
			    
			    <?php endwhile; wp_reset_query(); ?>
                       
                            <!-- Item End -->
                            </div>
                        </div>
                      </div>
                  </div>
              </div>
              
          </div>
      </section>
      <!-- New Arivals Area End -->

      <section class="category_area sec_padding">
          <div class="container">
              <div class="row gx-2 gy-2">
                  <div class="col-md-12 col-sm-12 col-12">
                    <div class="sec_title text-center">
                        <h2 class="heading text-light">Popular <span>Categories</span></h2>
                    </div>
                  </div>
                  <div class="col-md-6 col-sm-6 col-12">
                      <div class="category_wraper">
                          <img src="<?=get_template_directory_uri()?>/assetsweb/images/product/category1.jpg" alt="">
                          <div class="category_body category_body1">
                              <h3>Tribal <span class="d-block">Paintings</span></h3>
                              <a href="<?php echo site_url() ?>/product-category/tribal-paintings/" class="btn btn-theme">Shop Now</a>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6 col-sm-6 col-12">
                      <div class="row gx-2 gy-2">
                        <div class="col-md-6 col-sm-6 col-12">
                            <div class="category_wraper">
                                <img src="<?=get_template_directory_uri()?>/assetsweb/images/product/category2.jpg" alt="">
                                <div class="category_body category_body2">
                                    <h3 class="text-light">Handicrafts <span>Bag</span></h3>
                                    <a href="<?php echo site_url() ?>/product-category/handicrafts-bag/" class="btn">Shop Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-12">
                            <div class="category_wraper">
                                <img src="<?=get_template_directory_uri()?>/assetsweb/images/product/category3.jpg" alt="">
                                <div class="category_body category_body3">
                                    <h3>Wooden <span class="d-block">Shield</span></h3>
                                    <a href="#" class="btn">Shop Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-12">
                            <div class="category_wraper">
                                <img src="<?=get_template_directory_uri()?>/assetsweb/images/product/category4.jpg" alt="">
                                <div class="category_body category_body4">
                                    <h3>Organic <span>Soap</span></h3>
                                    <a href="<?php echo site_url() ?>/product-category/organic-soap"" class="btn">Shop Now</a>
                                </div>
                            </div>
                        </div>
                      </div>
                  </div>
              </div>
          </div>          
      </section>

      <!-- About US Area Start -->
      <section class="about_area sec_padding">
          <div class="container">
              <div class="row">
                  <div class="col-md-12">
                      <div class="about-wraper text-center  ">
                          <div class="sec_title text-center">
                              <h2 class="heading">About <span>Us</span></h2>
                          </div>
                         <?php   $value = get_field( "description", 5 );
                        echo substr($value, 0, 1284). ' ...';
                         // echo $trimmed_content = wp_trim_words( $value, 300); 
                         ?><br>
                          <a href="<?php echo site_url(); ?>/about-us/" class="btn btn-theme text-uppercase"> Read More</a>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- About US Area End -->

      <!-- Testimonials Area Start-->
      <section class="testimonial-area sec_padding">
          <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="sec_title text-center">
                        <h2 class="heading text-light">Testimo<span>nials</span></h2>
                    </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-12">
                      <div class="testim_slide owl-carousel owl-theme">
                           <?php
                     $args = array(  
                    'post_type' => 'testimonial',
                    'post_status' => 'publish',
                    'posts_per_page' => 8, 
                    'orderby' => 'title', 
                    'order' => 'ASC', 
                );
            
                $loop = new WP_Query( $args ); 
                    
                while ( $loop->have_posts() ) : $loop->the_post();  ?>
                   
               
         <div class="item">
                              <div class="testimonial_wraper row">
                                  <div class="col-md-4 col-sm-4 col-12 testimonial_img">
                                      <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                                      <div class="rating">  
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>                                        
                                      </div>
                                  </div>
                                  <div class="col-md-8 col-sm-8 col-12 testimonial_text">
                                      <div class="author">
                                          <h3><?php echo get_the_title(); ?></h3>
                                          <h6><?php echo get_post_meta($post->ID,'Position', true ); ?></h6>
                                      </div>
                                      <p><?php echo get_the_content(); ?></p>
                                  </div>
                              </div>
                          </div>
         
         
         
            <?php    endwhile; 
            
              wp_reset_postdata(); 
                    ?>
         
              
                      <!-- item end -->
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- Testimonials Area End -->

      <!-- Social Product Area Start -->
      <section class="socialProduct_area sec_padding">
          <div class="container">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="sec_title d-inline-block">
                        <h2 class="heading text-left">Social <span>Products</span></h2>
                    </div>
                </div>
                  <div class="col-md-12 col-sm-12 col-12">
                      <div class="product_slider owl-carousel owl-theme">

         
         
         
                                    <?php
                                         $args = array(
                                    'posts_per_page' => '12',
                                    'product_cat' => 'handmate',
                                    'post_type' => 'product',
                                    'orderby' => 'title',
                                );

                $loop = new WP_Query( $args ); 
                    
                while ( $loop->have_posts() ) : $loop->the_post();  ?>
                   
         
                                   <div class="item">
                              <div class="product_wraper">
                                  <div class="product_figure">
                                             <a href="<?php echo get_the_permalink();?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt=""></a>
                                  </div>
                                  <div class="product_text text-center">
                                             <a href="<?php echo get_the_permalink();?>"><h4><?php echo get_the_title(); ?></h4></a>
                                     
                                            <div class="price">
                                                <?php echo $product->get_price_html();?>
                                            </div>
                                            <a href="<?php echo $product->add_to_cart_url()?>" class="btn-light-grey single_add_to_cart_button alt product_type_simple  ajax_add_to_cart add_to_cart_button btn btn-outline-primary" value="<?php echo esc_attr( $product->get_id() )?>" data-product_id="<?php echo get_the_ID(); ?>" data-product_sku="<?php echo esc_attr($sku); ?>" aria-label="<?php the_title_attribute(); ?>">Add To Cart</a>
                                       
                                  </div>
                              </div>
                          </div>
         
            <?php    endwhile; 
            
              wp_reset_postdata(); 
                    ?>
         
         
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- Social Product Area End -->

      <!-- Video Area Start -->
      <section class="VideoArea">
          <div class="container">
              <div class="row">
                  <div class="col-md-12 col-sm-12 col-12">
                      <div class="vider_wraper">
                          <a href="#"><i class="bi bi-play-fill"></i></a>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- Video Area End -->

      <!-- Latest Blog Area -->
      <section class="blog_area sec_padding">
          <div class="container">
              <div class="row gx-4 gy-4">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="about-wraper text-center  ">
                        <div class="sec_title text-center">
                            <h2 class="heading">Latest <span>Blog</span></h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                        </div>                      
                    </div>
                </div>
                
                
                <?php 
		    
                $loop = new WP_Query( array( 'cat'=>'22', 'order_by'=>'desc','posts_per_page' => 3)); ?>
                <?php while($loop->have_posts()){
                            $loop->the_post(); ?>
			      <div class="col-md-4 col-sm-4 col-12">
                      <div class="blog_wraper">
                          <div class="blog_img">
                              <img src="<?php echo get_the_post_thumbnail_url();?>" alt="">
                          </div>
                          <div class="blog_text">
                              <div class="post_date mb-2">
                                <i class="bi bi-calendar3 me-2"></i><?php echo get_the_date();?>
                              </div>
                              <h4 class="post_title"><?php echo the_title();?></h4>
                              <p><?php echo the_excerpt();?></p>
                              <a href="<?php echo get_the_permalink();?>" class="btn btn-theme">Read More <i class="bi bi-arrow-right ms-2"></i></a>
                          </div>
                      </div>
                  </div>
			<?php } ?>
			<?php wp_reset_postdata();?>
                
                

              </div>
          </div>
      </section>
      <!-- Latest Blog End -->
<a href="https://api.whatsapp.com/send?phone=919311681559&amp;text=Hello,%20I'm%20looking%20for" target="_blank" class="float_whatsapp"><i class="fab fa-whatsapp"></i></a>

<?php get_footer(); ?>