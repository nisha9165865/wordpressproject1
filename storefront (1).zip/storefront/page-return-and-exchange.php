<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package storefront
 */

get_header(); ?>

    <section class="inner_banner">
        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt="">
        <div class="inner_caption">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="breadcrum_title"><?php echo get_the_title(); ?></h1>
                        <nav aria-label="breadcrumb" class="breadcrumb mt-3">
                            <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>"><i class="bi bi-house-door-fill me-2"></i> Home</a></li>
                              <li class="breadcrumb-item active" aria-current="page"><?php echo get_the_title(); ?></li>
                            </ol>
                          </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
      <section class="contact_inner sec_padding">
        <div class="container">
           

        <div class="contact_formArea mt-5">
            <div class="row gx-3 gy-3">
                <div class="col-md-6">
                    <div class="contact_form">
                        <div class="sec_title text-left">
                            <h2 class="heading">Return And <span>Exchange</span></h2>
                        </div>
                        <?php echo do_shortcode('[contact-form-7 id="193" title="Return and Exchange"]'); ?>
                        
                    </div>
                </div>
                
                 <div class="col-md-6">
                    <div class="contact_form">
                        <!--<div class="sec_title text-left">-->
                        <!--    <h2 class="heading">Return And <span>Exchange</span></h2>-->
                        <!--</div>-->
                       <!--<img src="https://devwork.v2web.in/jltweb/wp-content/uploads/2022/06/return-parcel-icon-exchange-of-goods-sign-vector-22621713.jpg">-->
                        
                    </div>
                </div>
                
            </div>
        </div>
        </div>
    </section>



<?php get_footer(); ?>
