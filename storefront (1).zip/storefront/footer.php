  <!-- Footer Area Start -->

      <footer class="site_footer">

          <div class="container">

              <div class="row gx-4 gy-4">

                  <div class="col-md-4 col-sm-4 col-12">

                      <div class="footer_contact">

                          <h3 class="footer_title">Contact Us</h3>

                          <ul>                           

                              <li><i class="bi bi-geo-alt"></i><a href="javascript:void(0)">8,1st Floor, A - Square Complex, Sector 73, Noida, Uttar Pradesh 201301</a></li>

                              <li><i class="bi bi-telephone"></i> <a href="tel:+91-9311681559">+91-9311681559</a></li>

                              <li><i class="bi bi-envelope"></i><a href="mailto:info@jltshop.in">info@jltshop.in</a></li>

                          </ul>

                      </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-12">

                    <div class="footer_links">

                        <h3 class="footer_title">Quick link</h3>

                        <ul>                  

                            <!--<li><a href="<?php echo site_url() ?>">Home</a></li>-->

                            <!--<li><a href="<?php echo site_url() ?>/product-category/handicrafts-bag/">Handicrafts Bag</a></li>-->

                            <!--<li><a href="<?php echo site_url() ?>/product-category/household-painting/">House Hold Painting</a></li>-->

                            <!--<li><a href="<?php echo site_url() ?>/product-category/organic-soap">Organic Soap</a></li>-->

                            <!--<li><a href="<?php echo site_url() ?>/product-category/tribal-paintings/">Tribal Paintings</a></li>-->

                            <li><a href="<?php echo site_url() ?>/contact-us/">Contact Us</a></li>

                            <li><a href="<?php echo site_url() ?>/shipping-policy">Shipping Policy</a></li>

                            <li><a href="<?php echo site_url() ?>/return-and-exchange-policy">Return And Exchange Policy</a></li>

                            <li><a href="<?php echo site_url() ?>/privacy-policy-2">Privacy Policy</a></li>

                        </ul>

                    </div>

                </div>

                <div class="col-md-4 col-sm-4 col-12">

                    <div class="footer_subscribe">

                        <h3 class="footer_title">Newsletter</h3>

                        <p>Don't miss latest updates & hot deals</p>

                         <?php dynamic_sidebar('Footer 4');?>

                        <!--<form action="">-->

                        <!--    <input type="email" name="" class="form-control" placeholder="Your email address">-->

                        <!--    <button class="btn"><i class="bi bi-telegram"></i></button>-->

                        <!--</form>-->



                        <ul class="footer_social mt-4 mb-0">                           

                            <li><a href="https://www.facebook.com/jltshop.in" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>

                            <li><a href="https://twitter.com/jltshopin" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>

                            <li><a href="https://www.linkedin.com/company/83041387/admin/" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>

                            <li><a href="https://www.instagram.com/jltshopin/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                            

                        </ul>

                    </div>

                </div>

              </div>

          </div>

          <div class="footer_bottom">

              <div class="container">

                  <div class="row">

                      <div class="col-md-12 col-sm-12 col-12">

                        <div class="copyrigh text-light text-center">

                            <p class="text-light">Copyright © 2022 JLT Shop. All Rights Reserved. Designed By <a href="https://www.v2web.in/">v2web</a></p>

                         </div>

                      </div>

                  </div>

              </div>

          </div>

      </footer>

      <!-- Footer Area End -->



      

      <a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/jquery-3.5.1.min.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/jquery.min.js"></script> 

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/popper.min.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/bootstrap.min.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/stellarnav.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/owl.carousel.min.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/lightcase.js"></script>

      <script src="<?=get_template_directory_uri()?>/assetsweb/js/custom.js"></script>

      <script>

         $('.showcase').lightcase();

      </script>

      

      <script>

jQuery(document).ready(function(){

    

        jQuery('.ajax_add_to_cart').click(function(){

    setTimeout(function () {

         jQuery.ajax({

        url : woocommerce_params.ajax_url,

        type : 'post',

        data : {

            'action': 'ajax_update_mini_cart'

        },

        success : function( response ) {

            //console.log(response);

            jQuery('#cart-floating-box').html(response);

        }

    });

      }, 2000);    

        

  

});

    

      jQuery( "body" ).delegate( ".remove_from_cart_button", "click", function(e){

    e.preventDefault();

    setTimeout(function () {

       

        location.reload(true);

      }, 2000);

      

    //   new code

               jQuery.ajax({

        url : woocommerce_params.ajax_url,

        type : 'post',

        data : {

            'action': 'ajax_update_mini_cart'

        },

        success : function( response ) {

            //console.log(response);

            jQuery('#cart-floating-box').html(response);

        }

    });

    //   end new code

    });

    

});

  

    

</script>

      

      <?php wp_footer(); ?>



      

      

   </body>

</html>