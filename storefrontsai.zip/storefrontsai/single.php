<?php
/**
 * The template for displaying all single posts.
 *
 * @package storefront
 */

get_header(); ?>
        <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
 <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
<div class="sec_title">
    <h1 class="sec_heading mb-2">Latest News</h1>
    <div class="section-border"><span></span></div>
</div>

<div class="row g-4 mt-4">
    <div class="col-xl-9 col-lg-9 col-md-6">
       <div class="news-dest">
        <h6 class="date"><i class="bi bi-calendar-event-fill"></i> <?php echo date('j F Y', strtotime(get_the_date())); ?> </h6>
            <h3 class="color"><?php echo get_the_title(); ?></h3>
        <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="img">
        <div class="news-info">  
        <?php echo  the_content(); ?>
            <!--<h6>SHRI SAI SAMITI NOIDA</h6>-->
            <!--<h6>A WORD ABOUT – SH. SUMMET PONDA (BHAI JI)</h6>-->
            <!--<p>Sh. Sumeet Ponda, known amongst his followers as Bhaiji is an ardent devotee of Sai Baba. He has been decorated with many prestigious awards like the Rashtriya Vidya Samman, Puraskar, the Educational Excellence Award, Gujrat Siksha Ratan Purskar, Rajiv Gandhi Educational Award, Vidya Ratan Gold Medal among many other. A Post-graduate (Gold Medalist) form MBA institute of Bhopal. Has many first to his credit in the field of education i.e. introduction of smart school concept and getting affiliation with Cambridge International U.K. for the school started and managed by him as a part of corporate Social Responsibility (CSR). </p>-->
            <!--<p>He is extremely popular amongst devotees of Sai Baba, his Katha based on Leelas of Baba mixed with Bhajan & HIS miracles, their significance and its relevance have been hugely appreciated across the country. He draws audience thousands. Recent being the programme conducted by him at Shirdi, on the eve of Gurupurnima, where devotees in lakhs were kept spellbound during the period of discourse /performance.</p>-->
            <!--<p>Sh. Sumeet Ponda (Bhai Ji) has most kindly consented to give a performance for the benefit of devotees at Noida.-->

            <!--    All are requested to attend and spiritually benefit from his Katha based on Leelas of Sai Baba. It may be mention that his programme would be live telecasted on 07.09.2014 to 09.09.2014 from 7 p.m. to 10 p.m. on AASTHA CHANNEL. COURTESY: NARAYAN SEWA SANSTHAN, UDAIPUR-->
                
            <!--    The programme is attached.</p>-->
        </div>
       </div>
    </div>
    <div class="col-xl-3 col-lg-3 col-md-6">
        <aside>
            <div class="list-parent">

<?php 
       $cat = 15;

    // Check if it is page only
    if ( is_page() || is_single()) {
        $args=array(
            'cat'  =>  $cat,
            'order'  =>  DESC,
            'orderby'  =>  rand,
            'posts_per_page'  =>  9999,
            );

        $my_query = null;

        $my_query = new WP_Query($args);

        if( $my_query->have_posts() ) {


            while ($my_query->have_posts()) : $my_query->the_post(); ?>

               <div class="list-body">
                <div class="list-icon-box">
                    <i class="bi bi-chevron-right"></i>
                </div>
                <a href="#" class="list-content-box">
                    <h5><?php echo date('j F Y', strtotime(get_the_date())); ?></h5>
                    <p><?php the_title(); ?></p>
                </a>
            </div> 
            <?php

            endwhile;

        }
        wp_reset_query();
    }
    
    
    
    ?>

            <!--<div class="list-body">-->
            <!--    <div class="list-icon-box">-->
            <!--        <i class="bi bi-chevron-right"></i>-->
            <!--    </div>-->
            <!--    <a href="#" class="list-content-box">-->
            <!--        <h5>26 Jul 2018</h5>-->
            <!--        <p>shri krishan janmashtami mahotsav</p>-->
            <!--    </a>-->
            <!--</div> -->
                       
            <!--<div class="list-body">-->
            <!--    <div class="list-icon-box">-->
            <!--        <i class="bi bi-chevron-right"></i>-->
            <!--    </div>-->
            <!--    <a href="#" class="list-content-box">-->
            <!--        <h5>26 Jul 2018</h5>-->
            <!--        <p>SRI SAI AMRIT KATHA FROM 7TH SEPTEMBER TO 9TH SEPTEMBER 2014</p>-->
            <!--    </a>-->
            <!--</div> -->

            </div>
        </aside>
    </div>
</div>

</div>
	</section>

<?php
//do_action( 'storefront_sidebar' );
get_footer();
?>
   