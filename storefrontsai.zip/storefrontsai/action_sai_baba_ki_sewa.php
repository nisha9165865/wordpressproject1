<?php
session_start();
include('config.php');
 
$name = $_POST['name'];
$_SESSION['name']= $name;
$amount_pay =$_POST['amount_pay'];
$_SESSION['amount_pay'] = $amount_pay;
$phone = $_POST['phone'];
$_SESSION['phone']= $phone;
$email = $_POST['email'];
$_SESSION['email']= $email;
$payment_status = "0";
//  print_r($_POST['interest_type']);
//  die();

$form_type= $_POST['form_type'];
if($_POST['address']==""){
    $_SESSION['address']= "noida";
}else {
   $_SESSION['address']= $_POST['address']; 
}
$address = $_SESSION['address'];
// $address= $_POST['address'];
// $_SESSION['address']= $address;
date_default_timezone_set('Asia/Kolkata'); // Set to Indian Standard Time
$added_on = date('Y-m-d H:i:s');
$form_type = $_POST['form_type'];
$sewa_category = $_POST['sewa_category'];
$conn->set_charset("utf8");
if(!empty($_POST['email']))
{
    $sql = "INSERT INTO sai_baba_ki_sewa (name,phone,email,address,amount_pay,form_type,sewa_category,payment_status,added_on)
            VALUES ('$name','$phone','$email','$address','$amount_pay','$form_type','$sewa_category','$payment_status','$added_on')";
           
            if ($conn->query($sql) === TRUE) 
            {
               echo"sent";
                    
            }
            
            else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
    
    
    
}else{
    echo "Data Not Found..";
    die();
}

?>