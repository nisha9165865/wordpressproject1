<?php 
error_reporting(1);
include('../../config.php');
// include('../header.php');
if($_POST['status']=="success"){
    $email = $_POST['email'];
    // $easepayid = $_POST['easepayid'];
    $txnid = $_POST['txnid'];
    $query = "SELECT id FROM givethegiftform WHERE email='$email' ORDER BY id DESC LIMIT 0,1";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $rowid = mysqli_fetch_assoc($result);

        if ($rowid) {
            $id = $rowid['id'];
            

            $updateQuery = "UPDATE givethegiftform SET payment_status ='1', payment_id = '$txnid' WHERE id = '$id'";
            $updateResult = mysqli_query($conn, $updateQuery);
            
               $query1 = "SELECT * FROM givethegiftform WHERE email='$email' AND id='$id'";
                $result1 = mysqli_query($conn, $query1);
                $row = mysqli_fetch_assoc($result1);
            if ($updateResult) {
               $admin_html .='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                <html xmlns="http://www.w3.org/1999/xhtml">
                                <head>
                                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                <title>Sai Mandir Noida</title>
                                </head>
                                <body style="margin:0px;">
                                <div style="background: #fff; border: solid 1px #ddd; max-width: 650px; width: 100%; margin: 0 auto; background-color: #fff;">
                                <table width="100%" style="width:100%; border:none;">
                                <tr >
                                    <td style="border-bottom:solid 1px #ddd; text-align:center;"><a href="" target="_blank"> <img src="" alt="Logo"  style="margin-bottom: 8px; height: 100px; color: #FFF;"/> </a></td>
                                </tr>
                                        
                                <tr>
                                    <td style="padding:10px;border:solid 1px #ddd; text-align:center;"><b>Dear Admin,</b></td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: solid 1px #ddd; padding-bottom: 20px; background-color: #f3f3f3;"><div align="center">
                                       <table border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: #fff;">
                                                    <tr>
                                                      <td><table border="0" cellspacing="1" cellpadding="0" width="100%">
                                                         <tr>
                                                            <td valign="top"><p><strong>Name: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['name'].'</p></td>
                                                          </tr>
                                                           <tr>
                                                            <td valign="top"><p><strong>Phone number: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['phone'].'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Email: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['email'].'</p></td>
                                                          </tr>
                                                         
                                                          <tr>
                                                            <td valign="top"><p><strong>Amount: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['amount_pay'].'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Transaction Id: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['payment_id'].'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Submit Date: </strong></p></td> 
                                                            <td valign="top"><p>'.$row['added_on'].'</p></td>
                                                          </tr>

                                                        </table></td>
                                                    </tr>
                                                  </table>
                                                </div></td>
                                            </tr>
                                          </table>
                                        </div>
                                        </body>
                                        </html>';
                                        
                $user_html .='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                    <html xmlns="http://www.w3.org/1999/xhtml">
                                    <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                    <title>Sai Mandir Noida</title>
                                    </head>
                                    <body style="margin:0px;">
                                    <div style="background: #fff; border: solid 1px #ddd; max-width: 650px; width: 100%; margin: 0 auto; background-color: #fff;">
                                      <table width="100%" style="width:100%; border:none;">
                                            <tr >
                                            <td style="border-bottom:solid 1px #ddd; text-align:center;"><a href="" target="_blank"> <img src="" alt="Logo"  style="margin-bottom: 8px; height: 100px; color: #FFF;"/> </a></td>
                                        </tr>
                                    
                                        <tr>
                                        </tr>
                                        <tr>
                                          <td style="border-bottom: solid 1px #ddd; padding-bottom: 20px; background-color: #f3f3f3;"><div align="center">
                                              <table border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: #fff;">
                                                <tr>
                                                  <td>
                                                    <div style="padding-uper: 20px;" align="center" ><p><strong><h2>Your form has been submitted successfully.
                                                    </h2></strong></p></div>
                                                    
                                              
                                                    </td>
                                                </tr>
                                              </table>
                                            </div></td>
                                        </tr>
                                      </table>
                                    </div>
                                    </body>
                                    </html>';
                                    
                require '../../PHPMailer-master/PHPMailerAutoload.php';
                $usermmail = $_POST["email"];
                 $mail = new PHPMailer;
                    // $mail->smtpConnect(
                    //     array(
                    //         "ssl" => array(
                    //             "verify_peer" => false,
                    //             "verify_peer_name" => false,
                    //             "allow_self_signed" => true
                    //         )
                    //     )
                    // );
                    $mail->isSMTP();                                
                    $mail->Host = 'cometbharat.icewarpcloud.in';
                    $mail->SMTPAuth = true;                               
                    $mail->Username ='info@cometbharat.com';                
                    $mail->Password = 'huLra#gl4'; 
                    $mail->SMTPSecure = 'tls';   
                    $mail->Port = 587;                                   
                   // $mail->SMTPDebug = 3;
                    //$mail->addreplyto('book@justairports.com', 'Information Book');
                    $mail->setFrom("info@cometbharat.com","GIVE THE GIFT OF EDUCATION");
                    $mail->isHTML(true);
                    $mail->Subject = $form_type;  
                    $mail->Body =  $admin_html;
                    $mail->AddAddress("nisha@v2web.in");
                    // $mail->AddCC("");
                    $mail->addReplyTo($usermmail, 'Interested');
                    $result =  $mail->Send();
                    
                    if($result)
                    {
                        $user_mail = new PHPMailer;
                        // $user_mail->smtpConnect(
                        //     array(
                        //         "ssl" => array(
                        //             "verify_peer" => false,
                        //             "verify_peer_name" => false,
                        //             "allow_self_signed" => true
                        //         )
                        //     )
                        // );
                        $user_mail->isSMTP();                                
                        $user_mail->Host = 'cometbharat.icewarpcloud.in';
                        $user_mail->SMTPAuth = true;                               
                        $user_mail->Username ='info@cometbharat.com';                
                        $user_mail->Password = 'huLra#gl4'; 
                        $user_mail->SMTPSecure = 'tls';   
                        $user_mail->Port = 587;                                   
                       // $user_mail->SMTPDebug = 3;
                        //$user_mail->addreplyto('book@justairports.com', 'Information Book');
                        $user_mail->setFrom("info@cometbharat.com","GIVE THE GIFT OF EDUCATION");
                        $user_mail->isHTML(true);
                        $user_mail->Subject = $form_type;  
                        $user_mail->Body =  $user_html;
                        $user_mail->AddAddress($usermmail,$name);
                        $resultdata =  $user_mail->Send();
                        if($resultdata)
                        { ?>
            <section class="thankyou_sec sec_padding">
                <div class="container">
                <div id="dvsuccess" class="alert alert-success">
                    <table style="width:100%;">
                        <tbody>
                                <tr>
                                <td colspan="2">
                                <div class="alert alert-success" style="background-color:mediumseagreen;color:white;border-radius:4px;text-wrap:inherit">
                                Thank you for your donation towards providing education to deserving children  of India. We will send you 80G donation receipt so you can get Income Tax Benefit.  
                                </div>
                                </td>
                                </tr>
                                <tr>
                                <td>Donation ID:</td>
                                <td><span id="lblID"><?php echo $txnid ?></span></td>
                                </tr>
                                <tr>
                                <td>Payment Status:</td>
                                <td><span id="lvlSstatus">success</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
                       <?php  } else {
                            echo "not sent";
                        }
                        
                    } else {
                        echo "not sent";
                    }
                    
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            
        } else {
           echo "Data Not Found..";
        }
        

    }
}


?>
<?php
define('WP_USE_THEMES', true);
get_template_part( '../../footer' ); 
require('public_html/sai-mandir-noida/wp-content/themes/wp-content/themes/storefront/header.php');

include('public_html/sai-mandir-noida/wp-content/themes/wp-content/themes/storefront/footer.php');


?>
<?php
require('https://devupwork.v2web.in/sai-mandir-noida/wp-content/themes/storefront/wp-blog-header.php');
get_header();
?>