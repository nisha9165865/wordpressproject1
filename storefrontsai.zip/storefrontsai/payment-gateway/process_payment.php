<?php

// Include necessary configurations or libraries

// Retrieve form data
$amount = $_POST['amount'];
// Retrieve other payment details from the form

// Set up API credentials (Replace with your actual credentials)
$merchantKey = "10PBP71ABZ2";
$salt = "MPMHMHGX7Y";

// Generate checksum (You'll need to implement the checksum logic as per Easebuzz documentation)
$checksum = generateChecksum($merchantKey, $amount, $salt); 

// Redirect to Easebuzz payment page with necessary parameters
$redirectUrl = "https://test.easebuzz.in/payment/initiateLink";
$redirectUrl .= "?key=" . $merchantKey;
$redirectUrl .= "&amount=" . $amount;
$redirectUrl .= "&txnid=" . uniqid(); // Unique transaction ID
$redirectUrl .= "&productinfo=Product"; // Product information
$redirectUrl .= "&firstname=User"; // User's first name
$redirectUrl .= "&email=user@example.com"; // User's email
$redirectUrl .= "&surl=" . urlencode("https://dev.justairports.com/pnb-payment-gateway-test/success.php"); // Success URL
$redirectUrl .= "&furl=" . urlencode("https://dev.justairports.com/pnb-payment-gateway-test/failure.php"); // Failure URL
$redirectUrl .= "&hash=" . $checksum; // Checksum value

// Redirect user to Easebuzz payment page
header("Location: " . $redirectUrl);
exit;

// Function to generate checksum (This is a basic example, refer to Easebuzz documentation for detailed checksum generation logic)
function generateChecksum($merchantKey, $amount, $salt) {
    $params = $merchantKey . "|" . $amount . "|" . $salt;
    return hash('sha512', $params);
}

?>
