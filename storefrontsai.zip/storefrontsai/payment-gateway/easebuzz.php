<?php
$referring_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
$parsed_url = parse_url($referring_url);
$domain_name = isset($parsed_url['host']) ? $parsed_url['host'] : '';
// print_r($parsed_url['path']);
// die();
// $_SESSION['referring_url'] = $domain_name; 
session_start();
ob_start();
include_once('easebuzz-lib/easebuzz_payment_gateway.php');
// print_r($_SESSION); die();
$MERCHANT_KEY = "PD00NNV8UY";
$SALT = "MPMHMHGX7Y";         
$ENV = "prod";   // set environment name

// $MERCHANT_KEY = "10PBP71ABZ2";
//     $SALT = "ABC55E8IBW";         
//     $ENV = "test";   // set enviroment name

if($parsed_url['path'] =="/sai-mandir-noida/donate/")
{
    $surl = "https://devupwork.v2web.in/sai-mandir-noida/donate-success/";
    // $surl = "https://devupwork.v2web.in/sai-mandir-noida/wp-content/themes/storefront/payment-gateway/success/donatepayment-success.php";
    $furl = "https://devupwork.v2web.in/sai-mandir-noida/donatepayment-failure";
}else if($parsed_url['path'] =="/sai-mandir-noida/online-pooja/")
{
    $surl = "https://devupwork.v2web.in/sai-mandir-noida/onlinepayment-success";
    $furl = "https://devupwork.v2web.in/sai-mandir-noida/onlinepayment-failure/";
}else if($parsed_url['path'] =="/sai-mandir-noida/")
{
     $surl = "https://devupwork.v2web.in/sai-mandir-noida/sai_baba_ki_sewa-success/";
    $furl = "https://devupwork.v2web.in/sai-mandir-noida/sai_baba_ki_sewa-failure/";
}else{
    
}


$easebuzzObj = new Easebuzz($MERCHANT_KEY, $SALT, $ENV);
// if($_SESSION['address']==""){
//     $address= "noida";
// } else {
//     $address=$_SESSION['address'];
// }

// Generate a unique transaction ID using timestamp
$txnid = "TXN" . time();  // Using the current timestamp to generate a unique txnid
$postData = array ( 
  "txnid" => $txnid, 
  "amount" =>number_format(round((float)$_SESSION['amount_pay'], 2), 2, '.', ''), 
  //"amount" =>'1.00', 
  "firstname" => $_SESSION['name'], 
  "email" => $_SESSION['email'], 
  "phone" => $_SESSION['phone'], 
 "productinfo" => "Laptop", 
  "surl" => $surl, 
  "furl" => $furl, 
  "udf1" => "aaaa", 
  "udf2" => "aaaa", 
  "udf3" => "aaaa", 
  "udf4" => "aaaa", 
  "udf5" => "aaaa", 
  "address1" => $_SESSION['address'], 
  "address2" => "aaaa", 
  "city" => "aaaa", 
  "state" => "aaaa", 
  "country" => "aaaa", 
  "zipcode" => "123123" 
);

$result = $easebuzzObj->initiatePaymentAPI($postData);
print_r($result);
ob_end_flush();
session_destroy();
?>
