<?php get_header(); ?>

 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
            <!-- Banner-->         
         
             <!-- About-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
      <div class="row g-4">
    <div class="col-12">
        <div class="sec_title mb-4">
            <h1 class="sec_heading mb-2">Photo Gallery</h1>            
            <div class="section-border"><span></span></div>
        </div>
        <h3 class="sub-title">Total Albums: <?php echo count(get_categories( array('taxonomy' => 'gallery_category','type' => 'gallery','orderby' => 'ID','order'   => 'DESC'))); ?></h3>
    </div>
    <?php
    $j=0;
 $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
  $posts_per_page = 12;
$offset = ($posts_per_page * $paged) - 12 ;
    $ccc = get_categories(array('taxonomy' => 'gallery_category','type' => 'gallery','orderby' => 'ID','order'   => 'DESC', 'number' => $posts_per_page,
'offset' => $offset,
'posts_per_page' => 12,
'paged' => $paged));
// $ccc = get_categories('taxonomy=gallery_category&type=gallery&orderby=ID&order=DESC');
// print_r($ccc); die();
    $args = array(
   'parent' => 0,
   'hide_empty' => 0
 );

$categories = get_categories( array('taxonomy' => 'gallery_category','type' => 'gallery','orderby' => 'ID','order'   => 'DESC'));
$cat =  ceil(count( $categories )/12);
foreach($ccc as $cccData){  ?> 
<?php 
$j++;
 $thumbnail_id = get_term_meta( $cccData->term_id, 'image_category_image', true );
 $image_id = wp_get_attachment_url( $thumbnail_id );
$current_cat_id  = $cccData->term_id;
$argsPost = [
    'orderby' => 'ID',
'order' => 'ASC',
    'post_type' => 'gallery',
    'tax_query' => [
        [
            'taxonomy' => 'gallery_category',
            'terms' =>$current_cat_id,
            'include_children' => false
        ],
    ],
];
$myposts = get_posts($argsPost);
$ccunt = new WP_Query( $argsPost);
?>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="<?php echo site_url()?>/photo-gallery-list/?data=<?php echo base64_encode($current_cat_id); ?>&&catName=<?php echo base64_encode($cccData->name); ?>">
        <div class="gallery-box">
            <img src="<?php echo $image_id; ?>" alt="img">
            <div class="gallery-content-flex">
                <div class="batch"></div>
                <div class="gallry-content">
                    <h4><?php echo $cccData->name; ?></h4>
                    <p>Total Photos: <?php echo  (int)$ccunt->post_count; // count($myposts); ?></p>
                    <p>Last Updated: <?php echo  date('j F Y', strtotime(get_term_meta($cccData->term_id, 'updated_at', TRUE))); ?></p>  
                </div>
            </div>
        </div>
        </a>
    </div>
<?php }  ?>
 <div class="qodef-custom-pagination">
<?php echo paginate_links( array(
'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
'total' => $cat,
'current' => max( 1, get_query_var('paged') ),
'prev_text' => '<span aria-label="' . esc_attr__( 'Previous page', 'textdomain' ) . '">' . esc_html__( '&laquo;', 'textdomain' ) . '</span>',
'next_text' => '<span aria-label="' . esc_attr__( 'Next page', 'textdomain' ) . '">' . esc_html__( '&raquo;', 'textdomain' ) . '</span>'
) ); ?>
</div>
<!--  <nav aria-label="...">-->
<!--  <ul class="pagination">-->
<!--    <li class="page-item disabled">-->
<!--      <span class="page-link">Previous</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">1</a></li>-->
<!--    <li class="page-item active" aria-current="page">-->
<!--      <span class="page-link">2</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">3</a></li>-->
<!--    <li class="page-item">-->
<!--      <a class="page-link" href="#">Next</a>-->
<!--    </li>-->
<!--  </ul>-->
<!--</nav>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/diwali.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Diwali -2016</h4>-->
    <!--                <p>Total Photos: 9</p>-->
    <!--                <p>Last Updated: 07 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/janmastmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Janmashtmi -2016</h4>-->
    <!--                <p>Total Photos: 25</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/lohari.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Lohri -2016</h4>-->
    <!--                <p>Total Photos: 15</p>-->
    <!--                <p>Last Updated: 20 Feb 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mahashivratri.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mahashivratri - 2016</h4>-->
    <!--                <p>Total Photos: 11</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mass-Marriage.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mass-Marriage -2016</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Ram-Navmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Ram Navmi -2016</h4>-->
    <!--                <p>Total Photos: 31</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Samadhi-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Samadhi Day -2016</h4>-->
    <!--                <p>Total Photos: 09</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Shri-Sai-Katha.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Shri Sai Katha - 2016</h4>-->
    <!--                <p>Total Photos: 29</p>-->
    <!--                <p>Last Updated:  03 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Sthapna-Diwas.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Sthapna Diwas -2016</h4>-->
    <!--                <p>Total Photos: 40</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Teacher-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Teacher Day -2016</h4>-->
    <!--                <p>Total Photos: 22</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/VIP-Guest-Visit.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>VIP Guest Visit</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->




</div>


                 </div>
             </section>
              <!-- About-close -->
        </main>
        
        <?php
get_footer();