 // Anchor Smooth Scroll
 jQuery(function ($) {
    $('a[href*="#"]:not([href="#"])').click(function () {
        var target = $(this.hash);
        $('html,body').stop().animate({
            scrollTop: target.offset().top - 120
        }, 'linear');
    });
    if (location.hash) {
        var id = $(location.hash);
    }

    $(window).on('load', function () {
        if (location.hash) {
            $('html,body').animate({ scrollTop: id.offset().top - 120 }, 'linear')
        };
    });
});



 // banner-slider
 $('.banner-slider').owlCarousel({
  loop: true,
  autoplay:true,
  margin: 10,
  nav: false,
  dots: true,
  autoplayTimeout: 4000,
  animateOut: 'fadeOut',
  responsive: {
      0: {
          items: 1
      },
      600: {
          items: 1
      },
      1000: {
          items: 1
      }
  }
 
})

  AOS.init();

  Fancybox.bind("[data-fancybox]", {
    // Your custom options
});




