<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package storefront
 */

?>
        <!-- footer-start -->
        <footer class="sec_padding">
          <div class="container">
            <div class="row g-5">
                 <div class="col-md-12">
                    <div class="footer_wrapper text-center">
                        <a href="<?= site_url('/');?>"><img src="<?= get_field("headerlogo",46);?>" alt="logo"><h5><?= get_field("footerlogotitle",46);?></h5></a>
                    </div>
                 </div>  
                 
                 <div class="col-md-12">
    <div class="telephone-row">
    <!--    <div class="items">-->
    <!--         <div class="text-center">-->
    <!--    <h2 class="sec_heading">TELEPHONE SEWA</h2>-->
    <!--</div>-->
    <!--    </div>-->
        <div class="items">
            <div class="telephone-box">
                <h5><?=get_field("phonetitle1",46);?></h5>
                <a href="tel:<?=get_field("phonenumber1",46);?>" ><?=get_field("phonenumber1",46);?></a>
            </div>
        </div>
        <div class="items">
            <div class="telephone-box">
                <h5><?=get_field("phonetitle2",46);?></h5>
                <a href="tel:<?=get_field("phonenumber2",46);?>" ><?=get_field("phonenumber2",46);?></a>
            </div>
        </div>
        <div class="items">
            <div class="telephone-box">
                <h5><?=get_field("phonetitle3",46);?></h5>
                <a href="tel:<?=get_field("phonenumber3",46);?>" ><?=get_field("phonenumber3",46);?></a><a href="tel:<?=get_field("phonenumber4",46);?>" >,<?=get_field("phonenumber4",46);?></a><a href="tel:<?=get_field("phonenumber5",46);?>" >,<?=get_field("phonenumber5",46);?></a>
            </div>
        </div>
        <div class="items">
            <div class="telephone-box">
                <h5><?=get_field("phonetitle4",46);?></h5>
                <a href="tel:<?=get_field("phonenumber6",46);?>" ><?=get_field("phonenumber6",46);?></a>
            </div>
        </div>
    </div>
</div>
                 
                 <div class="col-xl-8 col-lg-6 col-md-12">
                    <div class="footer_wrapper">
                        <h4>Quick Links</h4>
                        <ul class="m-0">
                             <?php
                  	$obj = wp_get_nav_menu_object('footer');
                  	$items = wp_get_nav_menu_items($obj->term_id);
                  	// echo "<pre>";
                  	// 	print_r($items);
                  	foreach($items as $item){
                  	?>
						<li><a href="<?= $item->url;?>"><?= $item->title;?></a></li>
						<?php
                  	}
                  	?>
                            <!--<li><a href="#">Home</a></li>-->
                            <!--<li><a href="#">Future Programs</a></li>-->
                            <!--<li><a href="#">About Us</a></li>-->
                            <!--<li><a href="#">Your Participation</a></li>-->
                            <!--<li><a href="#">Management</a></li>-->
                            <!--<li><a href="#">Upcoming Events</a></li>-->
                            <!--<li><a href="#">Sai Patrika</a></li>-->
                            <!--<li><a href="#">Photogallery</a></li>-->
                            <!--<li><a href="#">Video Gallery</a></li>-->
                            <!--<li><a href="#">Downloads</a></li>-->
                            <!--<li><a href="#">Festival</a></li>-->
                            <!--<li><a href="#">News</a></li>-->
                        </ul>
                    </div>
                 </div> 
                   
                 <div class="col-xl-4 col-lg-6 col-md-12">
                    <div class="footer_wrapper">
                        <h4>NEWSLETTER SIGN UP</h4>
                        <form method="post" action="https://devupwork.v2web.in/sai-mandir-noida/?na=s">
                            <input type="hidden" name="nlang" value="">
                            <input type="email" id="tnp-1" name="ne" id="email" value="" placeholder="Your Email Address"required>
                            <button type="submit">Submit</button>
                        </form>
                    </div>
                 </div>    
          </div>  
          <div class="row  copywrite-row">
            <div class="col-xl-8 col-md-12 copyright">
                <p>Copyright © 2012 Shri Sai Samiti. All Right Reserved. <a href="terms-and-conditions/">Terms And Conditions</a> | <a href="privacy-policy/">Privacy Policy</a></p>
              </div>
              <div class="col-xl-4 col-md-12 copyright">
           <h6>Donated By <a href="https://v2web.in/" target="_blank">V2web</a></h6>
              </div>
          </div>        
          </div>
        </footer>
        <!-- footer-close -->

       
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/jquery.min.js"></script>
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/fancybox.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/owl.carousel.min.js"></script>
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/SmoothScroll.min.js"></script>
        <script src="<?= get_stylesheet_directory_uri();?>/sai_assets/js/custom.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
        
       <?php wp_footer(); ?>
       <script>(function($){ $(document).ready(function(){ $('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { event.preventDefault(); event.stopPropagation(); $(this).parent().siblings().removeClass('open'); $(this).parent().toggleClass('open'); }); }); })(jQuery);</script>
    </body>
</html>