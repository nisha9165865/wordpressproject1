<?php
session_start();
include('config.php');
 
$name = $_POST['name'];
$_SESSION['name']= $name;
$amount_pay =$_POST['amount_pay'];
$_SESSION['amount_pay'] = $amount_pay;
$phone = $_POST['phone'];
$_SESSION['phone']= $phone;
$email = $_POST['email'];
$_SESSION['email']= $email;

//  print_r($_POST['interest_type']);
//  die();

$address = $_POST['address'];
$_SESSION['address'] = $address;
$purpose =$_POST['purpose'];
$payment_status = "0";
date_default_timezone_set('Asia/Kolkata'); // Set to Indian Standard Time
$added_on = date('Y-m-d H:i:s');

if(!empty($_POST['email']))
{
    $sql = "INSERT INTO onlinepoojaform (name,email,phone,amount_pay,address,purpose,payment_status,added_on)
            VALUES ('$name','$email','$phone','$amount_pay','$address','$purpose','$payment_status','$added_on')";
            
            if ($conn->query($sql) === TRUE) 
            {
               echo"sent";
                    
            }
            
            else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
    
    
    
}else{
    echo "Data Not Found..";
    die();
}

?>