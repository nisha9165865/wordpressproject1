<?php get_header();?>
  <main>
                   <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>  
         
             <!-- About-start-->
             <section class="sec_padding contact_sec animate-bg" data-aos="fade-up">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
                     <div class="row g-5 form-row">                         
                         <div class="col-xl-4 col-lg-4 col-md-12">
                             <div class="left-contact">
                                 <div class="contact_heading">
                                    <h4><?=get_field("locationtitle",31);?></h4>
                                 </div>
                                 <div class="address-box mb-35">
                                        <i class="bi bi-geo-alt-fill"></i>
                                    <div class="address-text">
                                         <span class="label">Address</span>
                                         <a href="#"><?=get_field("locationaddress",31);?></a>
                                    </div>
                                </div>
                                <div class="address-box mb-35">
                                    <i class="bi bi-telephone-fill"></i>
                                <div class="address-text">
                                     <span class="label">Call Us</span>
                                     <a href="tel:<?=get_field("phone1",31);?>"><?=get_field("phone1",31);?>, </a>
                                     <a href="tel:<?=get_field("phone2",31);?>"><?=get_field("phone2",31);?>, </a>
                                     <a href="tel:<?=get_field("phone3",31);?>"><?=get_field("phone3",31);?>, </a>
                                     <a href="tel:<?=get_field("phone4",31);?>"><?=get_field("phone4",31);?></a>
                                </div>
                            </div>

                            <div class="address-box mb-35">
                                <i class="bi bi-envelope-fill"></i>
                            <div class="address-text">
                                 <span class="label">EMail Id</span>
                                 <a href="mailto:<?=get_field("email1",31);?>"><?=get_field("email1",31);?>, </a>
                                 <a href="mailto:<?=get_field("email2",31);?>"><?=get_field("email2",31);?>, </a>
                                 <a href="mailto:<?=get_field("email3",31);?>"><?=get_field("email3",31);?> </a>
                            </div>
                        </div>
                               
                             </div>
                         </div>
                         <div class="col-xl-8 col-lg-8 col-md-12">
                            <div class="right-contact">
                                <div class="contact_heading">
                                    <h4><?=get_field("formtitle",31);?></h4>
                                 </div>
                                 <?= do_shortcode('[contact-form-7 id="ab0c112" title="Contact form 1"]');?>
                                <!--<form class="row g-4">-->
                                <!--    <div class="col-lg-6">-->
                                <!--        <div class="form-group">-->
                                <!--            <input type="text" placeholder="First Name" class="form-control" required>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="col-lg-6">-->
                                <!--        <div class="form-group">-->
                                <!--            <input type="text" placeholder="Last Name" class="form-control">-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="col-lg-6">-->
                                <!--        <div class="form-group">-->
                                <!--            <input type="email" placeholder="E-mail" class="form-control">-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="col-lg-6">-->
                                <!--        <div class="form-group">-->
                                <!--            <input type="text" placeholder="Phone Number" class="form-control">-->
                                <!--        </div>-->
                                <!--    </div>                                    -->
                                <!--    <div class="col-lg-12">-->
                                <!--        <div class="form-group">-->
                                <!--            <textarea  placeholder="Your message Here" rows="5" ></textarea>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="col-12">-->
                                <!--        <a href="#" class="btn theme-btn">Submit<i class="fa fa-angle-right" aria-hidden="true"></i>-->
                                <!--        </a>-->
                                <!--    </div>-->
                                <!--</form>-->
                            </div>
                        </div>
                     </div>
                     
                     <div class="right-contact"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3504.1602532097886!2d77.35367347632095!3d28.564950175701608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5ea87d8e005%3A0xb1a35f9614784384!2sShri%20Sai%20Samiti%20Noida(Shirdi%20Sai%20Baba%20Mandir)!5e0!3m2!1sen!2sin!4v1705490164826!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
                 </div>
             </section>
              <!-- About-close -->
        </main>
        <?php get_footer();?>