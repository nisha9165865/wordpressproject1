<?php
get_header(); ?>

<main>
    <!-- Banner-slider -->
    <div class="banner_sec donate-slider">
        <!--<div class="banner-slider owl-carousel owl-theme">-->
        <!--    <div class="item">-->
        <!--        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/d-banner1.webp" alt="img">-->
        <!--    </div>-->
        <!--    <div class="item">-->
        <!--        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/d-banner2.webp" alt="img">-->
        <!--    </div>-->
        <!--</div>-->
        
       <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
      <?php
        $slider = get_field('slider',117);
        $firstItem = true;
        foreach($slider as $slider)
        {
            // echo "<pre>";
            // print_r($delhi_and_ncr['googlemapurl']);
        ?>
      <div class="carousel-item <?= $firstItem ? 'active' : ''; ?>">
      <img src="<?= $slider['slider_image']; ?>" alt="img">
    </div>
    <!--<div class="carousel-item ">-->
    <!--  <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/d-banner1.webp" alt="img">-->
    <!--</div>-->
    <?php
    $firstItem = false;
    }
    ?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        
        
        
        
        

        <div class="donate-div">
            <div class="container">
                <div class="row donate-row">
                    <div class="col-xl-7 col-md-12  col-sm-12 donate-col"></div>
                    <div class="col-xl-5 col-md-12  col-sm-12">
                        <div class="donate_box">
            <div class="donate_header">
                <h6><?= get_field("title1",117);?></h6>
                <h3><?= get_field("title2",117);?></h3>
            </div>
            <div class="donate_form mCustomScrollbar" data-mcs-theme="dark">
                <p><i class="bi bi-lock-fill"></i> <?= get_field("title3",117);?></p>
                    <form class="donate row g-3" method="POST">
                    <div class="col-6">
                        <div class="donate-input" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <a href="javascript:void(0)" type="button" class="btn">
                                <span><i class="bi bi-currency-rupee"></i> 501</span> Donate
                            </a>
                            <input name="amt501" type="hidden" value="501" class="interest_btn"/>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="donate-input" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <a href="javascript:void(0)" type="button" class="btn">
                                <span><i class="bi bi-currency-rupee"></i> 2100</span> Donate
                            </a>
                            <input name="amt2100" type="hidden" value="2100" class="interest_btn"/>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="donate-input" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <a href="javascript:void(0)" type="button" class="btn">
                                <span><i class="bi bi-currency-rupee"></i> 1100</span> Donate
                            </a>
                            <input name="amt1100" type="hidden" value="1100" class="interest_btn"/>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="donate-input" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <a href="javascript:void(0)" type="button" class="btn">
                                <span><i class="bi bi-currency-rupee"></i> 5100</span> Donate
                            </a>
                            <input name="amt5100" type="hidden" value="5100" class="interest_btn"/>
                        </div>
                    </div>
                    <div class="col-12">
                            <div class="form-group">
                                <i class="bi bi-currency-rupee"></i>
                                <input name="otheramount" type="text" placeholder="Other Amount" class="interest_btn"/>
                                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Donate</button>
                            </div>
                    </div>
                    </form>

                <div class="donation_help">
                    <h5><i class="bi bi-chat-heart-fill"></i> <?= get_field("title4",117);?></h5>
                    <p><?= get_field("content1",117);?></p>
                    <p class="mt-3 tax_text"><i class="bi bi-journal-medical"></i><?= get_field("content2",117);?></p>
                    <img src="<?= get_field("image",117);?>" alt="img" />
                    <p><?= get_field("content3",117);?></p>
                </div>
            </div>
        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner-slider-close -->

    <!-- donate-about -->
    <section class="sec_padding donate_sec">
        <div class="container">
            <div class="donate-about">
                <div class="sec_title text-center mb-4">
                    <h2 class="sec_heading mb-2"><?= get_field("donatetitle",117);?></h2>
                    <p class="color"><?= get_field("donatecontent1",117);?></p>
                    <div class="section-border"><span></span></div>
                </div>
                <p><iframe width="100%" height="390" src="<?= get_field("youtubevedio",117);?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" style="
    height: 220px;
    float: right;
    width: 500px;
    box-shadow: 10px 11px #adaaaa;
"></iframe>
                    <?= get_field("donatecontent2",117);?>
                </p>
                <?= get_field("donatecontent3",117);?>
                
            </div>
           
        </div>
    </section>
    <!-- donate-about-close -->

    <!-- booksec -->
    <section class="sec_padding book_sec">
        <div class="container">
            <div class="sec_title text-center">
                <h2 class="sec_heading mb-2"><?= get_field("givethegifttitle",117);?></h2>
                <p class="color"><?= get_field("givethegifttitle2",117);?></p>
                <div class="section-border"><span></span></div>
            </div>
                <div class="book-row row g-4 mt-4 align-items-center justify-content-center">
                    <?php
                            $interested = get_field('interested',117);
                            foreach($interested as $interested)
                            {
                                // echo "<pre>";
                                // print_r($delhi_and_ncr['googlemapurl']);
                            ?>
                <div class="col-xl-4 col-lg-6 col-md-12">
                        <div class="book-body">
                               <div class="bg-image hover-zoom ripple rounded ripple-surface">
                                        <img src="<?= $interested['image']; ?>" alt="img">
                                        <a href="#!">
                                            <div class="hover-overlay">
                                                <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>
                                            </div>
                                        </a>
                                    </div>
                                    <h5 class="interested_title"><?= $interested['title']; ?></h5>
                                   <small><?= $interested['smallcontent']; ?></small>
                                    <p >
                                        <?= $interested['content']; ?>
                                    </p>
                                    <div class="d-flex flex-row align-items-center mb-1 justify-content-between">
                                        <h4 class="mb-1 me-1"><i class="bi bi-currency-rupee"></i><?= $interested['price']; ?></h4>
                                   <a href="javascript:void(0)" class="btn theme-btn clsListAmount" list-amount="<?= $interested['amount']; ?>">Interested</a>
                                           <!--<a href="javascript:void(0)" class="btn theme-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">Interested</a>-->
                                    </div>
                                    <div class="shape-one"></div>
                                    <div class="shape-two"></div>
                        </div>
                </div>
                   <?php
                            }
                            ?>
                <!--<div class="col-xl-4 col-lg-6 col-md-12">-->
                <!--        <div class="book-body">-->
                <!--                 <div class="bg-image hover-zoom ripple rounded ripple-surface">-->
                <!--                        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/book3.webp" alt="img">-->
                <!--                        <a href="#!">-->
                <!--                            <div class="hover-overlay">-->
                <!--                                <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>-->
                <!--                            </div>-->
                <!--                        </a>-->
                <!--                    </div>-->
                <!--                <h5>Support Free Education and Ignite Change</h5>-->
                                   <!--<small>Gift free education and impact young lives today!</small>-->
                <!--                    <p >-->
                <!--                        Help us build the dreams of thousands of young children by donating to transform their lives. Your kind gesture and support will permanently remain with us in our School Archives and annual publication.-->
                <!--                    </p>-->
                <!--               <div class="d-flex flex-row align-items-center mb-1 justify-content-between">-->
                <!--                        <h4 class="mb-1 me-1"><i class="bi bi-currency-rupee"></i> 1.0 Lakhs</h4>-->
                <!--                    <a href="javascript:void(0)" class="btn theme-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">Interested</a>-->
                <!--                    </div>-->
                <!--                    <div class="shape-one"></div>-->
                <!--                    <div class="shape-two"></div>-->
                <!--        </div>-->
                <!--</div>-->
                <!--<div class="col-xl-4 col-lg-6 col-md-12">-->
                <!--        <div class="book-body">-->
                <!--                <div class="bg-image hover-zoom ripple rounded ripple-surface">-->
                <!--                        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/book3.webp" alt="img">-->
                <!--                            <div class="hover-overlay">-->
                <!--                                <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>-->
                <!--                            </div>-->
                <!--                        </a>-->
                <!--                    </div>-->
                <!--               <h5>Support Our Cause and Make a Difference Today</h5>-->
                                   <!--<small>Gift free education and impact young lives today!</small>-->
                <!--                    <p >-->
                <!--                        Help us build the dreams of thousands of young children by donating to transform their lives. Your kind gesture and support will permanently remain with us in our School Archives and annual publication.-->
                <!--                    </p>-->
                <!--                <div class="d-flex flex-row align-items-center mb-1 justify-content-between">-->
                <!--                        <h4 class="mb-1 me-1"><i class="bi bi-currency-rupee"></i> 0.5 Lakhs</h4>-->
                <!--                    <a href="javascript:void(0)" class="btn theme-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">Interested</a>-->
                <!--                    </div>-->
                <!--                    <div class="shape-one"></div>-->
                <!--                    <div class="shape-two"></div>-->
                <!--        </div>-->
                <!--</div>-->
                <!--<div class="col-xl-4 col-lg-6 col-md-12">-->
                <!--     <div class="book-body">-->
                <!--         <div class="bg-image hover-zoom ripple rounded ripple-surface">-->
                <!--                       <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/book1.webp" alt="img">-->
                <!--                        <a href="#!">-->
                <!--                            <div class="hover-overlay">-->
                <!--                                <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>-->
                <!--                            </div>-->
                <!--                        </a>-->
                <!--                    </div>-->
                <!--                    <h5>Classroom Donation</h5>-->
                <!--                   <small>Donate a classroom and spread the joy of free education today!</small>-->
                <!--                    <p >-->
                <!--                        Help us develop a safe space to make studying fun for children by donating a classroom. The children will always remember your kindness as we permanently etch your name into our School Archives and annual publication and on the classroom you donate. We also invite you to attend our annual school function to personally witness all the lives you change.-->
                <!--                    </p>-->
                <!--                    <div class="d-flex flex-row align-items-center mb-1 justify-content-between">-->
                <!--                        <h4 class="mb-1 me-1"><i class="bi bi-currency-rupee"></i> 25.0 Lakhs</h4>-->
                <!--                    <a href="javascript:void(0)" class="btn theme-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">Interested</a>-->
                <!--                    </div>-->
                <!--                    <div class="shape-one"></div>-->
                <!--                    <div class="shape-two"></div>-->
                <!--        </div>-->
                <!--</div>-->
                <!--<div class="col-xl-4 col-lg-6 col-md-12">-->
                <!--   <div class="book-body">-->
                <!--            <div class="bg-image hover-zoom ripple rounded ripple-surface">-->
                <!--                        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/book2.webp" alt="img">-->
                <!--                        <a href="#!">-->
                <!--                            <div class="hover-overlay">-->
                <!--                                <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>-->
                <!--                            </div>-->
                <!--                        </a>-->
                <!--                    </div>-->
                <!--                    <h5>Board Name Donation</h5>-->
                <!--                   <small>Gift free education and impact young lives today!</small>-->
                <!--                    <p >-->
                <!--                        Help us lay the foundation of free education for underprivileged children by donating for their future. We will never forget your generosity. To mark your support as a milestone in our history, you’ll be given a special place on our Donation Board and in our School Archives and annual publication. To express our eternal gratitude, you will also be invited to our annual school function.-->
                <!--                    </p>-->
                <!--                    <div class="d-flex flex-row align-items-center mb-1 justify-content-between">-->
                <!--                        <h4 class="mb-1 me-1"><i class="bi bi-currency-rupee"></i> 10.0 Lakhs</h4>-->
                <!--                    <a href="javascript:void(0)" class="btn theme-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">Interested</a>-->
                <!--                    </div>-->
                <!--                    <div class="shape-one"></div>-->
                <!--                    <div class="shape-two"></div>-->
                <!--        </div>-->
                <!--</div>-->
                </div>
        </div>
    </section>
    <!-- booksec-close -->
    
    <!-- Programs-sec -->
    <section class="sec_padding program_sec">
        <div class="container">
            <div class="sec_title text-center">
                <h2 class="sec_heading mb-2"><?= get_field("maintitle",117);?></h2>
                <div class="section-border"><span></span></div>
            </div>
                <div class="list-item-box">
                     <h5><?= get_field("secondtitle",117);?></h5>
                
                     <ul class="timline-ul">
                          <?php
                        $cardtitle = get_field('cardtitle',117);
                        foreach($cardtitle as $cardtitle)
                        {
                        ?>
                         <li><?= $cardtitle['cardtitle1']; ?>
                         <img src="<?= $cardtitle['cardimage1']; ?>" alt="img" class="timline-icon">
                         </li>
                         
                          <!--<li><strong>SAI VIDYA NIKETAN- FREE EDUCATION TO THE POOR AND UNDERPRIVILEGED:-</strong> A charitable primary School functions on the first floor of the Mandir. The school is recognized by U.P Government and imparts free basic education from KG to 5th standard. Students are not charged any fees and are provided with free books and stationery, notebooks, school uniform, mid-day-meals etc.-->
                          <!--<img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img" class="timline-icon">-->
                          <!--</li>-->
                          
                          <!-- <li><strong>SAI VIDYA NIKETAN- FREE EDUCATION TO THE POOR AND UNDERPRIVILEGED:-</strong> A charitable primary School functions on the first floor of the Mandir. The school is recognized by U.P Government and imparts free basic education from KG to 5th standard. Students are not charged any fees and are provided with free books and stationery, notebooks, school uniform, mid-day-meals etc.-->
                          <!-- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img" class="timline-icon">-->
                          <!-- </li>-->
                           
                          <!--  <li><strong>SAI VIDYA NIKETAN- FREE EDUCATION TO THE POOR AND UNDERPRIVILEGED:-</strong> A charitable primary School functions on the first floor of the Mandir. The school is recognized by U.P Government and imparts free basic education from KG to 5th standard. Students are not charged any fees and are provided with free books and stationery, notebooks, school uniform, mid-day-meals etc.-->
                          <!--  <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img" class="timline-icon">-->
                          <!--  </li>-->
                            
                          <!--   <li><strong>SAI VIDYA NIKETAN- FREE EDUCATION TO THE POOR AND UNDERPRIVILEGED:-</strong> A charitable primary School functions on the first floor of the Mandir. The school is recognized by U.P Government and imparts free basic education from KG to 5th standard. Students are not charged any fees and are provided with free books and stationery, notebooks, school uniform, mid-day-meals etc.-->
                          <!--   <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img" class="timline-icon">-->
                          <!--   </li>-->
                           <?php
                        }
                        ?>
                     </ul>
                      
                     <?=get_field("lasttitle",117);?>
                </div>
        </div>
        <div class="welcome-one-hands"></div>
    </section>
    <!-- Programs-sec-close -->
    
    
    <!-- campus-sec -->
    <section class="sec_padding campus_sec">
        <div class="container">
            <div class="sec_title text-center">
                <h2 class="sec_heading mb-2"><?=get_field("conctructionmaintitle",117);?></h2>
                <div class="section-border"><span></span></div>
            </div>
            <div class="row g-4 align-items-center mt-2 campus-row">
                <div class="col-md-12">
                    <div class="campus-info-box animate-bg">
                        <img src="<?=get_field("constructionimagebackground",117);?>" alt="img" class="round-bg-top">
                        <img src="<?=get_field("constructionimagebackground",117);?>" alt="img" class="round-bg-bottom">
                        <?= get_field("constructioncontent",117);?>
                
                <div class="campus-list">
                    <?php
                            $constructionrepeater = get_field('constructionrepeater',117);
                            foreach($constructionrepeater as $constructionrepeater)
                            {
                            ?>
                    <ul>
                        <li><?= $constructionrepeater['contructionrepeatertitle']; ?></li>
                        <!--<li>Loacted in Greater Noida adjacent the main 60M road.</li>-->
                        <!--<li>Built up area of around 1.6 Lakh sq.ft. area.</li>-->
                        <!--<li>Single basement and upto 6 floors above ground.</li>-->
                        <!--<li>The Campus shall be designed for providing adequate outdoor learning and playing spaces.</li>-->
                        <!--<li>Using minimal energy for reducing operating costs while providing a environment for futuristic learning.</li>-->
                        <!--<li>Disabled friendly and designed with the latest codes for Health and Fire Safety.</li>-->
                        <!--<li>Sustainable Green Building with Water recycling and Waste management facilities.</li>-->
                        <!--<li>Interactive whiteboards are used in Sai Vidya Niketan.</li>-->
                        <!--<li>Each classroom teaching will include green board and interactive teaching.</li>-->
                        
                    </ul>
                    <?php
                            }
                            ?>
                </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="row g-3 left-img">
                        <div class="col-xl-6 col-lg-6 col-md-12">
                            <img src="<?=get_field("mainmapimage",117);?>" alt="img">
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12">
                         <div class="row g-3">
                             <div class="col-md-12">
                                 <img src="<?=get_field("groundmapimage",117);?>" alt="img">
                         
                             </div>
                             <div class="col-md-12">
                                 <div class="campus-contact-box">
                             <h5><?=get_field("lastsectionheading",117);?></h5>
                             <ul>
                                 <li><i class="bi bi-envelope-fill"></i> <a href="mailto:<?=get_field("email",117);?>"><?=get_field("email",117);?></a> </li>
                                 <li><i class="bi bi-telephone-fill"></i> <a href="tel:<?=get_field("mobile",117);?>"><?=get_field("mobile",117);?></a></li>
                             </ul>
                         </div>
                             </div>
                         </div>
                         </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- campus-sec-close -->
    
</main>



<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
      </div>
      <div class="modal-body donation-body">
        <form method="POST" class="myContactForm" id="myContactForm">
            <div class="row g-4">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <!--<label class="form-label" for="">Name<sup>*</sup></label>-->
                                            <input name="name" type="text" class="form-control" id="name" placeholder="Devotee Name *" >
                                             <span class="error" id="username_err"> </span>
                                        </div>
                                    </div>
                                      <div class="col-lg-12">
                                        <div class="form-group">
                                            <!--<label class="form-label" for="">Contact Phone<sup>*</sup></label>-->
                                            <input name="phone" type="tel" class="form-control" id="phone" placeholder="Mobile No.*" >
                                              <span id="mobile_err" class="error"></span>
                                        </div>
                                    </div>   
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <!--<label class="form-label" for="">Email<sup>*</sup></label>-->
                                            <input name="email" type="email" id="email_id" class="form-control" placeholder="E-Mail Address" >
                                              <span id="email_err" class="error"></span>
                                        </div>
                                    </div>
                                  
                                              <input name="amount_pay" type="hidden" id="interest_type">
                                            <input name="form_type" type="hidden" id="form_type">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/saikenaamsandesh.png">
                                            <!--<label class="form-label" for="">Address<sup>*</sup></label>-->
                                            <textarea rows="2" name="address" class="form-control" ></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <!--<input type="submit" name="submit" class="btn theme-btn mb-2 btnsubmit" value="Submit"><i class="fa fa-angle-right" aria-hidden="true"></i><span class="loader"></span>-->
                                        <button type="button" name="submit" class="btn theme-btn mb-2 btnsubmit">Submit Now <i class="fa fa-angle-right" aria-hidden="true"></i><span class="loader"></span></button>
                                        <!--<a href="#" class="btn theme-btn mb-2">Submit<i class="fa fa-angle-right" aria-hidden="true"></i>-->
                                        <!--</a>-->
                                    </div>
                                    </div>
                                    <span class="mailNotificationcontact" style="color:green; display:none;">Your Data Has Been Sent Successfully..</span>
                                </form>
      </div>
    </div>
  </div>
</div>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
      
<script>
 jQuery(document).ready(function () {
       
        //   $(".myContactForm").validate({
        //     // Define validation rules
        //     rules: {
        //         name: {
        //             required: true
        //         },
        //         phone: {
        //             required: true,
        //             minlength: 10,
        //             maxlength: 12,
        //             number: true
        //         },
        //         email: {
        //             required: true,
        //             email: true
        //         },
        //          address: {
        //             required: true
        //         }
        //     },
        //     // Specify validation error messages
        //     messages: {
        //         name: "Please provide a valid name.",
        //         phone: {
        //             required: "Please provide a phone number",
        //             minlength: "Phone number must be min 10 characters long",
        //             maxlength: "Phone number must not be more than 12 characters long"
        //         },
        //         email: {
        //             required: "Please enter your email",
        //             minlength: "Please enter a valid email address"
        //         },
        //          address: {
        //             required: "Please enter your Address"
        //         },
        //     },
        //     errorPlacement: function(error, element) {
        //         error.insertAfter(element); // Display error messages below the respective input fields
        //     }
        // });
});




    $(document).ready(function () {
        
      $('#phone').on('input', function () {
        checkmobile();
    });  
    
        $('#name').on('input', function () {
        checkuser();
    }); 
     
      $('#email_id').on('input', function () {
        checkemail();
    });
     //   Form validation   
function checkmobile() {
   
    if (!$.isNumeric($("#phone").val())) {
        $("#mobile_err").html("only number is allowed");
        return false;
    } else if ($("#phone").val().length != 10) {
        $("#mobile_err").html("10 digit required");
        return false;
    }
    else {
        $("#mobile_err").html("");
        return true;
    }
}    


function checkuser() {
  var user = $('#name').val();
    if (user == "") {
       $('#username_err').html('required field');
        return false;
    } else {
        $('#username_err').html('');
        return true;
    }
}


function checkemail() {
    var pattern1 = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    var email = $('#email_id').val();
    var validemail = pattern1.test(email);
    if (email == "") {
        $('#email_err').html('required field');
        return false;
    } else if (!validemail) {
        $('#email_err').html('invalid email');
        return false;
    } else {
        $('#email_err').html('');
        return true;
    }
}
//  End Form validation    
         
            $(".clsListAmount").click(function(e) {
          e.preventDefault();
           data = $(this).closest('.book-body').find('.interested_title').text().trim();
       
        $("#form_type").val(data);
    });
  
        $("[data-bs-target='#staticBackdrop']").click(function (e) {
            e.preventDefault();
$("#form_type").val("banner form");
            // Find the closest input field with class 'interest_btn' within the same parent container
            var inputValue = $(this).closest('.col-12').find('.interest_btn').val();
//alert(inputValue);
            // Set the value in the hidden field 'interest_type'
            $('#interest_type').val(inputValue);

        });
        
                $('.clsListAmount').click(function(){
            // Get the list-amount attribute value
            var listAmount = $(this).attr('list-amount');
            
            // Set the value in the hidden field inside the modal form
            $('#interest_type').val(parseInt(listAmount));

            // Show the modal
            $('#staticBackdrop').modal('show');
        });
        
        
        $(".btnsubmit").click(function (e) {
            e.preventDefault();
            submitForm();
        });
   

    $(".loader").hide();
    function submitForm() {
         if (!checkuser() && !checkemail() && !checkmobile()) {
            console.log("er1");
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
        } else if (!checkuser() || !checkemail() || !checkmobile()) {
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
            console.log("er");
        }
        else {
        
        let email = $('#email_id').val();
        if (email){
        $(".btnsubmit").html("Loading <span class='loader'></span>");
            $(".loader").show();
   $('.btnsubmit').prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: '<?php echo site_url('wp-content/themes/storefront/action.php'); ?>',
            dataType: 'text',
            data: $("#myContactForm").serialize(),
            success: function (response) {
                var resultText = $.trim(response);
                console.log(resultText);

                if (resultText == "sent") {
                           $("#myContactForm")[0].reset();
                        window.location.href = '<?php echo site_url('wp-content/themes/storefront/payment-gateway/easebuzz.php'); ?>';
                        $(".btnsubmit").html("Submit");
                    } else {
                        alert("error");
                    }
            },
            complete: function () {
                // Re-enable the button after the request is complete
                $('.btnsubmit').prop('disabled', false);
            }
        });
        }
    }
    }
    });
</script>




<script>
        window.onload = function () {
            // Step 2: Check if the current URL contains '/donate'
            var isDonationPage = window.location.href.includes('/donate');

            // Step 3: If it is a donation page, add the class to the header
            if (isDonationPage) {
                // Step 4: Get the header element
                var header = document.querySelector('header');

                // Step 5: Add the 'donate-header' class to the header
                header.classList.add('donate-header');
            }
        };
    </script>
<?php
get_footer();