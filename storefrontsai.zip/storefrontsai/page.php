<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package storefront
 */

get_header(); 

global $post;
global $wp_query;

global $post;
global $wp_query;

$post_obj = $wp_query->get_queried_object();
$Page_ID = $post->ID;

// Get the slider repeater field
$slider_images = get_field('slider', $Page_ID);

// Check if the repeater field has images
if ($slider_images) {
    // Get the first image from the repeater
    $banner_image = $slider_images[0]['slider_image'];
} else {
    // If no slider image, $banner_image is set to an empty string
    $banner_image = '';
}

?>
<!-- Banner-->
<div  class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <div class="container" style="display: none;">
        <div class="breadcrumb_body" >
            <ul class="p-0">
                <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>
                <li><?= get_the_title(); ?></li>
            </ul>
        </div>
    </div>
</div>


            <!-- Banner-->
            
            <!-- About-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
                  <div class="sec_title">
    <h1 class="sec_heading mb-2"><?php echo get_the_title(); ?></h1>
    <div class="section-border"><span></span></div>
</div>   


			<?php
			while ( have_posts() ) :
				the_post();

				do_action( 'storefront_page_before' );
                the_content();
				//get_template_part( 'content', 'page' );

				/**
				 * Functions hooked in to storefront_page_after action
				 *
				 * @hooked storefront_display_comments - 10
				 */
				do_action( 'storefront_page_after' );

			endwhile; // End of the loop.
			?>

	
	</div>
	</section>

<?php
get_footer();
