<?php get_header(); ?>

 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
            <!-- Banner-->         
         
  <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
      <div class="row g-4">
    <div class="col-12">
        <div class="sec_title mb-4">
            <h1 class="sec_heading mb-2">News</h1>            
            <div class="section-border"><span></span></div>
        </div>
       
    </div>
    
    <?php 
       $cat = 15;

    // Check if it is page only
    if ( is_page() || is_single()) {
        $args=array(
            'cat'  =>  $cat,
            'order'  =>  DESC,
            'orderby'  =>  rand,
            'posts_per_page'  =>  9999,
            );

        $my_query = null;

        $my_query = new WP_Query($args);

        if( $my_query->have_posts() ) {

            while ($my_query->have_posts()) : $my_query->the_post(); ?>

                <!--<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>-->
             <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="<?php the_permalink(); ?>">
        <div class="gallery-box">
            <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="img">
            <div class="gallery-content-flex">
                <div class="batch"></div>
                <div class="gallry-content">
                    <p><?php the_title(); ?></p>
                   
                </div>
            </div>
        </div>
        </a>
    </div>

            <?php

            endwhile;

        }
        wp_reset_query();
    }
    
    
    
    ?>
    


<!--  <nav aria-label="...">-->
<!--  <ul class="pagination">-->
<!--    <li class="page-item disabled">-->
<!--      <span class="page-link">Previous</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">1</a></li>-->
<!--    <li class="page-item active" aria-current="page">-->
<!--      <span class="page-link">2</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">3</a></li>-->
<!--    <li class="page-item">-->
<!--      <a class="page-link" href="#">Next</a>-->
<!--    </li>-->
<!--  </ul>-->
<!--</nav>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/diwali.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Diwali -2016</h4>-->
    <!--                <p>Total Photos: 9</p>-->
    <!--                <p>Last Updated: 07 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/janmastmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Janmashtmi -2016</h4>-->
    <!--                <p>Total Photos: 25</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/lohari.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Lohri -2016</h4>-->
    <!--                <p>Total Photos: 15</p>-->
    <!--                <p>Last Updated: 20 Feb 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mahashivratri.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mahashivratri - 2016</h4>-->
    <!--                <p>Total Photos: 11</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mass-Marriage.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mass-Marriage -2016</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Ram-Navmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Ram Navmi -2016</h4>-->
    <!--                <p>Total Photos: 31</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Samadhi-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Samadhi Day -2016</h4>-->
    <!--                <p>Total Photos: 09</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Shri-Sai-Katha.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Shri Sai Katha - 2016</h4>-->
    <!--                <p>Total Photos: 29</p>-->
    <!--                <p>Last Updated:  03 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Sthapna-Diwas.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Sthapna Diwas -2016</h4>-->
    <!--                <p>Total Photos: 40</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Teacher-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Teacher Day -2016</h4>-->
    <!--                <p>Total Photos: 22</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/VIP-Guest-Visit.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>VIP Guest Visit</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->




</div>


                 </div>
             </section>
        </main>
        
        <?php
get_footer();