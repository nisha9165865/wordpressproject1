<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package storefront
 */

?>
	<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="UTF-8">
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php wp_head(); ?>
        <title>Sai mandir</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">
        <!-- <link rel="icon" href="<?= get_stylesheet_directory_uri();?>/sai_assets/images/favicon.webp" type="image/x-icon"> -->
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/fancybox.css">
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/aos.css">
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/style.css">
        <link rel="stylesheet" href="<?= get_stylesheet_directory_uri();?>/sai_assets/css/responsive.css">
                <style>
        .error{
            color: red !important;
        }
        
        
        .loader {
            display: inline-block;
            border: 4px solid #f3f3f3;
            border-radius: 50%;
            border-top: 4px solid #3498db;
            width: 20px;
            height: 20px;
            margin-left: 8px;
            -webkit-animation: spin 1s linear infinite;
            animation: spin 1s linear infinite;
            
        }
    </style>
    </head>
    <body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
        <!-- header-start -->
        <header class="header">
            <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="top-colud">
            <div class="top-header">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-4">
                            <a href="<?= site_url('/');?>" class="nav__logo">
                                <img src="<?= get_field("headerlogo",46);?>" alt="logo">
                            </a>
                        </div>

                        <div class="col-xl-10 col-lg-8">
                            <div class="top-btn">
                                <a class="btn-transparent" href="<?=site_url('/daily-program');?>"><img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/temple.webp" alt="img">Daily Program</a>
                                <a href="<?=site_url('/online-pooja');?>" class="btn-transparent color1"><img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/pooja.png" alt="img"> Online Pooja </a>
                                <a href="<?=site_url('/donate');?>" target="_blank" class="btn-transparent color2"><img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"> Donate Now</a>
                                <a class="btn-transparent" href="#" target="_blank"><img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/school.webp" alt="img">Sai Vidya Niketan</a>
                                <div class="social-icon">
                                    <!--<h5><?= get_field("socialmediatitle",46);?></h5>-->
                                   <span>
                                    <a href="<?= get_field("facebooklink",46);?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <a href="<?= get_field("youtubelink",46);?>" target="_blank"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                                    <a href="<?= get_field("linkdinlink",46);?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                    <a href="<?= get_field("twitterlink",46);?>" target="_blank"><i class="bi bi-twitter-x"></i></a>
                                    <a href="<?= get_field("instagram",46);?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                   </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container">
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="hamburger"></span>
                    <span class="hamburger"></span>
                    <span class="hamburger"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav ms-auto">
                          <?php 
                            $menu_exists = wp_get_nav_menu_object('header');
                            $items = wp_get_nav_menu_items($menu_exists->term_id);
                            $tree = buildTree($items);            
                            foreach($tree as $key=>$item){
                            if(empty($item->wpse_children)){
                            ?>
                            <li class="nav-item">
                                <a class="nav-link <?= !empty($key == 0)? 'active':'';?>" aria-current="page" href="<?= $item->url;?>"><?= $item->title;?></a>
                              </li>
                            <?php
                           }else{
                           ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="<?= $item->url;?>" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?= $item->title;?></a>
                                <ul class="dropdown-menu">
                                    <?php
                                    foreach($item->wpse_children as $step2){
                                    // innermenu($step2);
                                    ?>
                                    <li><a class="dropdown-item" href="<?= $item->url;?>"><?= $step2->title;?></a>
                                        <ul class="sub-dropdown-menu">
                                            <?php
                                            foreach($step2->wpse_children as $step3){
                                            ?>
                                            <li><a class="sub-dropdown-item" href="<?= $step3->url;?>"><?= $step3->title;?></a></li>
                                            <?php
                                            }
                                            ?> 
                                        </ul>
                                    </li>
                                    <?php
                                    }
                                    ?> 
                                  
                                </ul>
                              </li>
                           <?php
                              }            
                              }
                            ?>
                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link active" aria-current="page" href="#">About Us</a>-->
                      <!--</li>-->
                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link" href="#">Samiti Management</a>-->
                      <!--</li>-->
                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link" href="#">Participate Yourself</a>-->
                      <!--</li>-->
                      <!--<li class="nav-item dropdown">-->
                      <!--  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
                      <!--      Temple Program-->
                      <!--  </a>-->
                      <!--  <ul class="dropdown-menu">-->
                      <!--    <li><a class="dropdown-item" href="#">Action</a>-->
                      <!--      <ul class="sub-dropdown-menu">-->
                      <!--        <li><a class="sub-dropdown-item" href="#">Action</a></li>-->
                      <!--        <li><a class="sub-dropdown-item" href="#">Another action</a></li>-->
                      <!--        <li><a class="sub-dropdown-item" href="#">Something else here</a></li>-->
                      <!--      </ul>-->
                      <!--    </li>-->
                      <!--    <li><a class="dropdown-item" href="#">Another action</a></li>-->
                      <!--    <li><a class="dropdown-item" href="#">Something else here</a></li>-->
                      <!--  </ul>-->
                      <!--</li>-->

                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link" href="#">Educational Program</a>-->
                      <!--</li>-->
                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link" href="#">Medical Services</a>-->
                      <!--</li>-->
                      <!--<li class="nav-item">-->
                      <!--  <a class="nav-link" href="#">Contact Us</a>-->
                      <!--</li>-->
                    </ul>
                  </div>
                </div>
              </nav>
            
            
            
            
            
        </header>
        <!-- header-close -->
