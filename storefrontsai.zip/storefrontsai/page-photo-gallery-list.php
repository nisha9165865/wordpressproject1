 <?php 
                        
$catidd=base64_decode($_GET['data']);
//echo $catidd;
?>
                        
                        
                        <?php get_header(); ?>
<?php
// The Query
  $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$args = array(
    'post_type'      => 'gallery', // Your post type
    'posts_per_page' => 12,      // Number of posts to display
    'paged' => $paged,
    'tax_query'      => array(
        array(
            'taxonomy' => 'gallery_category', // Replace with your custom taxonomy name
            'field'    => 'term_id',                 // Use 'term_id', 'name', or 'slug'
            'terms'    => $catidd,       // Replace with the term you want to query
        ),
    ),
);

$query = new WP_Query($args);
 ?>
 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li>Photo gallery</li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
            <!-- Banner-->         
         
             <!-- About-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
      <div class="row g-4">
    <div class="col-12">
        <div class="sec_title mb-4">
            
            <h1 class="sec_heading mb-2">Photo Gallery</h1>            
            <div class="section-border"><span></span></div>
        </div>
        <h3>Album Name: <?php  echo base64_decode($_GET['catName']);?></h3>
        <h3 class="sub-title">Total Albums: <?php echo (int)$query->post_count; ?></h3>
    </div>

 <?php
// The Loop
if ($query->have_posts()) {
    while ($query->have_posts()) {$query->the_post(); ?>
        
       
        <!--the_title('<h2>', '</h2>');-->
        <!--the_content();-->
     <div class="col-xl-3 col-lg-4 col-md-6">
        <div class="gallery-box">
            <img src="<?php echo get_the_post_thumbnail(); ?>" alt="img">
            <div class="gallery-content-flex">
                <div class="batch"></div>
                <div class="gallry-content">
                    <h4>Title: <?php echo the_title(); ?></h4>
                    <p>Description: <?php echo the_content(); ?></p>
                    <p>Last Updated: <?php echo  date('j F Y', strtotime($post->post_modified_gmt)); ?></p>
                </div>
            </div>
        </div>
    </div>
        
  <?php  } ?>
<?php } else {
    // No posts found
    echo 'No posts found';
}

// Restore original post data
wp_reset_postdata();
?>

<div class="qodef-custom-pagination">
<?php echo paginate_links( array(
'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
'total' => $query->max_num_pages,
'current' => $paged,
'prev_text' => '<span aria-label="' . esc_attr__( 'Previous page', 'textdomain' ) . '">' . esc_html__( '&laquo;', 'textdomain' ) . '</span>',
'next_text' => '<span aria-label="' . esc_attr__( 'Next page', 'textdomain' ) . '">' . esc_html__( '&raquo;', 'textdomain' ) . '</span>'
) ); ?>
</div>
<!--  <nav aria-label="...">-->
<!--  <ul class="pagination">-->
<!--    <li class="page-item disabled">-->
<!--      <span class="page-link">Previous</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">1</a></li>-->
<!--    <li class="page-item active" aria-current="page">-->
<!--      <span class="page-link">2</span>-->
<!--    </li>-->
<!--    <li class="page-item"><a class="page-link" href="#">3</a></li>-->
<!--    <li class="page-item">-->
<!--      <a class="page-link" href="#">Next</a>-->
<!--    </li>-->
<!--  </ul>-->
<!--</nav>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/diwali.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Diwali -2016</h4>-->
    <!--                <p>Total Photos: 9</p>-->
    <!--                <p>Last Updated: 07 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/janmastmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Janmashtmi -2016</h4>-->
    <!--                <p>Total Photos: 25</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/lohari.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Lohri -2016</h4>-->
    <!--                <p>Total Photos: 15</p>-->
    <!--                <p>Last Updated: 20 Feb 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mahashivratri.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mahashivratri - 2016</h4>-->
    <!--                <p>Total Photos: 11</p>-->
    <!--                <p>Last Updated: 30 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Mass-Marriage.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Mass-Marriage -2016</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Ram-Navmi.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Ram Navmi -2016</h4>-->
    <!--                <p>Total Photos: 31</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Samadhi-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Samadhi Day -2016</h4>-->
    <!--                <p>Total Photos: 09</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Shri-Sai-Katha.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Shri Sai Katha - 2016</h4>-->
    <!--                <p>Total Photos: 29</p>-->
    <!--                <p>Last Updated:  03 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Sthapna-Diwas.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Sthapna Diwas -2016</h4>-->
    <!--                <p>Total Photos: 40</p>-->
    <!--                <p>Last Updated: 02 Jan 2017</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/Teacher-Day.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>Teacher Day -2016</h4>-->
    <!--                <p>Total Photos: 22</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--<div class="col-xl-3 col-lg-4 col-md-6">-->
    <!--    <div class="gallery-box">-->
    <!--        <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/VIP-Guest-Visit.png" alt="img">-->
    <!--        <div class="gallery-content-flex">-->
    <!--            <div class="batch"></div>-->
    <!--            <div class="gallry-content">-->
    <!--                <h4>VIP Guest Visit</h4>-->
    <!--                <p>Total Photos: 20</p>-->
    <!--                <p>Last Updated: 31 Dec 2016</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->




</div>


                 </div>
             </section>
              <!-- About-close -->
        </main>
        
        <?php
get_footer();