<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package storefront
 */

get_header(); ?>



        <main>
            <!-- Banner-slider -->
            <div class="banner_sec">
                 <?php 
                 $args = array( 'post_type' => 'slider',  'posts_per_page' => -1 , 'order'=>'ASC', 'post_status'=>'publish' );
                 $slider = new WP_Query( $args );
                 ?>
             <div class="banner-slider owl-carousel owl-theme">
                  <?php 
    			    foreach($slider->posts as $key=>$row_slider){
    				$slider_id = $row_slider->ID;
    			?>
               <div class="item-<?= $key+1;?>">
                 <img src="<?php echo get_the_post_thumbnail_url($slider_id);?>" alt="img">
               </div>
              <!-- <div class="item">-->
              <!--   <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/banner2.webp" alt="img">-->
              <!-- </div>-->
              <!-- <div class="item">-->
              <!--  <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/banner3.webp" alt="img">-->
              <!--</div>-->
              <?php
        		}
        		?>
             </div> 
             <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="bottom-colud">
            </div>
            <!-- Banner-slider-close -->
         
            <!-- news-updat-start -->
            <section class="sec_padding news-sec">
             <div class="container">
                 <div class="row align-items-center marquee-row">
                     <div class="col-xl-2 col-lg-2 col-2 marquee-col">
                         <div class="mar-heading"><h4>Daily News</h4></div> 
                     </div>
                     <div class="col-xl-10 col-lg-10 col-10 marquee-col">
                          <?php 
                 $args = array( 'post_type' => 'daily_news',  'posts_per_page' => -1 , 'order'=>'ASC', 'post_status'=>'publish' );
                 $dailynews = new WP_Query( $args );
                 ?>
                         <marquee onmouseover="this.stop();" onmouseout="this.start();" direction="left" behavior="scroll" scrollamount="7">
                             <?php 
    			    foreach($dailynews->posts as $key=>$row_dailynews){
    				$dailynews_id = $row_dailynews->ID;
    			?>
                             <a href="<?= get_field("newsurl",$dailynews_id);?>" target="_blank"><?= get_the_title($dailynews_id);?></a>
                             <!--<a href="#" target="_blank">Shri Krishan Janamashtmi Mahotsav</a>-->
                                           <?php
        		}
        		?>
                             </marquee>
               
                     </div>
                 </div>    
                 </div>
            </section> 
            <!-- news-updat-close -->
         
             <!-- About-start-->
             <section class="sec_padding about_sec" data-aos="fade-up">
                 <div class="container">
                     <div class="row g-5">
                         <div class="col-xl-6 col-lg-6 col-md-12">
                             <div class="left-about">
                                 <h1 class="sec_heading"><?= get_field("abouttitle",46);?></h1>
                                 <?php $about_id = 46; // Replace with the actual post/page ID

                                   $customFieldContent = get_field("aboutcontent", $about_id); ?>
                                 <p><?= substr(wp_strip_all_tags($customFieldContent), 0, 770);?></p>
         
                                 <div class="btn-box">
                                     <a href="<?=site_url('/about-us');?>" target="_blank" class="btn theme-btn">Read More <i class="fa fa-angle-right" aria-hidden="true"></i>
                                     </a>
                                     <a href="<?=site_url('/donate');?>" target="_blank" class="btn theme-btn2">Donate Now <i class="fa fa-angle-right" aria-hidden="true"></i>
                                     </a>
                                 </div>
                             </div>
                         </div>
                         <div class="col-xl-6 col-lg-6 col-md-12">
                             <div class="right-about">
                                 <img src="<?= get_field("aboutimage",46);?>" alt="img">
                             </div>
                         </div>
                     </div>
                 </div>
             </section>
              <!-- About-close -->
         
             <!-- programs-start-->
             <section class="sec_padding program-sec">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="top-colud">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="bottom-colud">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-shap">
                 <div class="container">
                     <div class="text-center mb-5">
                         <h2 class="sec_heading text-white">OUR PROGRAMS</h2>
                     </div>
                     <div class="row g-5 justify-content-center">
                         <?php

                                    $args = array(
                                        'post_type'      => 'page',
                                        'posts_per_page' => 3,
                                        'post_parent'    => 153,
                                        'order'          => 'ASC',
                                     );
                                    
                                    
                                    $parent = new WP_Query( $args );
                                    
                                    
                                    if ( $parent->have_posts() ) : ?>
                                    
                                        <?php while ( $parent->have_posts() ) : $parent->the_post(); ?>
                         <div class="col-xl-4 col-lg-4 col-md-6" data-aos="zoom-in">
                             <div class="program-box">
                                 <figure>
                                     <img src="<?= get_the_post_thumbnail_url($parent->ID);?>" alt="img">
                                 </figure>
                                <div class="dets">
                                 <div class="info-box">
                                     <h3><?= get_the_title();?></h3>
                                     <p><?php echo substr(get_the_excerpt($parent->ID),0,150); ?></p>
                                 </div>
                                 <a href="<?php the_permalink(); ?>" class="btn theme-btn">Read More <span><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i></span>
                                 </a>
                                </div>
                             </div>
                         </div>
                          <?php endwhile; ?>
                                    
                       <?php endif; wp_reset_postdata(); ?>
                         <!--<div class="col-xl-4 col-lg-4 col-md-6" data-aos="zoom-in">-->
                         <!--    <div class="program-box">-->
                         <!--        <figure>-->
                         <!--            <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/p2.webp" alt="img">-->
                         <!--        </figure>-->
                         <!--       <div class="dets">-->
                         <!--        <div class="info-box">-->
                         <!--            <h3>Education Program</h3>-->
                         <!--            <p>A charitable primary School functions on the first floor on the Mandir. The school is recognized by U. P Government and imparts free basic..</p>-->
                         <!--        </div>-->
                         <!--        <a href="#" class="btn theme-btn">Read More <span><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i></span>-->
                         <!--        </a>-->
                         <!--       </div>-->
                         <!--    </div>-->
                         <!--</div>-->
                         <!--<div class="col-xl-4 col-lg-4 col-md-6" data-aos="zoom-in">-->
                         <!--    <div class="program-box">-->
                         <!--        <figure>-->
                         <!--            <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/p3.webp" alt="img">-->
                         <!--        </figure>-->
                         <!--       <div class="dets">-->
                         <!--        <div class="info-box">-->
                         <!--            <h3>Medical Services</h3>-->
                         <!--            <p>A Charitable Mini Hospital of the Mandir provides free medical treatment to about 250-300 outdoor patients daily from the less- privileged class ...</p>-->
                         <!--        </div>-->
                         <!--        <a href="#" class="btn theme-btn">Read More <span><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i><i class="bi bi-caret-right-fill"></i></span>-->
                         <!--        </a>-->
                         <!--       </div>-->
                         <!--    </div>-->
                         <!--</div>-->
                     </div>
                 </div>
             </section>
             <!-- programs-close-->
         
             <!-- Gallery-start -->
             <section class="sec_padding gallery_sec">
                 <div class="container">
                     <div class="text-center mb-5">
                         <h2 class="sec_heading">OUR MEDIA SECTION</h2>
                     </div>
                         <?php
                           $gallery = get_field('gallery',46);
                           foreach($gallery as $row_gallery){
                           ?>
                     <div class="row g-4 gallery-row">
                     
                         <div class="col-xl-4 col-lg-4 col-md-6">
                             <div class="gallery_wraper gr1">
                                 <div class="gallery_item" data-aos="flip-up"> 
                                    <a href="<?= $row_gallery['showcaseimage1'];?>" class="showcase" data-fancybox="gallery">
                                <img src="<?= $row_gallery['image1'];?>" alt="img" class="img-fluid">
                                </a>
                                 </div>
                                 <div class="gallery_item" data-aos="flip-right">
                                    <a href="<?= $row_gallery['showcaseimage2'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image2'];?>" alt="img" class="img-fluid">
                                        </a>
                                 </div>
                             </div>
                         </div>
                         <div class="col-xl-4 col-lg-4 col-md-6">
                             <div class="gallery_wraper gr2">
                                 <div class="gallery_item" data-aos="flip-up">
                                    <a href="<?= $row_gallery['showcaseimage3'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image3'];?>" alt="img" class="img-fluid">
                                        </a>
                                 </div>
                                 <div class="gallery_item" data-aos="flip-right">
                                    <a href="<?= $row_gallery['showcaseimage4'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image4'];?>" alt="img" class="img-fluid">
                                        </a>
                                 </div>
                                 <div class="gallery_item" data-aos="flip-up">
                                    <a href="<?= $row_gallery['showcaseimage5'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image5'];?>" alt="img" class="img-fluid">
                                        </a>
                                 </div>
                 
                             </div>
                         </div>
                         <div class="col-xl-4 col-lg-4 col-md-6">
                             <div class="gallery_wraper gr3">
                                 <div class="gallery_item" data-aos="flip-left">
                                    <a href="<?= $row_gallery['showcaseimage6'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image6'];?>" alt="img" class="img-fluid">
                                        </a>
                                 </div>
                                 <div class="gallery_item" data-aos="flip-up">
                                    <a href="<?= $row_gallery['showcaseimage7'];?>" class="showcase" data-fancybox="gallery">
                                        <img src="<?= $row_gallery['image7'];?>" alt="img" class="img-fluid">
                                        </a>                                     
                                 </div>
                 
                             </div>
                         </div>

                         <div class="col-12 mt-5 text-center">
                            <a href="#" class="btn theme-btn">View All <i class="fa fa-angle-right" aria-hidden="true"></i>
                            </a>
                         </div>
                     </div>
                      <?php
                   }
                   ?>
                 </div>
             </section>
             <!-- Gallery-close -->
         
           <!-- sewa-start -->
           <section class="sec_padding sewa_sec">
             <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="top-colud">
             <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/top-cloud.webp" alt="img" class="bottom-colud">
             <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-shap">
             <div class="container">
                <div class="row">
                    <div col-12>
                          <div class="text-center">
                     <h2 class="sec_heading text-white">Sai Baba Ki Sewa</h2>
                 </div>
                     </div>
                     
<!--                    <div class="col-12">-->
    <!-- table-1 -->
 
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="4">आरती सेवा</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>काकड़ आरती 6 AM</td>-->
<!--                    <td>प्राप्त आरती 8.00 AM</td>-->
<!--                    <td>मध्यान आरती 12.00 PM</td>-->
<!--                    <td>संध्या आरती 06.00 PM</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-2 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">पोशक सेवा</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>1 पोशक</td>-->
<!--                    <td>2 पोशक</td>-->
<!--                    <td>3 पोशक</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>250/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                    <td class="t-payment"><span>100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                    <td class="t-payment"><span>100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-3 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">भंडारा (सामान्य दिन)</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>प्राप्त 8.00 बजे</td>-->
<!--                    <td>दोपहर - 12.00 बजे</td>-->
<!--                    <td>सायं - सर्दियों में 6 बजे और गर्मियों में 6.30 बजे</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>4100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>5100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>5100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-4 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">भंडारा ( बृहस्पतिवार )</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>प्राप्त 8.00 बजे</td>-->
<!--                    <td>दोपहर - 12.00 बजे</td>-->
<!--                    <td>सायं - सर्दियों में 6 बजे और गर्मियों में 6.30 बजे</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>6100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>6100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>21000/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-5 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">स्कूल के बच्चों को नाश्ता व दोपहर का भोजन</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>नाश्ता प्राप्त 8.00 बजे</td>-->
<!--                    <td>दोपहर का भोजन - 12.00 बजे</td>-->
<!--                    <td>अन्य स्कूल को मध्यान्ह भोजन प्रातः 10 बजे से पहुंचना शुरू हो जता है।</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>4100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>5100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>5100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-6 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">साईं की रसोई - प्रति रविवार</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>दोपहर - 12:30 बजे</td>-->
<!--                    <td>अतिरिक्त बुकिंग जैसे :- हलवा / खीर दोनों में से एक</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>7100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

<!--                    <td class="t-payment"><span>5100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->

    <!-- table-7 -->
<!--    <div class="table-responsive">-->
<!--        <table class="table table-striped table-bordered text-center arti-table">-->
<!--            <thead>-->
<!--                <tr class="text-white arti-table-heading">-->
<!--                    <th colspan="3">साईं की रसोई - प्रति बृहस्पतिवार</th>-->
<!--                </tr>-->
<!--            </thead>-->
<!--            <tbody>-->
<!--                <tr>-->
<!--                    <td>दोपहर - 12:30 बजे</td>-->
<!--                </tr>-->
<!--                <tr>-->
<!--                    <td class="t-payment"><span>6100/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
<!--                </tr>-->
<!--            </tbody>-->
<!--        </table>-->
<!--    </div>-->
<!--</div>-->



 <div class="col-12">
    <!-- table-1 -->
 
    <?php
$ccc = get_categories('taxonomy=sai_baba_ki_sewa_category&type=sai_baba_ki_sewa&orderby=ID&order=DESC'); 
//print_r($ccc);
foreach($ccc as $cccData){ ?>
<?php 
$current_cat_id  = $cccData->term_id;
$argsPost = [
    'orderby' => 'ID',
'order' => 'ASC',
    'post_type' => 'sai_baba_ki_sewa',
    'tax_query' => [
        [
            'taxonomy' => 'sai_baba_ki_sewa_category',
            'terms' =>$current_cat_id,
            'include_children' => false
        ],
    ],
];
$myposts = get_posts($argsPost); 


?>

    <div class="table-responsive">
        <table class="table table-striped table-bordered text-center arti-table">
            <thead>
                <tr class="text-white arti-table-heading">
                    <th colspan="4"><?php echo $cccData->name ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
                    
                    <td><?php the_title(); ?></td>
                    <?php
                    endforeach; 
                    wp_reset_postdata();
                    ?>
                    
                    ?>
                    
                    <!--<td>प्राप्त आरती 8.00 AM</td>-->
                    <!--<td>मध्यान आरती 12.00 PM</td>-->
                    <!--<td>संध्या आरती 06.00 PM</td>-->
                </tr>
                <tr>
                        <?php
                    foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
                     <td class="t-payment tPayment" sewa-category="<?php echo $cccData->name ?>" sewa-title="<?php echo the_title(); ?>" pay-amount="<?php echo get_the_content(); ?>"><span><?php echo get_the_content(); ?>/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>
               
                    <?php
                    endforeach; 
                    wp_reset_postdata();
                    ?>
                    
                    ?>
                    
                   

                    <!--<td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

                    <!--<td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->

                    <!--<td class="t-payment"><span>500/- <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/donate.png" alt="img"></span></td>-->
                </tr>
            </tbody>
        </table>
    </div>
<?php }
?>
 
    

    
</div>
                </div>
             </div>
         </section>
         <!-- sewa-close -->
         
        </main>

<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/sai-baba-images.webp" alt="img">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
      </div>
      <div class="modal-body donation-body">
        <form method="POST" class="myContactForm" id="myContactForm">
            <div class="row g-4">
                <div id="message"></div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-label" for="">Name<sup>*</sup></label>
                                            <input name="name" type="text" class="form-control" id="name" placeholder="Full Name*" >
                                             <span class="error" id="username_err"> </span>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-label" for="">Email<sup>*</sup></label>
                                            <input name="email" type="email" id="email_id" class="form-control" placeholder="Your Email*">
                                            <span id="email_err" class="error"></span>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-label" for="">Contact Phone<sup>*</sup></label>
                                            <input name="phone" type="tel" class="form-control" id="phone" pattern="[0-9]{10,12}" placeholder="Your Phone*">
                                            <span id="mobile_err" class="error"></span>
                                        </div>
                                    </div>   
                                                  <input name="amount_pay" type="hidden" id="interest_type">
                                            <input name="form_type" type="hidden" id="form_type">
                                            <input name="sewa_category" type="hidden">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                                <img src="https://devupwork.v2web.in/sai-mandir-noida/wp-content/uploads/2024/01/saikenaamsandesh.png">
                                            <textarea rows="2" name="address" class="form-control" ></textarea>
                                         
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <!--<input type="submit" name="submit" class="btn theme-btn mb-2 btnsubmit" value="Submit"><i class="fa fa-angle-right" aria-hidden="true"></i><span class="loader"></span>-->
                                        <button type="button" name="submit" class="btn theme-btn mb-2 btnsubmit">Submit <i class="fa fa-angle-right" aria-hidden="true"></i><span class="loader"></span></button>
                                        <!--<a href="#" class="btn theme-btn mb-2">Submit<i class="fa fa-angle-right" aria-hidden="true"></i>-->
                                        <!--</a>-->
                                    </div>
                                    </div>
                                    <span class="mailNotificationcontact" style="color:green; display:none;">Your Data Has Been Sent Successfully..</span>
                                </form>
      </div>
    </div>
  </div>
</div>


<?php
get_footer(); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
   $(document).ready(function(){
       
      $('#phone').on('input', function () {
        checkmobile();
    });  
    
        $('#name').on('input', function () {
        checkuser();
    }); 
     
      $('#email_id').on('input', function () {
        checkemail();
    });
     //   Form validation   
function checkmobile() {
   
    if (!$.isNumeric($("#phone").val())) {
        $("#mobile_err").html("only number is allowed");
        return false;
    } else if ($("#phone").val().length != 10) {
        $("#mobile_err").html("10 digit required");
        return false;
    }
    else {
        $("#mobile_err").html("");
        return true;
    }
}    


function checkuser() {
  var user = $('#name').val();
    if (user == "") {
       $('#username_err').html('required field');
        return false;
    } else {
        $('#username_err').html('');
        return true;
    }
}


function checkemail() {
    var pattern1 = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    var email = $('#email_id').val();
    var validemail = pattern1.test(email);
    if (email == "") {
        $('#email_err').html('required field');
        return false;
    } else if (!validemail) {
        $('#email_err').html('invalid email');
        return false;
    } else {
        $('#email_err').html('');
        return true;
    }
}
//  End Form validation
       
    //   $('#staticBackdrop').modal('show'); 
    $('.tPayment').on('click', function(){
        var payAmount = $(this).attr('pay-amount');
        $("input[name=sewa_category]").val($(this).attr('sewa-category'));
        $('#staticBackdrop').modal('show');
        $('#interest_type').val(payAmount);
        $('#form_type').val($(this).attr('sewa-title'));
    });
     
     
     
            $(".btnsubmit").click(function (e) {
            e.preventDefault();
            submitForm();
        });
   

    $(".loader").hide();
    function submitForm() {
       
       if (!checkuser() && !checkemail() && !checkmobile()) {
            console.log("er1");
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
        } else if (!checkuser() || !checkemail() || !checkmobile()) {
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
            console.log("er");
        }
        else {
       
        let email = $('#email_id').val();
        if (email){
        $(".btnsubmit").html("Loading <span class='loader'></span>");
            $(".loader").show();
$('.btnsubmit').prop('disabled', true);
        $.ajax({
            type: 'POST',
            url: '<?php echo site_url('wp-content/themes/storefront/action_sai_baba_ki_sewa.php'); ?>',
            dataType: 'text',
            data: $("#myContactForm").serialize(),
            success: function (response) {
                var resultText = $.trim(response);
                console.log(resultText);

                if (resultText == "sent") {
                      $("#myContactForm")[0].reset();
                        window.location.href = '<?php echo site_url('wp-content/themes/storefront/payment-gateway/easebuzz.php'); ?>';
                        $(".btnsubmit").html("Submit");
                    } else {
                        alert("error");
                    }
            },
            complete: function () {
                $('.btnsubmit').prop('disabled', false);
            }
        });
        }
    }
    } 
    
   
    
   });
</script>
