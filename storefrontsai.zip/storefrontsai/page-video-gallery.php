<?php get_header(); ?>

 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
            <!-- Banner-->         
         <?php
         $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
         if(base64_decode($_GET['video_cat'])){
             $catName= get_term(base64_decode($_GET['video_cat']))->name;
             $args = array(
    'post_type'      => 'video_gallery', // Your post type
    'posts_per_page' => 12,      // Number of posts to display
    'paged' => $paged,
    'tax_query'      => array(
        array(
            'taxonomy' => 'video_category', // Replace with your custom taxonomy name
            'field'    => 'term_id',                 // Use 'term_id', 'name', or 'slug'
            'terms'    => base64_decode($_GET['video_cat']),       // Replace with the term you want to query
        ),
    ),
);

$result = new WP_Query($args);

             $argsCount = array(
    'post_type'      => 'video_gallery', // Your post type
    'posts_per_page' =>-1,      // Number of posts to display
    'tax_query'      => array(
        array(
            'taxonomy' => 'video_category', // Replace with your custom taxonomy name
            'field'    => 'term_id',                 // Use 'term_id', 'name', or 'slug'
            'terms'    => base64_decode($_GET['video_cat']),       // Replace with the term you want to query
        ),
    ),
);

$resultCount = new WP_Query($argsCount);

         } else {
                   $args = array(
'post_type'=> 'video_gallery',
'orderby'    => 'ID',
'post_status' => 'publish',
'order'    => 'DESC',
'posts_per_page' => 12,
'paged' => $paged
);
$result = new WP_Query( $args );

        $argsCount = array(
'post_type'=> 'video_gallery',
'orderby'    => 'ID',
'post_status' => 'publish',
'order'    => 'DESC',
'posts_per_page' => -1,
);
$resultCount = new WP_Query( $argsCount );

         }


 ?>
             <!-- event-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
         <div class="container">

<div class="row align-items-center">
    <div class="col-md-6 col-sm-12">
        <div class="sec_title mb-4">
            <h1 class="sec_heading mb-2">Video Gallery (<?php echo (int)$resultCount->post_count; ?>)</h1>            
            <div class="section-border"><span></span></div>
        </div>
         </div>
         <div class="col-md-6 col-sm-12">
            <div class="filter-body">
                <form action="<?php echo site_url() ?>/video-gallery/" class="filter-form" method="GET">
                    <select class="form-select" name="video_cat">
                        <option value=""  selected >All Video</option>
                        <?php $cat =  get_categories( array('taxonomy' => 'video_category','type' => 'gallery','orderby' => 'ID','order'   => 'DESC')); ?>
                        <?php foreach($cat as $cccData){  ?> 
                        <option value="<?php echo base64_encode($cccData->term_id); ?>" <?php if($catName==$cccData->name){ echo "selected"; } ?>><?php echo $cccData->name; ?></option>
                        <?php } ?>
                        <!--<option value="">Independence Day</option>-->
                        <!--<option value="">Independence Day</option>-->
                        <!--<option value="">Independence Day</option>-->
                        <!--<option value="">Independence Day</option>-->
                        <!--<option value="">Independence Day</option>-->
                    </select>
                    <button  type="submit">Show</button>
                </form>
            </div>
         </div>
</div>



<div class="row g-4 video-gallery-row "> 

    <!--<div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--    <div class="video-box">-->
    <!--        <iframe width="420" height="315" src="https://www.youtube.com/embed/dmFUZOkEs9g" frameborder="0" allowfullscreen=""></iframe>-->
    <!--        <div class="video-info">-->
    <!--                <h4>Inter School Quiz Programme</h4>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
        
        
               <?php 

        
  
if ( $result-> have_posts() ) : ?>
<?php while ( $result->have_posts() ) : $result->the_post(); ?>

   <div class="col-xl-4 col-lg-4 col-md-6">
                  <div class="video-box">
                <?php 
if (str_contains($post->post_content, 'iframe')) { ?> 
    <?php echo $post->post_content; ?>
<?php } else { ?> 
<iframe width="420" height="315" src="<?php echo $post->post_content; ?>" frameborder="0" allowfullscreen=""></iframe>
<?php }

?>      
            
            <div class="video-info">
                    <h4><?php echo get_the_title(); ?></h4>
                </div>
            </div>
        </div>  
<?php endwhile; ?>
<?php endif; wp_reset_postdata(); ?>
        
        <!--?> -->
        
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--        <div class="video-box">-->
    <!--            <iframe width="420" height="315" src="https://www.youtube.com/embed/ln3HVm-WRl4" frameborder="0" allowfullscreen=""></iframe>-->
    <!--            <div class="video-info">-->
    <!--                    <h4>Quiz Competition (12th August 2014)</h4>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--        <div class="video-box">-->
    <!--            <iframe width="420" height="315" src="https://www.youtube.com/embed/Sja5pS7FuqE" frameborder="0" allowfullscreen=""></iframe>-->
    <!--            <div class="video-info">-->
    <!--                    <h4>Inter School Quiz Programme (12th August 2014)</h4>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--            <div class="video-box">-->
    <!--                <iframe width="420" height="315" src="https://www.youtube.com/embed/6OuJ_TiNXFI" frameborder="0" allowfullscreen=""></iframe>-->
    <!--                <div class="video-info">-->
    <!--                        <h4>Quiz Competition (12th August 2014)</h4>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--                <div class="video-box">-->
    <!--                    <iframe width="420" height="315" src="https://www.youtube.com/embed/3wJ8g49lpOg" frameborder="0" allowfullscreen=""></iframe>-->
    <!--                    <div class="video-info">-->
    <!--                            <h4>Sai Samiti (Quiz Competition 12th August 2014)</h4>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--        <div class="video-box">-->
    <!--            <iframe width="420" height="315" src="https://www.youtube.com/embed/TS30wi97nYA" frameborder="0" allowfullscreen=""></iframe>-->
    <!--            <div class="video-info">-->
    <!--                    <h4>Inter School Quiz Programme (12th August 2014)</h4>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--<div class="video-box">-->
    <!--    <iframe width="420" height="315" src="https://www.youtube.com/embed/j_epVPp28m0" frameborder="0" allowfullscreen=""></iframe>-->
    <!--    <div class="video-info">-->
    <!--            <h4>	Quiz Competition (12th August 2014)</h4>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    </div>-->
    <!--    <div class="col-xl-4 col-lg-4 col-md-6">-->
    <!--<div class="video-box">-->
    <!--    <iframe width="420" height="315" src="https://www.youtube.com/embed/VTqu-HT2agg" frameborder="0" allowfullscreen=""></iframe>-->
    <!--    <div class="video-info">-->
    <!--            <h4>Independence Day 2014</h4>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    </div>-->
        </div>  


<div class="qodef-custom-pagination">
<?php echo paginate_links( array(
'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
'total' => $result->max_num_pages,
'current' => $paged,
'prev_text' => '<span aria-label="' . esc_attr__( 'Previous page', 'textdomain' ) . '">' . esc_html__( '&laquo;', 'textdomain' ) . '</span>',
'next_text' => '<span aria-label="' . esc_attr__( 'Next page', 'textdomain' ) . '">' . esc_html__( '&raquo;', 'textdomain' ) . '</span>'
) ); ?>
</div>
</div>


</div>
</section>
              <!-- event-close -->
        </main>
             
        <?php
get_footer();