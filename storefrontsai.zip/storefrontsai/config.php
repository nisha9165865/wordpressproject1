 <?php

    $servername = "localhost";
    $username = "devupw8_saimandiruser";
    $password = "1q0?mZ8+%Mc*";
    $dbname = "devupw8_saimandirnoida";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    ?> 