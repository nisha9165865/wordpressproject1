<?php get_header(); ?>

 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <div class="container">
        <div class="breadcrumb_body">
            <ul class="p-0">
                <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>
                <li><?= get_the_title(); ?></li>
            </ul>
        </div>
    </div>
</div>
            <!-- Banner-->         
         
             <!-- About-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
                     <div class="row g-5 align-items-center">                         
                         <div class="col-xl-6 col-lg-6 col-md-12" >
                             <div class="right-about">
                                 <img src="<?= get_field("aboutimage",7);?>" alt="img">
                             </div>
                         </div>
                         <div class="col-xl-6 col-lg-6 col-md-12">
                            <div class="left-about">
                                <h1 class="sec_heading"><?= get_field("abouttitle",7);?></h1>
                                <div class="section-border"><span></span></div>
                                <p><?= get_field("aboutcontent",7);?></p>
        
                                <div class="btn-box">
                                    <a href="<?= site_url('/donate');?>" class="btn theme-btn2">Donate Now <i class="fa fa-angle-right" aria-hidden="true"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div>
             </section>
              <!-- About-close -->
        </main>
        
        <?php
get_footer();