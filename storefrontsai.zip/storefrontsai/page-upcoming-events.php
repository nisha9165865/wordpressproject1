<?php get_header(); ?>

 <main>
            <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
            <!-- Banner-->         
         
             <!-- event-start-->
             <section class="sec_padding about_sec inner-about-sec animate-bg" >
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
                     <div class="sec_title">
                    <h1 class="sec_heading mb-2">Upcoming Events</h1>
                    <div class="section-border"><span></span></div>
                </div>
                     <div class="list-parent mt-3">
    <div class="list-body">
    <div class="list-icon-box">
        <i class="bi bi-chevron-down"></i>
    </div>
    <div class="list-content-box">
        <h6>Your Sansthan is organizing a visit to AKSHAR DHAM MANDIR on 07th October 2014 for Senior Citizen.</h6>
    </div>
</div>

<div class="list-body">
    <div class="list-icon-box">
        <i class="bi bi-chevron-down"></i>
    </div>
    <div class="list-content-box">
        <h6>Those desirous may contact Dr. Bhardwaj Cell No. <a href="tel:9811014899">9811014899</a></h6>
    </div>
</div>

<div class="list-body">
    <div class="list-icon-box">
        <i class="bi bi-chevron-down"></i>
    </div>
    <div class="list-content-box">
        <h6>This visit includes meeting /dharshan of Maharaj Ji, all tours, visits within the Temple and musical fountain.</h6>
    </div>
</div>
</div>

<div class="row g-4 mt-3 pdf-row">
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Sai Vidya Niketan</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Inter School Quiz</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Sai Vidya Niketan</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Sai Vidya Niketan</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Quiz All Heads of Religious</a>
    </div>


    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Ramnavmi Invitation</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Mahasamadhi Invitation</a>
    </div>
    <div class="col-xl-3 col-lg-4 col-md-6">
        <a href="#"  class="pdf-btn"><i class="bi bi-file-earmark-pdf-fill"></i> Sai Pamphlet</a>
    </div>
    
</div>
                 </div>
             </section>
              <!-- event-close -->
        </main>
        
        <?php
get_footer();