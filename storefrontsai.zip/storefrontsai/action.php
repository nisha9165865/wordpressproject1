<?php
session_start();
include('config.php');
 
$name = $_POST['name'];
$_SESSION['name']= $name;
$amount_pay =$_POST['amount_pay'];
$_SESSION['amount_pay'] = $amount_pay;
$phone = $_POST['phone'];
$_SESSION['phone']= $phone;
$email = $_POST['email'];
$_SESSION['email']= $email;
$payment_status = "0";
//  print_r($_POST['interest_type']);
//  die();
if($_POST['address']==""){
    $_SESSION['address']= "noida";
}else {
   $_SESSION['address']= $_POST['address']; 
}
$address = $_SESSION['address'];
date_default_timezone_set('Asia/Kolkata'); // Set to Indian Standard Time
$added_on = date('Y-m-d H:i:s');
$form_type = $_POST['form_type'];
if(!empty($_POST['email']))
{
    $sql = "INSERT INTO givethegiftform (name,email,phone,address,amount_pay,form_type,payment_status,added_on)
            VALUES ('$name','$email','$phone','$address','$amount_pay','$form_type','$payment_status','$added_on')";
            
            if ($conn->query($sql) === TRUE) 
            {
               echo"sent";
                    
            }
            
            else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
    
    
    
}else{
    echo "Data Not Found..";
    die();
}

?>