<?php
get_header(); ?>
        <main>
              <!-- Banner-->
          <div class="banner_sec breadcrumb-sec" <?php if (!empty($banner_image)) { ?> style="background: url(<?= $banner_image; ?>) no-repeat; background-size: cover;" <?php } ?>>
    <!--<div class="container">-->
    <!--    <div class="breadcrumb_body">-->
    <!--        <ul class="p-0">-->
    <!--            <li><a href="<?= site_url('/'); ?>"><i class="bi bi-house-door-fill"></i> Home</a></li>-->
    <!--            <li><?= get_the_title(); ?></li>-->
    <!--        </ul>-->
    <!--    </div>-->
    <!--</div>-->
</div>
           <!-- Banner-->    
         
             <!-- About-start-->
             <section class="sec_padding contact_sec animate-bg" data-aos="fade-up">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-top">
                 <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/bg/round-bg.webp" alt="img" class="round-bg-bottom">
                 <div class="container">
                     <div class="row pooja-row">  
                        <div class="col-xl-4 col-lg-4 col-md-12">
                            <div class="pooja-img">
                                <img src="<?= get_stylesheet_directory_uri();?>/sai_assets/images/home/p1.webp" alt="img">
                            </div>
                        </div>
                         <div class="col-xl-8 col-lg-8 col-md-12">
                            <div class=" pooja-body">
                                <div class="contact_heading">
                                    <h4>Online Pooja</h4>
                                    <div class="section-border"><span></span></div>
                                 </div>
                                 <form class="row g-4 ContactForm" method="POST" id="ContactForm">
                                     <div id="message"></div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Name<sup>*</sup></label>
                                            <input type="text" name="name" id="name" class="form-control">
                                               <span class="error" id="username_err"> </span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Email<sup>*</sup></label>
                                            <input type="email" name="email" id="email_id" class="form-control">
                                            <span id="email_err" class="error"></span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Contact Phone<sup>*</sup></label>
                                            <input type="tel" name="phone" id="phone" class="form-control">
                                             <span id="mobile_err" class="error"></span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Amount<sup>*</sup></label>
                                            <input type="text" name="amount_pay" id"amount" class="form-control amount">
                                             <span id="amount_err" class="error"></span>
                                        </div>
                                    </div>                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Address<sup>*</sup></label>
                                            <textarea   rows="2" name="address" id"address" class="address form-control"></textarea>
                                             <span id="address_err" class="error"></span>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label" for="">Purpose<sup>*</sup></label>
                                            <textarea rows="2" name="purpose" id"purpose" class="form-control purpose" ></textarea>
                                            <span id="purpose_err" class="error"></span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <button type="button" name="submit" class="btn theme-btn mb-4 btnsubmit">Submit <i class="fa fa-angle-right" aria-hidden="true"></i><span class="loader"></span></button>
                                        <!--<a href="#" class="btn theme-btn mb-4">Submit<i class="fa fa-angle-right" aria-hidden="true"></i>-->
                                        <!--</a>-->
                                    </div>
                                    <span class="mailNotificationcontact" style="color:green; display:none;">Your Data Has Been Sent Successfully..</span>
                                </form>
                            </div>
                        </div>
                     </div>
                 </div>
             </section>
              <!-- About-close -->
        </main>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
      <!--<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>-->
      <!--<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>-->
        
        <script>
 jQuery(document).ready(function () {
       

//  End Form validation
});




$(document).ready(function () {
    
    
   $('#phone').on('input', function () {
        checkmobile();
    });  
    
        $('#name').on('input', function () {
        checkuser();
    }); 
     
      $('#email_id').on('input', function () {
        checkemail();
    });
    
       $('.amount').on('input', function () {
        checkamount();
    });
    
      $('.address').on('input', function () {
        checkaddress();
    });
    
    $('.purpose').on('input', function () {
        checkpurpose();
    });
     //   Form validation   
function checkmobile() {
   
    if (!$.isNumeric($("#phone").val())) {
        $("#mobile_err").html("only number is allowed");
        return false;
    } else if ($("#phone").val().length != 10) {
        $("#mobile_err").html("10 digit required");
        return false;
    }
    else {
        $("#mobile_err").html("");
        return true;
    }
}    


function checkuser() {
    var user = $('#name').val();
    if (user == "") {
       $('#username_err').html('required field');
        return false;
    } else {
        $('#username_err').html('');
        return true;
    }
}


function checkemail() {
    var pattern1 = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    var email = $('#email_id').val();
    var validemail = pattern1.test(email);
    if (email == "") {
        $('#email_err').html('required field');
        return false;
    } else if (!validemail) {
        $('#email_err').html('invalid email');
        return false;
    } else {
        $('#email_err').html('');
        return true;
    }
}
    
function checkaddress() {
    var address = $('.address').val();
    if (address == "") {
        $('#address_err').html('required field');
        return false;
    } else {
        $('#address_err').html('');
        return true;
    }
}

function checkamount(){
    if ($(".amount").val() == "") {
        $('#amount_err').html('required field');
        return false;
    } else if (!$.isNumeric($(".amount").val())) {
        $("#amount_err").html("only number is allowed");
        return false;
    }  else  {
        $("#amount_err").html("");
        return true;
    }
}

function checkpurpose(){
       var purpose = $('.purpose').val();
    if (purpose == "") {
        $('#purpose_err').html('required field');
        return false;
    } else {
        $('#purpose_err').html('');
        return true;
    }
}

    $(".btnsubmit").click(function (e) {
        e.preventDefault();
        submitForm();
    });

    $(".loader").hide();

    function submitForm() {
          if (!checkuser() && !checkemail() && !checkmobile() && !checkaddress() && !checkamount() && !checkpurpose()) {
        
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
        } else if (!checkuser() || !checkemail() || !checkmobile() || !checkaddress() || !checkamount() || !checkpurpose()) {
            $("#message").html(`<div class="alert alert-warning">Please fill all required field</div>`);
        }
        else {
        let email = $('#email_id').val();

        if (email) {
            
            $(".btnsubmit").html("Please Wait... <span class='loader'></span>");
            $(".loader").show();
           $('.btnsubmit').prop('disabled', true);
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('wp-content/themes/storefront/actionsecond.php'); ?>',
                dataType: 'text',
                data: $("#ContactForm").serialize(),
                success: function (response) {
                    var resultText = $.trim(response);
                    console.log(resultText);

                    if (resultText == "sent") {
                        
                        // $(".mailNotificationcontact").css("display", "block");
                        // setTimeout(function () {
                        //     // Redirect to the payment gateway page
                            
                        //     $("#ContactForm")[0].reset();
                        // }, 1000);
                           $("#ContactForm")[0].reset();
                        window.location.href = '<?php echo site_url('wp-content/themes/storefront/payment-gateway/easebuzz.php'); ?>';
                        $(".btnsubmit").html("Submit");
                    } else {
                        alert("error");
                    }
                },
                complete: function () {
                    // Re-enable the button after the request is complete
                    $('.btnsubmit').prop('disabled', false);
                }
            });
        }
        }
    }

});

</script>

<?php
get_footer();