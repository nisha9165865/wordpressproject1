<?php
get_header(); ?>

 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->


   
    <!-- Book Selling Area Start -->
   <section class="dei_sec sec_padding">
      <div class="container">
         <div class="row align-items-center g-4">
             
              <?php
            $args = array(
            'post_type' => 'best_selling_book', 
            'post_status' => 'publish',
            'order' => 'ASC',
            'posts_per_page' => -1
            );
            
              $queries = new wp_Query($args);
                          
              foreach($queries->posts as $query){
                  $post_id = $query->ID;
                  $post_content = $query->post_content;
            ?>
             
             
            <div class="col-md-6 col-lg-4 col-xl-4">
               <div class="dei_figure wow bounceIn">
			<img src="<?= get_the_post_thumbnail_url($post_id);?>" class="img-responsive" alt="">
                  <!-- <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/book-selling.jpg" class="img-responsive" alt=""> -->
               </div>
            </div>
            <div class="col-md-6 col-lg-8 col-xl-8">
               <div class="dei_word ps-xl-5 wow bounceInRight">
                  <div class="sec_title">
			   <h2 class="main_title"><?= get_the_title($post_id);?></h2>
                     <!-- <h2 class="main_title">Best Selling Book From <span class="text-color-1">Nandita Pandey</span></h2> -->
                  </div>
			   <p><?= $content = get_post_field( 'post_content', $post_id);?></p>

                  <!-- <p>Your appearance speaks about you, even before you start any conversation. Thus, it is important that you make,
                  "appearance" speak in your favour, to project a winning image. The book gives the science behind the art of dressing. It
                  contains easy do-able steps and secrets, to help men and women in business and corporates, to present oneself
                  appropriately, confidently and successfully in any professional situation. * This is an exclusive Trader's only edition.
                  Contact us for an exclusive copy</p> -->
                  <!--<a href="#" class="btn btn_theme mt-xl-4 mt-3">Read More <i-->
                  <!--      class="bi bi-chevron-double-right ms-2"></i></a>-->
               </div>
            </div>
            <?php } ?>
            
            
         </div>
      </div>
   </section>
   <!-- Book Selling Area End -->
   
   
   
   
   
 <?php
get_footer();
?>