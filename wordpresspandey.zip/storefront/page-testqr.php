<?php
get_header(); 


include 'config.php';

?>

<style>
    .error
    {
        color:#862723 !important;
    }
</style>

 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
   
   
   
   
  <section class="sec_padding atoz_section">
   <div class="container">
      <div class="row g-5">
         <div class="col-lg-4 col-md-5">
            <div class="about_right wow bounceInRight">
               <img src="https://nanditapandey.com/wp-content/uploads/2023/10/Untitled-2.jpg" alt="">
            </div>
         </div>
         
         <div class="col-lg-8 col-md-7 form-div">
               <!--<h5>* If above 999, delivery free. Else 250</h5>-->
           <div class="contact_right ">
                <form method="POST" id="mainForm" class="mainForm" name="mainForm" enctype="multipart/form-data">
               <div class="row g-4">
                  <div class="col-md-6">
                     <label for="name" class="form-label">Full Name<sup style="color: red;">*</sup></label>
                     <input type="text" name="name" id="" class="form-control" placeholder="Full Name" required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Email Address<sup style="color: red;">*</sup></label>
                     <input type="email" name="email" id="" class="form-control" placeholder="Email"  required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Mobile Number<sup style="color: red;">*</sup></label>
                     <input type="tel" name="mobileno" id="" class="form-control" placeholder="Mobile Number" required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Alternate Number</label>
                     <input type="tel" name="alternateno" id="" class="form-control" placeholder="Alternate Number">
                  </div>
                  
                  <div class="col-md-12">
                     <label for="" class="form-label">Shipping Address<sup style="color: red;">*</sup></label>
                  </div>
            <div class="col-md-12">
                      <div class="row g-4">
                      <div class="col-md-6">
                     <input type="text" name="Shippingstreet" id="" class="form-control" style="color:black;" placeholder="Street"  required>
                  </div>
                  <div class="col-md-6">
                     <input type="text" name="Shippingcity" id="Shippingcity" class="form-control" style="color:black;" placeholder="City"  required>
                  </div>
                  <div class="col-md-6">
                     <input type="text" name="Shippingstate" id="Shippingstate" class="form-control" style="color:black;" placeholder="State"  required>
                  </div>
                  <div class="col-md-6">
                      <input type="number" name="Shippingpincode" id="Shippingpincode" class="form-control" style="color:black;" placeholder="Pincode" pattern="[0-9]{6}" maxlength="8" required>
                  </div>
                  <div class="col-md-12">
                      <input type="text" name="Shippinglandmark" id="Shippinglandmark" class="form-control" style="color:black;" placeholder="Landmark (Optional)">
                  </div>
                  </div>
            </div>
                  <div class="col-md-12">
                    <label for="" class="form-label">Billing Address  </label>
                    <input type="checkbox" id="sameAsShipping"> Different to Shipping Address
                    </div>
                  <div id="billingFields" class="col-md-12">
               <div class="row g-4">
                    <div class="col-md-6">
                    <input type="text" name="billing_street" id="billing_street" class="form-control" style="color:black;" placeholder="Street">
                </div>
                <div class="col-md-6">
                    <input type="text" name="billing_city" id="billing_city" class="form-control" style="color:black;" placeholder="City">
                </div>
                <div class="col-md-6">
                    <input type="text" name="billing_state" id="billing_state" class="form-control" style="color:black;" placeholder="State">
                </div>
                <div class="col-md-6">
                    <input type="number" name="billing_pincode" id="billing_pincode" pattern="[0-9]{6}" class="form-control" style="color:black;" placeholder="Pincode">
                </div>
                <div class="col-md-12">
                    <input type="text" name="billing_landmark" id="billing_landmark" class="form-control" style="color:black;" placeholder="Landmark (Optional)">
                </div>
               </div>
            </div>
                    <!--start code -->
                        <?php
                $workshops = array();
                $read = "SELECT * FROM `booksdetails`";
                $result = mysqli_query($conn, $read);
            
                ?>
                    <table class="table table-bordered" id="item_table">
                      <tr>
                       <th valign="middle">Selection</th>
                       <th valign="middle">Quantity</th>
                       <th valign="middle"><i class="bi bi-currency-rupee"></i>Price</th>
                       <th valign="middle" class="text-center"><button type="button" name="add" class="btn btn-success btn-sm add">+</button></th>
                      </tr>
                      <tr>
                        <td><select class="form-select item_name" data-search="on" name="item_name[]" id="item_name" required> 
                        <option selected disabled>Select Book</option>
                        <?php foreach ($result as $workshop) { ?>
                       <option  value="<?= $workshop['bookname']; ?>"><?= $workshop['bookname']; ?></option>
                       <?php } ?>
                        </select></td>
                        <td><input type="number" min="1" name="item_quantity[]" class="form-control item_quantity" id="item_quantity" placeholder="Enter Quantity" required/></td>
                        <td><input type="text" name="item_price[]" class="form-control item_price" id="item_price" readonly/></td>
                        <td width="80" class="text-center"><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</button></td>

                      </tr>
                     </table>
                     <table class="mt-0">
                         <tr>
                          <td style="
    width: 46%;
    background: transparent;
"> </td>
                          <td style="float:right">
                              <label for="validationServer03" class="form-label me-2">Total Price :</label>
                              <input type="text" name="total_price" id="amount" readonly></td>
                        </tr>
                        </table>
                       <div class="col-md-12 mt-0">
                    <label for="" class="form-label">Do You Want GST Invoice ?</label>
                    <input type="checkbox" id="gstdetail">
                    </div>
                    
                  <div id="gstfields" class="col-md-12">
               <div class="row g-4">
                    <div class="col-md-6">
                    <input type="text" name="companyname" id="companyname" class="form-control" style="color:black;" placeholder="Company Name">
                </div>
                <div class="col-md-6">
                    <input type="text" name="gstnumber" id="gstnumber" class="form-control" style="color:black;" placeholder="GST No.">
                </div>
               </div>
               
            </div>
            
<input class="form-control" type="hidden" id="pa" value="merchant3@icici">
<input class="form-control" type="hidden" id="pn" value="test merchant">
<input class="form-control" type="hidden" id="tn" value="test note">
<input class="form-control" type="hidden" id="mc" value="1234">
<input class="form-control" type="hidden" id="tid" value="">
<input class="form-control" type="hidden" id="tr" value="test reference id">
<input class="form-control" type="hidden" id="url" value="https://teztytreats.com/demo">
           


                  <div class="col-md-12 text-end">
                     <!--<button type="submit" name="submit" class="btn btn_theme"onclick="pay_now()" id="btn">Submit<i-->
                     <!--      class="fa-regular fa-paper-plane ms-2"></i></button>-->
                           <input type="button" name="btn" id="btn" value="Submit" onclick="pay_now()"/>
                  </div>
               </div>

            </form>

         </div>
      </div>
   </div>
</section>
 
<script src="<?= get_stylesheet_directory_uri();?>/assetss/js/your-script.js"></script>
 <script>


    jQuery(document).ready(function () {
       
           $("#mainForm").validate({
            rules: {
                   name:{
                    required:true
                },
                mobileno:{
                    required:true,
                    minlength: 10,
                   maxlength: 12
                },
                email:{
                    required:true
                },
                Shippingstreet:{
                    required:true
                },
                Shippingcity:{
                    required:true
                },
                Shippingstate:{
                    required:true
                },
                Shippingpincode:{
                    required:true
                },
                item_name:{
                    required:true
                },
                item_price:{
                    required:true
                },
                item_quantity: {
                   required: true,
                },
            },
            // Specify validation error messages
            messages: {
                name: "Please provide a valid name.",
                Shippingstreet: {
                    required: "please provide a street",
                },
                Shippingcity: {
                    required: "please provide a city",
                },
                Shippingstate: {
                    required: "please provide a state",
                },
                Shippingpincode: {
                    required: "please provide a 6 digit pincode",
                },
                item_name: {
                    required: "please select collection",
                },
                item_quantity: {
                    required: "please enter quantity",
                },
                mobileno: {
                    required: "Please provide a phone number",
                    minlength: "Phone number must be min 10 characters long",
                    maxlength: "Phone number must not be more than 12 characters long"
                },
                email: {
                    required: "Please enter your email",
                    minlength: "Please enter a valid email address"
                },
            },
            errorPlacement: function(error, element) {
                error.insertAfter(element); // Display error messages below the respective input fields
            }
          });

    });
  </script>

<script>
    const sameAsShippingCheckbox = document.getElementById("sameAsShipping");
    const billingFields = document.getElementById("billingFields");

    sameAsShippingCheckbox.addEventListener("change", function () {
        if (this.checked) {
            billingFields.style.display = "block";
        } else {
            billingFields.style.display = "none";
        }
    });

    // Initialize the display based on the checkbox state
    if (sameAsShippingCheckbox.checked) {
        billingFields.style.display = "block";
    } else {
        billingFields.style.display = "none";
    }
</script>


<script>
    const gstdetailCheckbox = document.getElementById("gstdetail");
    const gstfields = document.getElementById("gstfields");

    gstdetail.addEventListener("change", function () {
        if (this.checked) {
            gstfields.style.display = "block";
        } else {
            gstfields.style.display = "none";
        }
    });

    // Initialize the display based on the checkbox state
    if (gstdetail.checked) {
        gstfields.style.display = "block";
    } else {
        gstfields.style.display = "none";
    }
</script>

<script>
jQuery(document).ready(function() {
    jQuery(document).on('click', '.add', function(){
        var html = '';
        html += '<tr>';
        html += '<td><select class="form-select item_name" data-search="on" name="item_name[]"> <option selected disabled>Select Book</option> <option value="Book">Book</option><option value="Journal">Journal</option> <option value="Cards">Cards</option><option value="Book + Cards">Book + Cards</option><option value="Book  + Journal">Book  + Journal</option><option value="Journal + Cards">Journal + Cards</option><option value="All Three">All Three</option></select></td>';
        html += '<td><input type="number" min="1" name="item_quantity[]" class="form-control item_quantity" placeholder="Enter Quantity" required/></td>';
        html += '<td><input type="text" class="form-control form-control-sm item_price" name="item_price[]" style="height: 47px; min-height: 47px;"></td>';
        html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</em></button></td></tr>';
        $('#item_table').append(html);

        // Initialize Select2 on the newly added select element
        // $('.form-select').select2();
    });

    $(document).on('click', '.remove', function(){
        $(this).closest('tr').remove();
    });
 
});


jQuery(document).ready(function() {
  function updatePrice() {
    var total = 0; // Initialize the total price to zero

    // Loop through each row in the table
    $('table#item_table tr').each(function() {
      var quantity = parseInt($(this).find('.item_quantity').val());
      var priceField = $(this).find('.item_price');
      var selectedBook = $(this).find('.item_name').val();

      $.ajax({
        type: 'GET',
        url: '/wp-content/themes/storefront/get_book_price.php',
        data: {
          bookname: selectedBook
        },
        success: function(response) {
          var data = JSON.parse(response);
          if (data.bookprice) {
            var totalPrice = quantity * parseFloat(data.bookprice);
            priceField.val(totalPrice.toFixed(2));
            total += totalPrice; // Add the row's total to the overall total
            $('#amount').val(total.toFixed(2)); // Update the total price input field
          } else {
            priceField.val('Price not found');
          }
        },
        error: function() {
          priceField.val('Error');
        }
      });
    });
  }

  // Initialize the quantity change event for the initial rows
  $(document).on('input', '.item_quantity', updatePrice);

  // Add event listener for adding rows
  jQuery(document).on('click', '.add', function() {
    var newRow = $('table#item_table tr:last')
      .clone()
      .find('.item_quantity')
      .unbind()
      .end()
      .removeClass('add');

    newRow.find('select.item_name').val('Select Book');
    newRow.find('input.item_quantity').val('');
    newRow.find('input.item_price').val('');

    newRow.find('.item_quantity').on('input', updatePrice);

   // $('table#item_table').append(newRow); // Append the new row to the table
  });

  // Add event listener for removing rows
  jQuery(document).on('click', '.remove', function() {
    $(this).closest('tr').remove();
    updatePrice(); // Recalculate prices after row removal
  });
});




// jQuery(document).ready(function () {
//     const mainForm = document.getElementById('mainForm');
//     const modal = $('#myModal');
//     const submitButton = $('#submit');
//     const nextButton = $('#nextButton');

//     // Handle form submission
//     mainForm.addEventListener('submit', function (e) {
//         if ($("#mainForm").valid()) {
//             // Form is valid, open the modal
//             modal.modal('show');
//         }
//         e.preventDefault(); // Prevent the default form submission
//     });

//     // Handle the "Next" button click inside the modal
//     nextButton.on('click', function () {
//         // You can perform validation on the data if needed

//         // Combine the data from the main form
//         const formData = new FormData(mainForm);

//         var ajaxurl = "https://nanditapandey.com/wp-content/themes/storefront/page-payment.php";

//         // Send the data to the server using AJAX
//         $.ajax({
//             url: ajaxurl,
//             data: formData,
//             type: 'POST',
//             contentType: false,
//             cache: false,
//             processData: false,
//             success: function (response) {
//                 // Handle the response from the server
//                 $("#mainForm")[0].reset()
//                 window.location.href = "https://nanditapandey.com/thanku/";
//             }
//         });

//         // Close the modal
//         modal.modal('hide');
//     });
// });



function pay_now() {
    // Check if the form is valid
    if ($("#mainForm").valid()) {
        var ajaxurl = "https://nanditapandey.com/wp-content/themes/storefront/page-paymenttestqr.php";
        var formData = new FormData(document.getElementById('mainForm'));
        var total_price = formData.get('total_price');

        var options = {
            "key": "rzp_test_M6L3ymxUOWizb3",
            "amount": total_price * 100,
            "currency": "INR",
            "name": "Buy The Book",
            "description": "Test Transaction",
            "image": "https://image.freepik.com/free-vector/logo-sample-text_355-558.jpg",
            "handler": function (response) {
                // Now include the payment ID along with form data in the same AJAX request
                formData.append('payment_id', response.razorpay_payment_id);

                jQuery.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: formData, // Include both form data and payment ID
                    processData: false,
                    contentType: false,
                    success: function (result) {
                        console.log(result);
                        $("#mainForm")[0].reset();
                        window.location.href = "https://nanditapandey.com/thanku/";
                    }
                });
            }
        };

        var rzp1 = new Razorpay(options);
        rzp1.open();
    }
}









    
  jQuery(document).ready(function () {
    // Select the checkbox element
    var $checkbox = $("#sameAsShipping");

    // Select the input fields
    var $billingStreet = $("#billing_street");
    var $billingCity = $("#billing_city");
    var $billingState = $("#billing_state");
    var $billingPincode = $("#billing_pincode");
    var $billingLandmark = $("#billing_landmark");

    // Function to toggle the 'required' attribute based on checkbox state
    function toggleRequired() {
      var isChecked = $checkbox.is(":checked");
      $billingStreet.prop("required", isChecked);
      $billingCity.prop("required", isChecked);
      $billingState.prop("required", isChecked);
      $billingPincode.prop("required", isChecked);
      $billingLandmark.prop("required", isChecked);
    }

    // Initially, set the 'required' attribute based on checkbox state
    toggleRequired();

    // Add a change event listener to the checkbox
    $checkbox.change(function () {
      toggleRequired();
    });
  });    
 
jQuery(document).ready(function () {
    // Select the checkbox element
    var $checkbox = $("#gstdetail");

    // Select the input fields
    var $companyName = $("#companyname");
    var $gstNumber = $("#gstnumber");

    // Function to toggle the 'required' attribute based on checkbox state
    function toggleRequired() {
      var isChecked = $checkbox.is(":checked");
      $companyName.prop("required", isChecked);
      $gstNumber.prop("required", isChecked);
    }

    // Initially, set the 'required' attribute based on checkbox state
    toggleRequired();

    // Add a change event listener to the checkbox
    $checkbox.change(function () {
      toggleRequired();
    });
  });    
    

</script>
 
 <?php
get_footer();
?>