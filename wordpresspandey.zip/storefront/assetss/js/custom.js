
(function ($) {
  "use strict";

  //(1)=============Header Fixed Start=============//
  $(window).scroll(function () {
    var sticky = $('.main_header'),
      scroll = $(window).scrollTop();

    if (scroll >= 50) sticky.addClass('sticky');
    else sticky.removeClass('sticky');
  });

// Stellarnav Menu
// --------------------------------------------------------------

  jQuery('.stellarnav').stellarNav({
    theme: 'dark',
    breakpoint: 1080,
    position: 'left',
    phoneBtn: false
  });

  //=============Placement Slider Start=============//

  $(document).ready(function () {
    $('.image_carousel').owlCarousel({
      loop: true,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      smartSpeed: 450,
      mouseDrag: false,
      navText: ['<i class="bi bi-chevron-double-left"></i>', '<i class="bi bi-chevron-double-right"></i>'],
      margin: true,
      dots: false,
      margin: 0,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: false,
        },
        360: {
          items: 1,
          nav: false,
        },
        480: {
          items: 1,
          nav: false,
        },
        414: {
          items: 1,
          nav: false,
        },
        600: {
          items: 1,
          nav: false,
        },
        768: {
          items: 1,
          nav: true,
        },
        1000: {
          items: 1,
          nav: true,
          loop: true,
        }
      }
    })
  });

  $(document).ready(function () {
    $('.breadcrumb_slide').owlCarousel({
      loop: true,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      smartSpeed: 450,
      mouseDrag: false,
      navText: ['<i class="bi bi-chevron-double-left"></i>', '<i class="bi bi-chevron-double-right"></i>'],
      margin: true,
      dots: false,
      nav:false,
      margin: 0,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
        },
        360: {
          items: 1,
        },
        480: {
          items: 1,
        },
        414: {
          items: 1,
        },
        600: {
          items: 1,
        },
        768: {
          items: 1,
        },
        1000: {
          items: 1,
          loop: true,
        }
      }
    })
  });
   
  $(document).ready(function () {
    $('.about-carousel').owlCarousel({
      loop: true,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      smartSpeed: 450,
      mouseDrag: false,
      navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
      margin: true,
      dots: false,
      margin: 0,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: true,
        },
        360: {
          items: 1,
          nav: true,
        },
        480: {
          items: 1,
          nav: true,
        },
        414: {
          items: 1,
          nav: true,
        },
        600: {
          items: 1,
          nav: true,
        },
        768: {
          items: 1,
          nav: true,
        },
        1000: {
          items: 1,
          nav: true,
          loop: true,
        }
      }
    })
  });

  $(document).ready(function () {
    $('.trusted_carousel').owlCarousel({
      loop: true,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      smartSpeed: 450,
      mouseDrag: false,
      navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
      margin: true,
      dots: false,
      margin: 0,
      animateIn: 'fadeIn',
      animateOut: 'fadeOut',
      responsiveClass: true,
      responsive: {
        0: {
          items: 1, 
          nav: true,
        },
        360: {
          items: 1,
          nav: true,
        },
        480: {
          items: 1,
          nav: true,
        },
        414: {
          items: 1,
          nav: true,
        },
        600: {
          items: 1,
          nav: true,
        },
        768: {
          items: 1,
          nav: true,
        },
        1000: {
          items: 1,
          nav: true,
          loop: true,
        }
      }
    })
  });
  
  
   $(document).ready(function () {
    $('.testimonial_carousel').owlCarousel({
      loop: true,
      autoplay: true,
      autoplayTimeout: 3000,
      autoplayHoverPause: true,
      smartSpeed: 450,
      mouseDrag: false,
      navText: ['<i class="bi bi-chevron-double-left"></i>', '<i class="bi bi-chevron-double-right"></i>'],
      margin: true,
      dots: false,
      margin: 50,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: false,
        },
        360: {
          items: 1,
          nav: false,
        },
        480: {
          items: 1,
          nav: false,
        },
        414: {
          items: 1,
          nav: false,
        },
        600: {
          items: 2,
          nav: false,
        },
        768: {
          items: 2,
          nav: true,
        },
        1000: {
          items: 3,
          nav: true,
          loop: true,
        }
      }
    })
  });
  

// AOS Animation Start//

  new WOW().init();
// AOS Animation End//
 
  //=============Scroll Top=============//

    $(document).ready(function () {
      "use strict";

      //Scroll back to top

      var progressPath = document.querySelector('.progress-wrap path');
      var pathLength = progressPath.getTotalLength();
      progressPath.style.transition = progressPath.style.WebkitTransition = 'none';
      progressPath.style.strokeDasharray = pathLength + ' ' + pathLength;
      progressPath.style.strokeDashoffset = pathLength;
      progressPath.getBoundingClientRect();
      progressPath.style.transition = progressPath.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
      var updateProgress = function () {
        var scroll = $(window).scrollTop();
        var height = $(document).height() - $(window).height();
        var progress = pathLength - (scroll * pathLength / height);
        progressPath.style.strokeDashoffset = progress;
      }

      updateProgress();
      $(window).scroll(updateProgress);
      var offset = 50;
      var duration = 550;
      jQuery(window).on('scroll', function () {
        if (jQuery(this).scrollTop() > offset) {
          jQuery('.progress-wrap').addClass('active-progress');
        } else {
          jQuery('.progress-wrap').removeClass('active-progress');
        }
      });
      jQuery('.progress-wrap').on('click', function (event) {
        event.preventDefault();
        jQuery('html, body').animate({ scrollTop: 0 }, duration);
        return false;
      })
    });
    
    
  })(jQuery); 