<?php
get_header(); ?>

 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->



  <!-- DEI Area Start -->
   <section class="dei_sec sec_padding">
      <div class="container">
         <div class="row align-items-center flex-md-row  flex-column-reverse g-4">
             
                           <?php
                            $args = array(
                            'post_type' => 'dei', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                            
                              $queries = new wp_Query($args);
                                          
                              foreach($queries->posts as $query){
                                  $post_id = $query->ID;
                                  $post_content = $query->post_content;
                            ?>
             
            <div class="col-md-6 col-lg-4 col-xl-4">
               <div class="dei_figure wow bounceIn">
                  <img src="<?= get_the_post_thumbnail_url($post_id);?>" class="img-responsive" alt="">
			   <!-- <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/dei.png" class="img-responsive" alt=""> -->
               </div>
            </div>
            <div class="col-md-6 col-lg-8 col-xl-8">
               <div class="dei_word ps-xl-5 wow bounceInRight">
                     <div class="sec_title">
				 <h2 class="main_title"><?= get_the_title($post_id);?></h2>
                        <!-- <h2 class="main_title">DEI <span class="text-color-1">(Diversity, Equity, and Inclusion)</span></h2> -->
                     </div>
                  <p><?= $content = get_post_field( 'post_content', $post_id);?></p>

			   <!-- <p>In today’s rapidly changing world, the true essence of DEI (Diversity, Equity, and Inclusion) often eludes us due to
                  unconscious biases or a lack of openness within our organizations.</p>
                  <p>I firmly believe that when we practice DEI, we embrace the recognition of diverse talents, provide equal opportunities,
                  and create an inclusive environment. This, in turn, paves the way for a floodgate of success for both individuals and
                  organizations alike. It opens our minds to new perspectives, fuels innovation, and welcomes novel opportunities.</p>
                  <p>In an ever-evolving market landscape, companies that fail to adapt will inevitably stagnate. By remaining receptive to
                  change, we position ourselves for growth and prosperity. It is through an open mindset that we continuously learn and
                  evolve, staying ahead of the curve.</p> -->
                 
            </div>
            
            <?php } ?>
            
            
         </div>
      </div>
   </section>
   <!-- DEI Area End -->
  
 
</body>
</html>

<?php
get_footer();
?>