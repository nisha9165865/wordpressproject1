<?php
get_header(); ?>

  <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
   
   
   
   <section class="sec_padding">
      <div class="container">
           <div class="row g-4 blog_row">
               
              
           
               
   
   <p><iframe src="https://open.spotify.com/embed-podcast/show/1s93Khbwi1kGaAhSxVcqKr" width="100%" height="232" frameborder="0"></iframe></p>
   
<span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span>

   
   <iframe src="https://open.spotify.com/embed/playlist/0iwp5S3yrMfvtALTBYoBU4" width="100%" height="380" frameborder="0"></iframe>
   
     </div>
      </div>
  </section>

  <?php
get_footer();
?> 