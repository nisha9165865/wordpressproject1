<?php
session_start();
include 'config.php';


// require 'vendor/autoload.php';
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\SMTP;
// use PHPMailer\PHPMailer\Exception;
require 'PHPMailer-master/PHPMailerAutoload.php';


if (isset($_POST)) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobileno = $_POST['mobileno'];
    $alternateno = $_POST['alternateno'];
    $Shippingstreet = $_POST['Shippingstreet'];
    $Shippingcity = $_POST['Shippingcity'];
    $Shippingstate = $_POST['Shippingstate'];
    $Shippingpincode = $_POST['Shippingpincode'];
    $Shippinglandmark = $_POST['Shippinglandmark'];
    $billing_street = $_POST['billing_street'];
    $billing_city = $_POST['billing_city'];
    $billing_state = $_POST['billing_state'];
    $billing_pincode = $_POST['billing_pincode'];
    $billing_landmark = $_POST['billing_landmark'];
    $item_names = $_POST['item_name'];
    $item_prices = $_POST['item_price'];
    $item_quantities = $_POST['item_quantity'];

    // Serialize arrays before inserting them
    $serialized_item_names = implode(', ', $item_names);
    $serialized_item_prices = implode(', ', $item_prices);
    $serialized_item_quantities = implode(', ', $item_quantities);

    // Handle the data for GST invoice
    $companyname = $_POST['companyname'];
    $gstnumber = $_POST['gstnumber'];

    // Calculate total price
    $total_price = $_POST['total_price'];

    $payment_status = "Not Paid";

    $added_on = date('Y-m-d h:i:s');
        function generateOrderID($name)
        {
            // Generate a unique order ID using the user's name, a random number, and timestamp
            $randomNumber = mt_rand(1000, 9999); // You can adjust the range based on your needs
            $timestamp = time();
            $orderID = "{$name}_{$randomNumber}_{$timestamp}";
    
            return $orderID;
        }
        $orderID = generateOrderID($name);

     $payment_id = $_POST['payment_id'];

        
        
     $query= "INSERT INTO wp_formdata(order_id, name, email, mobileno, alternateno, Shippingstreet, Shippingcity, Shippingstate, Shippingpincode,
        Shippinglandmark, billing_street, billing_city, billing_state, billing_pincode, billing_landmark,
        item_name, item_price, item_quantity, companyname, gstnumber, total_price, payment_status,payment_id,added_on) 
        VALUES ('$orderID', '$name', '$email', '$mobileno', '$alternateno', '$Shippingstreet', '$Shippingcity', '$Shippingstate', '$Shippingpincode',
        '$Shippinglandmark', '$billing_street', '$billing_city', '$billing_state', '$billing_pincode', '$billing_landmark',
        '$serialized_item_names', '$serialized_item_prices', '$serialized_item_quantities', '$companyname', '$gstnumber', '$total_price', '$payment_status','$payment_id','$added_on')";
     $sql = mysqli_query($conn, $query);
     
     if($sql){
                            $admin_html .='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                <html xmlns="http://www.w3.org/1999/xhtml">
                                <head>
                                <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                <title>Buy The Book</title>
                                </head>
                                <body style="margin:0px;">
                                <div style="background: #fff; border: solid 1px #ddd; max-width: 650px; width: 100%; margin: 0 auto; background-color: #fff;">
                                <table width="100%" style="width:100%; border:none;">
                                <tr >
                                    <td style="border-bottom:solid 1px #ddd; text-align:center;"><a href="https://nanditapandey.com/" target="_blank"> <img src="https://nanditapandey.com/wp-content/themes/storefront/assetss/images/logo.png" alt="Logo"  style="margin-bottom: 8px; height: 100px; color: #FFF;"/> </a></td>
                                </tr>
                                        
                                <tr>
                                    <td style="padding:10px;border:solid 1px #ddd; text-align:center;"><b>Dear Admin,</b></td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: solid 1px #ddd; padding-bottom: 20px; background-color: #f3f3f3;"><div align="center">
                                       <table border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: #fff;">
                                                    <tr>
                                                      <td><table border="0" cellspacing="1" cellpadding="0" width="100%">
                                                         <tr>
                                                            <td valign="top"><p><strong>Name: </strong></p></td> 
                                                            <td valign="top"><p>'.$name.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Email: </strong></p></td> 
                                                            <td valign="top"><p>'.$email.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Mobile number: </strong></p></td> 
                                                            <td valign="top"><p>'.$mobileno.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Alternate number:</strong></p></td> 
                                                            <td valign="top"><p>'.$alternateno.'</p></td>
                                                         </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Shipping Street: </strong></p></td> 
                                                            <td valign="top"><p>'.$Shippingstreet.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Shipping City: </strong></p></td> 
                                                            <td valign="top"><p>'.$Shippingcity.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Shipping State: </strong></p></td> 
                                                            <td valign="top"><p>'.$Shippingstate.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Shipping pincode: </strong></p></td> 
                                                            <td valign="top"><p>'.$Shippingpincode.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Shipping Landmark: </strong></p></td> 
                                                            <td valign="top"><p>'.$Shippinglandmark.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Billing Street: </strong></p></td> 
                                                            <td valign="top"><p>'.$billing_street.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Billing City: </strong></p></td> 
                                                            <td valign="top"><p>'.$billing_city.'</p></td>
                                                         </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Billing State: </strong></p></td> 
                                                            <td valign="top"><p>'.$billing_state.'</p></td>
                                                         </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Billing Pincode: </strong></p></td> 
                                                            <td valign="top"><p>'.$billing_pincode.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Billing Landmark: </strong></p></td> 
                                                            <td valign="top"><p>'.$billing_landmark.'</p></td>
                                                         </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Collection Name: </strong></p></td> 
                                                            <td valign="top"><p>'.$serialized_item_names.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Collection Quantity </strong></p></td> 
                                                            <td valign="top"><p>'.$serialized_item_quantities.'</p></td>
                                                          </tr>
                                                         <tr>
                                                            <td valign="top"><p><strong>Collection Price: </strong></p></td> 
                                                            <td valign="top"><p>'.$serialized_item_prices.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Company Name: </strong></p></td> 
                                                            <td valign="top"><p>'.$companyname.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Gst Number </strong></p></td> 
                                                            <td valign="top"><p>'.$gstnumber.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Total price: </strong></p></td> 
                                                            <td valign="top"><p>'.$total_price.'</p></td>
                                                          </tr>
                                                            <tr>
                                                            <td valign="top"><p><strong>Payment Id: </strong></p></td> 
                                                            <td valign="top"><p>'.$payment_id.'</p></td>
                                                          </tr>
                                                          <tr>
                                                            <td valign="top"><p><strong>Created At: </strong></p></td> 
                                                            <td valign="top"><p>'.$added_on.'</p></td>
                                                          </tr>
                                                        </table></td>
                                                    </tr>
                                                  </table>
                                                </div></td>
                                            </tr>
                                          </table>
                                        </div>
                                        </body>
                                        </html>';

                                    // $mail = new PHPMailer(true);
                                    //   $mail->isSMTP();
                                    //   //$mail->SMTPDebug = 2;
                                    //   $mail->Host = 'mail.nanditapandey.com';
                                    //   $mail->Port = 587;
                                    //   $mail->SMTPAuth = true;
                                    //   $mail->Username = 'wordpress@nanditapandey.com';
                                    //   $mail->Password = 'j7hZ2Y@6c5YG';
                                    //   $mail->setFrom('wordpress@nanditapandey.com');
                                    //   $mail->addaddress('nk9165865@gmail.com');
                                    //   //$mail->addaddress('nisha@v2web.in');
                                    //     //$mail->addaddress('me@nanditapandey.com');
                                        
                                    // //   $mail->addaddress('author@nanditapandey.com');
                                    // //   $mail->addCC('info@nanditapandey.com');
                                        
                                    //     //Content
                                    //     $mail->isHTML(true);                                  
                                    //     $mail->Subject = "Buy The Book";
                                    //     $mail->Body    = $admin_html;
                                        
                                    
                                    //     $result_data = $mail->send();
                                    
                // $usermmail = $_POST["email"];
                 $mail = new PHPMailer;
                    $mail->smtpConnect(
                        array(
                            "ssl" => array(
                                "verify_peer" => false,
                                "verify_peer_name" => false,
                                "allow_self_signed" => true
                            )
                        )
                    );
                    $mail->isSMTP();                                
                    $mail->Host = 'mail.nanditapandey.com';
                    $mail->SMTPAuth = true;                               
                    $mail->Username ='wordpress@nanditapandey.com';                
                    $mail->Password = 'j7hZ2Y@6c5YG'; 
                    //$mail->SMTPSecure = 'ssl';   
                    $mail->Port = 25;                                   
                    $mail->setFrom("wordpress@nanditapandey.com","Buy The Book");
                    $mail->isHTML(true);
                    $mail->Subject = "Buy The Book";  
                    $mail->Body =  $admin_html;
                    $mail->AddAddress("nk9165865@gmail.com");
                    $mail->AddCC("nisha@v2web.in");
                    $mail->addReplyTo($email, 'Information');
                    $result_data =  $mail->Send();
                                   
                                        if($result_data){
                                        
                                           $user_html .='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                    <html xmlns="http://www.w3.org/1999/xhtml">
                                    <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                    <title>Buy The Book</title>
                                    </head>
                                    <body style="margin:0px;">
                                    <div style="background: #fff; border: solid 1px #ddd; max-width: 650px; width: 100%; margin: 0 auto; background-color: #fff;">
                                      <table width="100%" style="width:100%; border:none;">
                                            <tr >
                                            <td style="border-bottom:solid 1px #ddd; text-align:center;"><a href="https://nanditapandey.com/" target="_blank"> <img src="https://nanditapandey.com/wp-content/themes/storefront/assetss/images/logo.png" alt="Logo"  style="margin-bottom: 8px; height: 100px; color: #FFF;"/> </a></td>
                                        </tr>
                                    
                                        <tr>
                                        </tr>
                                        <tr>
                                          <td style="border-bottom: solid 1px #ddd; padding-bottom: 20px; background-color: #f3f3f3;"><div align="center">
                                              <table border="0" cellspacing="0" cellpadding="0" width="100%" style="background-color: #fff;">
                                                <tr>
                                                  <td>
                                                    <div style="padding-uper: 20px;" align="center" ><p><strong><h2>Your form has been submitted successfully.
                                                    </h2></strong></p></div>
                                                    
                                                    <div align="center" ><p><strong><h5>Your Payment Id is '.$payment_id.'
                                                    </h5></strong></p></div>
                                              
                                                    </td>
                                                </tr>
                                              </table>
                                            </div></td>
                                        </tr>
                                      </table>
                                    </div>
                                    </body>
                                    </html>';
                                        // $user_mail = new PHPMailer(true);
                                        // $user_mail->isSMTP();
                                        // $user_mail->Host = 'mail.nanditapandey.com';
                                        // $user_mail->Port = 587;
                                        // $user_mail->SMTPAuth = true;
                                        // $user_mail->Username = 'wordpress@nanditapandey.com';
                                        // $user_mail->Password = 'j7hZ2Y@6c5YG';
                                        // $user_mail->setFrom('wordpress@nanditapandey.com');
                                        // $user_mail->addaddress($email,$name);
                                        // $user_mail->isHTML(true);                                  
                                        // $user_mail->Subject = "Buy The Book";
                                        // $user_mail->Body = $user_html;
                                        // $send_data = $user_mail->send();
                                        
                        $user_mail = new PHPMailer;
                        $user_mail->smtpConnect(
                            array(
                                "ssl" => array(
                                    "verify_peer" => false,
                                    "verify_peer_name" => false,
                                    "allow_self_signed" => true
                                )
                            )
                        );
                        $user_mail->isSMTP();                                
                        $user_mail->Host = 'mail.nanditapandey.com';
                        $user_mail->SMTPAuth = true;                               
                        $user_mail->Username ='wordpress@nanditapandey.com';                
                        $user_mail->Password = 'j7hZ2Y@6c5YG'; 
                        // $user_mail->SMTPSecure = 'ssl';   
                        $user_mail->Port = 25;                                   
                        $user_mail->setFrom("wordpress@nanditapandey.com","Buy The Book");
                        $user_mail->isHTML(true);
                        $user_mail->Subject = "Buy The Book";  
                        $user_mail->Body =  $user_html;
                        $user_mail->AddAddress($email,$name);
                        // $user_mail->AddCC("lk6401110@gmail.com");
                        // $user_mail->addReplyTo($usermmail, 'Information');
                        $send_data =  $user_mail->Send();
                                        
                                        
                                        if($send_data){
                                        echo 'send successfully';
                                            ?>
                                            <!--<script type="text/javascript">-->
                                            <!--    window.location = "<?= site_url('/payment-done/');?>";-->
                                            <!--</script>-->
                                            <?php
                                            //  echo '<script>swal("Success", "Your data has been submitted successfully!", "success");</script>';
                                            //   echo '';
                                        }else{
                                            echo 'Something went wrong please try again';
                                        }
                                        } 
                                
                            }
}


?>
