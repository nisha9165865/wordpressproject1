<?php
get_header(); 


?>

 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
   <html lang="en">

<head>

<meta charset="utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1">

<title></title>


</head>

<body>


<section class="sec_padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="thank-you">
    <img src="https://nanditapandey.com/wp-content/uploads/2023/11/check.png">
    <h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU!</h1>
<p class="main-content__body" data-lead-id="main-content-body">Your form has been submitted successfully.</p>

</div>
            </div>
        </div>
    </div>
</section>

</body>

</html>
   
   
   
    <?php
get_footer();
?>