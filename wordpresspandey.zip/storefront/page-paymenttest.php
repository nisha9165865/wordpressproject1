<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the QR Code library
require 'vendor/autoload.php';

use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;

// Function to generate a UPI QR code
function generateUPIQRCode($upiId, $price) {
    // UPI link data
    $upiLink = "upi://pay?pa=$upiId&pn=Nandita&mc=&tid=&tr=&tn=&am=$price&cu=INR&url=";

    // QR code options
    $options = new QROptions([
        'outputType' => QRCode::OUTPUT_IMAGE_PNG,
        'eccLevel'   => QRCode::ECC_L,
        'scale'      => 4,
    ]);

    // Generate QR code
    $qrcode = new QRCode($options);
    $image  = $qrcode->render($upiLink);

    // Output image
    header('Content-Type: image/png');
    echo $image;
}

// Example: Generate a UPI QR code with a dynamic price of $10 and UPI ID "nandita.prismatic-2@okicici"
generateUPIQRCode('nandita.prismatic-2@okicici', 10);
?>
