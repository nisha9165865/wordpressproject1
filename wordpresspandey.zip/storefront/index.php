<?php
   /**
    * The main template file.
    *
    * This is the most generic template file in a WordPress theme
    * and one of the two required files for a theme (the other being style.css).
    * It is used to display a page when nothing more specific matches a query.
    * E.g., it puts together the home page when no home.php file exists.
    * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
    *
    * @package storefront
    */
   
   get_header(); ?>
<!-- Main Banner Area Start -->
<section class="main_banner_sec">
   <div class="icon_shape1">
      <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/bg/microphone_9456058.png" alt="">
   </div>
   <div class="container">
      <div class="row align-items-center g-4">
         <div class="col-md-8 col-lg-6 col-xl-6">
           <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $queries = new wp_Query($args);
                              foreach($queries->posts as $query){
                                  $post_id = $query->ID;
                                  $post_content = $query->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($post_id);?></h2>
                             </div>
                
                     <?php } ?>
                      
                     <!--<div class="item">-->
                     <!--   <h5>Any brand can be Charismatic and Inspiring - It all depends on "YOU" - Nandita Pandey</h5>-->
                     <!--</div>-->
                     <!--<div class="item">-->
                     <!--   <h5>Don't follow your Passion- Nurture it, Cultivate it - Nandita Pandey</h5>-->
                     <!--</div>-->
                     <!--<div class="item">-->
                     <!--   <h5>Branding is what people say about you, when you are not in the room - Nandita Pandey</h5>-->
                     <!--</div>-->
                     <!--<div class="item">-->
                     <!--   <h5>Good looking is in your genes, Looking Good is in your hands - Nandita Pandey</h5>-->
                     <!--</div>-->
                     <!--<div class="item">-->
                     <!--   <h5>You are responsible for creating Value, that didn't exist before you arrived in the room --->
                     <!--      Nandita Pandey</h5>-->
                    </div>
   
   
         </div>
         <div class="col-md-4 col-lg-6 col-xl-6">
            <div class="banner_figure wow fadeInUp">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Main Banner Area ENd -->



<!-- About Nandita Start -->
<section class="about_nandita sec_padding">
   <div class="container">
      <div class="row align-items-center flex-lg-row flex-column-reverse justify-content-end g-4">
         <?php
            $args = array(
            'post_type' => 'about_nandita_pandey', 
            'post_status' => 'publish',
            'order' => 'ASC',
            'posts_per_page' => -1
            );
              $queries = new wp_Query($args);
              foreach($queries->posts as $query){
                  $post_id = $query->ID;
                  $post_content = $query->post_content;
            ?>
              <div class="col-md-6 col-lg-6 col-xl-5">
            <div class="about_right wow bounceInRight">
               <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
            </div>
         </div>
         <div class="col-md-6 col-lg-6 col-xl-7">
            <div class="about_left wow bounceInUp">
               <div class="sec_title">
                  <h5>Being your own brand is all about reflecting the best of who you actually are</h5>
                  <h1 class="main_title"><?= get_the_title($post_id);?></h1>
               </div>
               <p><?= $content = get_post_field( 'post_content', $post_id);?></p>
               <a href="<?= site_url('/about-nandita/');?>" class="btn btn_theme mt-xl-4 mt-3">More About Nandita<i
                  class="bi bi-chevron-double-right ms-2"></i></a>
            </div>
         </div>
       
         <?php } ?>
      </div>
   </div>
</section>
<!-- About Nandita End -->

<!-- Book Selling Area Start -->
<section class="book_selling_sec sec_padding">
   <div class="container-fluid m-0 p-0">
      <div class="row align-items-center justify-content-center g-0 p-0 m-0">
         <?php
            $args = array(
            'post_type' => 'best_selling_book', 
            'post_status' => 'publish',
            'order' => 'ASC',
            'posts_per_page' => -1
            );
            
              $queries = new wp_Query($args);
                          
              foreach($queries->posts as $query){
                  $post_id = $query->ID;
                  $post_content = $query->post_content;
            ?>

         <div class="col-md-6 col-lg-8 col-xl-6">
            <div class="book_selling_word pe-lg-5 wow bounceInRight">
               <div class="sec_title">
                  <h2 class="main_title text-white"><?= get_the_title($post_id);?></h2>
               </div>
               <p><?= $content = get_post_field( 'post_content', $post_id);?></p>
               <a href="<?= site_url('/best-selling-book/')?>" class="btn btn_theme_2 mt-xl-4 mt-3">Read More <i
                  class="bi bi-chevron-double-right ms-2"></i></a>
            </div>
         </div>
                  <div class="col-md-6 col-lg-4 col-xl-3">
            <div class="book_selling_figure wow bounceIn">
               <img src="<?= get_the_post_thumbnail_url($post_id);?>" class="img-responsive" alt="">
            </div>
         </div>
         <?php } ?>
      </div>
   </div>
</section>
<!-- Book Selling Area End -->
<!-- DEI Area Start -->
<section class="dei_sec sec_padding">
   <div class="container">
      <div class="row align-items-center flex-md-row  flex-column-reverse g-4">
         <?php
            $args = array(
            'post_type' => 'dei', 
            'post_status' => 'publish',
            'order' => 'ASC',
            'posts_per_page' => -1
            );
            
              $queries = new wp_Query($args);
                          
              foreach($queries->posts as $query){
                  $post_id = $query->ID;
                  $post_content = $query->post_content;
            ?>
         <div class="col-md-4 col-lg-3 col-xl-3">
            <div class="dei_figure wow bounceIn">
               <img src="<?= get_the_post_thumbnail_url($post_id);?>" class="img-responsive" alt="">
            </div>
         </div>
         <div class="col-md-8 col-lg-9 col-xl-9">
            <div class="dei_word ps-xl-5 wow bounceInRight">
               <div class="sec_title">
                  <h2 class="main_title"><?= get_the_title($post_id);?></h2>
               </div>
               <p><?= $content = get_post_field( 'post_content', $post_id);?></p>
               
            </div>
         </div>
         <?php } ?>
      </div>
   </div>
</section>
<!-- DEI Area End -->



<!-- Latest Seat Area Start -->
<section class="latest_seat_sec sec_padding" >
   <div class="container">
      <div class="row align-items-center g-4">
         <div class="col-md-6 col-lg-6 col-xl-7">
            <div class="latest_seat_wraper me-xl-5 wow bounceInUp">
                
               <?php
                  $args = array(
                  'post_type' => 'don_t_miss', 
                  'post_status' => 'publish',
                  'order' => 'ASC',
                  'posts_per_page' => -1
                  );
                  
                    $queries = new wp_Query($args);
                                
                    foreach($queries->posts as $query){
                        $post_id = $query->ID;
                        $post_content = $query->post_content;
                  ?>
               <div class="latest_figure">
                  <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
                  <!-- <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/seats_1.png" alt=""> -->
               </div>
               <h2><?= get_the_title($post_id);?></h2>
               <!-- <h2><span>Don't Miss</span> The Latest Seats on The Workshop</h2>  -->
               <p><?= $content = get_post_field( 'post_content', $post_id);?></p>
               <!-- <p>Learn the skills you'll need to promote
                  and run a successful business.</p>    
                  -->
               <?php } ?>
            </div>
         </div>
         <div class="col-md-6 col-lg-6 col-xl-5">
            <div class="image_carousel owl-carousel owl-theme wow bounceInUp">
               <?php
                  $dont_miss_images = get_field('dont_miss_images',73);
                  foreach($dont_miss_images as $row_image){
                  ?>
               <div class="item">
                  <div class="carousel_figure">
                     <img src="<?= $row_image['images'];?>" alt="">
                  </div>
               </div>
               <?php		
                  }
                  ?>
               <!-- <div class="item">
                  <div class="carousel_figure">
                     <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/latest-1.jpg" alt="">
                  </div>
                  </div>
                  <div class="item">
                  <div class="carousel_figure">
                     <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/latest-2.jpg" alt="">
                  </div>
                  </div>
                  <div class="item">
                  <div class="carousel_figure">
                     <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/latest-3.jpg" alt="">
                  </div>
                  </div> -->
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Latest Seat Area End -->
<!-- Contact ME Area Start-->
<section class="contact_sec sec_padding">
   <div class="container">
      <div class="row g-4">
         <div class="col-md-12 col-lg-12 col-xl-12">
            <div class="sec_title">
               <h2 class="main_title text-center">Contact <span class="text-color-1">Me</span></h2>
            </div>
         </div>
         <div class="col-md-6 col-lg-6 col-xl-5">
            <div class="contact_left wow bounceIn">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/business-handshake.jpg" alt="">            
               <h3>Nandita Pandey</h3>
               <ul>
                  <li><a href="#"><i class="bi bi-geo-alt"></i> B2/11 Plaza Serene Acres Thoraipakkam, Chennai 600097</a></li>
                  <li><a href="mailto:me@nanditapandey.com"><i class="bi bi-envelope-at"></i> me@nanditapandey.com</a></li>
                  <li><a href="tel:+91 87545 79310"><i class="bi bi-telephone"></i>+91 87545 79310</a></li>
               </ul>
            </div>
         </div>
         <div class="col-md-6 col-lg-6 col-xl-7">
            <div class="contact_right ms-xl-5 wow bounceIn">
                
               <?php echo do_shortcode('[contact-form-7 id="1e45721" title="Contact With Me"]');?> 
               
               <!-- <form action="">
                  <div class="row g-4">
                     <div class="col-md-6">
                        <label for="" class="form-label">Name</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                     </div>
                     <div class="col-md-6">
                        <label for="" class="form-label">Phone Number</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                     </div>
                     <div class="col-md-12">
                        <label for="" class="form-label">Email Address</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                     </div>
                     <div class="col-md-12">
                        <label for="" class="form-label">Subject</label>
                        <input type="text" name="" id="" class="form-control" placeholder="">
                     </div>
                     <div class="col-md-12">
                        <label for="" class="form-label">Message</label>
                        <textarea type="text" name="" id="" rows="4" class="form-control" placeholder=""></textarea>
                     </div>
                     <div class="col-md-12 text-end">
                        <button type="button" class="btn btn_theme">Send Message <i class="fa-regular fa-paper-plane ms-2"></i></button>
                     </div>
                  </div>
                  </form> -->
                  
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Contact ME Area End -->

<?php
   get_footer();
   ?>