<?php
get_header(); ?>

  <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
   <!-- Breadcrumb Area ENd -->
   
   


  <section class="sec_padding">
      <div class="container">
           <div class="row g-4 blog_row">
               

                 <?php
                 $paged = !empty(get_query_var('paged')) ? get_query_var('paged') : 1;
                    $args = array(
                    'post_type' => 'post', 
                    'post_status' => 'publish',
                    'order' => 'desc',
                    'posts_per_page' => 9,
                    'paged'=>$paged
                    );
                  $queries = new wp_Query($args);
                              
                  foreach($queries->posts as $query){
                      $post_id = $query->ID;
                      $post_content = $query->post_content;
                ?>
                
                  <div class="col-md-6 col-sm-12 col-lg-4">
                
                <div class="blog_listing wow bounceIn">
                   <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="img...">            
                   <h5><?= get_the_title($post_id);?></h5>
                   <ul>
                      <?php $get_cats = get_the_category($post_id);?>
                         <li>
                             <?php
                            foreach($get_cats as $get_cat)
                            {
                                echo $get_cat->name.",";
                                // echo "<pre>";
                                // print_r($get_cat);
                            }
                             ?>
                         </li>
                        <li> <i class="bi bi-chat-dots"></i> <?php print_r(get_comment_count($post_id)['approved']);?> Comments</li>
                         <li> <i class="bi bi-calendar2-week"></i> <?= get_the_date('d/m/y',$post_id);?></li>
                       
                   </ul>
                   <p><?= get_field('short_description',$post_id);?></p>
                   <a href="<?= get_permalink($post_id);?>" class="btn btn_theme_2">Read More<i class="bi bi-chevron-double-right ms-2"></i></a>
                </div>
            </div>
             <?php } ?>
             
             
            
             <?php
            $total_pages = $queries->max_num_pages;
            if($total_pages > 1){
            ?>
            
             <nav aria-label="Page navigation example">
            <ul class="pagination">
               <li class="page-item"><a class="page-link paginav" href="<?= get_pagenum_link($paged - 1);?>"> << </a></li>
               <?php
                  for($i=1;$i<=$total_pages;$i++){
                  ?>
               <li class="page-item <?= !empty($i==$paged) ? 'active':'' ;?>"><a class="page-link" href="<?= get_pagenum_link($i);?>"><?= $i;?></a></li>
               <?php
                  }
                  ?>
               <li class="page-item"><a class="page-link paginav" href="<?= get_pagenum_link(!empty($paged + 1 < $total_pages)? $paged + 1 :'');?>"> >></a></li>
            </ul>
         </nav>
         <?php
            }
            ?>	

    </div>
      </div>
  </section>



<?php
get_footer();
?>