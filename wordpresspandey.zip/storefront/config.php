 <?php

    $servername = "localhost";
    $username = "nandiiqg_newnanUser";
    $password = "E)RdQ=!c6%cT";
    $dbname = "nandiiqg_newdbnan";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    ?>    