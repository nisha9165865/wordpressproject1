<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package storefront
 */

get_header(); ?>
   <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $queries = new wp_Query($args);
                              foreach($queries->posts as $query){
                                  $post_id = $query->ID;
                                  $post_content = $query->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($post_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>
   
   
                  </div>
                  </div>
                   <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                    <div class="breadcrumb_figure wow fadeInUp">
                        <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                    </div>
                    </div>
      </div>
       </div>
   </section>






	<section class="innerPage_sec sec_padding">
      <div class="container">

			<?php
			while ( have_posts() ) :
				the_post();

				do_action( 'storefront_page_before' );

				// get_template_part( 'content', 'page' );
				the_content();

				/**
				 * Functions hooked in to storefront_page_after action
				 *
				 * @hooked storefront_display_comments - 10
				 */
				do_action( 'storefront_page_after' );

			endwhile; // End of the loop.
			?>

		
	</div><!-- #primary -->
</section>




<?php
// do_action( 'storefront_sidebar' );
get_footer();
