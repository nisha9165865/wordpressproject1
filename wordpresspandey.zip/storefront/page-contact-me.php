<?php
get_header(); 
?>



 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->

   <section class="contact_sec sec_padding">
      <div class="container">
         <div class="row g-4">
            <div class="col-md-12 col-lg-12 col-xl-12">
               <div class="sec_title">
                  <h2 class="main_title text-center">Contact <span class="text-color-1"> Me</span></h2>
               </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-5">
               <div class="contact_left wow bounceIn" style="visibility: visible; animation-name: bounceIn;">
                  <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/business-handshake.jpg" alt="">
                  <h3>Nandita Pandey</h3>
                  <ul>
                     <li><a href="#"><i class="bi bi-geo-alt"></i> B2/11 Plaza Serene Acres Thoraipakkam, Chennai
                           600097</a></li>
                     <li><a href="mailto:me@nanditapandey.com"><i class="bi bi-envelope-at"></i> me@nanditapandey.com</a>
                     </li>
                     <li><a href="tel:+91 87545 79310"><i class="bi bi-telephone"></i>+91 87545 79310</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-7">
               <div class="contact_right ms-xl-5 wow bounceIn" style="visibility: visible; animation-name: bounceIn;">
                   
                   <?php echo do_shortcode('[contact-form-7 id="1e45721" title="Contact With Me"]');?>
                  <!--<form action="">-->
                  <!--   <div class="row g-4">-->
                  <!--      <div class="col-md-6">-->
                  <!--         <label for="" class="form-label">Name</label>-->
                  <!--         <input type="text" name="" id="" class="form-control" placeholder="">-->
                  <!--      </div>-->
                  <!--      <div class="col-md-6">-->
                  <!--         <label for="" class="form-label">Phone Number</label>-->
                  <!--         <input type="text" name="" id="" class="form-control" placeholder="">-->
                  <!--      </div>-->
                  <!--      <div class="col-md-12">-->
                  <!--         <label for="" class="form-label">Email Address</label>-->
                  <!--         <input type="text" name="" id="" class="form-control" placeholder="">-->
                  <!--      </div>-->
                  <!--      <div class="col-md-12">-->
                  <!--         <label for="" class="form-label">Subject</label>-->
                  <!--         <input type="text" name="" id="" class="form-control" placeholder="">-->
                  <!--      </div>-->
                  <!--      <div class="col-md-12">-->
                  <!--         <label for="" class="form-label">Message</label>-->
                  <!--         <textarea type="text" name="" id="" rows="4" class="form-control" placeholder=""></textarea>-->
                  <!--      </div>-->
                  <!--      <div class="col-md-12 text-end">-->
                  <!--         <button type="button" class="btn btn_theme">Send Message <i-->
                  <!--               class="fa-regular fa-paper-plane ms-2"></i></button>-->
                  <!--      </div>-->
                  <!--   </div>-->
                  <!--</form>-->
               </div>
            </div>
         </div>
      </div>
   </section>




<?php
get_footer();
?>