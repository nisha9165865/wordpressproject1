<?php
get_header(); ?>

   <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                        <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
   <section class="innerPage_sec sec_padding">
      <div class="container">
         <div class="row g-4">
            <div class="col-md-12 col-lg-12 col-xl-12">
               <div class="video_main wow bounceIn">
                    <iframe width="100%" class="videoframe" height="655px" src="<?php
                    $args = array(
                    'post_type' => 'video', 
                    'post_status' => 'publish',
                    'order' => 'ASC',
                    'posts_per_page' => 1
                    );
                  $queries = new wp_Query($args);
                              
                  foreach($queries->posts as  $query){
                      $post_id = $query->ID;
                      $post_content = $query->post_content;
                ?>
                <?= get_field('video_link',$post_id);?>
                <?php } ?>"
                        title="Brandify Take - 1 Rendezvous with Rajnish Bahl" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen></iframe>
               </div>
            </div>
          
                
                  <?php
                    $args = array(
                    'post_type' => 'video', 
                    'post_status' => 'publish',
                    'order' => 'ASC',
                    'posts_per_page' => -1
                    );
                  $queries = new wp_Query($args);
                              
                  foreach($queries->posts as  $query){
                      $post_id = $query->ID;
                      $post_content = $query->post_content;
                ?>
                
                 <div class="col-6 col-md-4 col-lg-4 col-xl-4"> 
                    <div class="video_tab">
                    <a class="videoUrl" dataUrl="<?= get_field('video_link',$post_id);?>" href="javascript:void(0)">
                        <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
                        <i class="bi bi-youtube"></i>
                    </a>
                    </div>
                     <p><?= get_the_title($post_id);?></p>
                     </div>
                    <?php } ?>
           
            
            <!--<div class="col-6 col-md-4 col-lg-4 col-xl-4">-->
            <!--    <div class="video_tab">-->
            <!--        <a href="#">-->
            <!--            <img src="https://i.ytimg.com/vi/pXYzA7eWEgA/hqdefault.jpg" alt="">-->
            <!--            <i class="bi bi-youtube"></i>-->
            <!--        </a>-->
            <!--    </div>-->
            <!--</div>-->
            <!--<div class="col-6 col-md-4 col-lg-4 col-xl-4">-->
            <!--    <div class="video_tab">-->
            <!--        <a href="#">-->
            <!--            <img src="https://i.ytimg.com/vi/cYNuuiKQphc/hqdefault.jpg" alt="">-->
            <!--            <i class="bi bi-youtube"></i>-->
            <!--        </a>-->
            <!--    </div>-->
            <!--</div>-->
         </div>
      </div>
   </section>
   

   
 <?php
get_footer();
?>

<script>
    $(document).ready(function(){
       $('.videoUrl').on('click', function(){
         // alert($(this).attr("dataUrl"));
         var videoLink = $(this).attr("dataUrl")+'?autoplay=1';
       //  alert(videoLink);
          $('.videoframe').attr('src',videoLink); 
       }); 
    });
</script>