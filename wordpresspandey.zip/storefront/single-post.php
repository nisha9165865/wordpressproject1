<?php
get_header(); 

global $post;
$post_id = $post->ID;
$post_content = $post->post_content;
$post_author = $post->post_author;

?>

 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <!--<nav aria-label="breadcrumb">-->
                  <!--   <ol class="breadcrumb">-->
                  <!--      <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>-->
                  <!--      <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>-->
                  <!--   </ol>-->
                  <!--</nav>-->
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
   
   
 <!-- innerPage Area Start -->

   <section class="innerPage_sec sec_padding">
      <div class="container">
         <div class="row g-4 mb-xl-5 mb-3">
            <div class="col-md-8 col-lg-8 col-xl-8">
                <div class="blog_page_left">
                        <div class="blog-header">
                            <div class="blog-thumbnail">
                                <a href="#" class="">
                                    <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="Blog Image" class="blog-img">
                                </a>
                            </div>
                            <h5 class="blog-event-date">
                                <!--<?= get_the_date('d/m/y',$post_id);?>-->
                                 <span class="month"><?= get_the_date('d/m/y',$post_id);?></span>
                                <!--<span class="year"><?= get_the_date('d/m/y',$post_id);?></span>-->
                            </h5>
                        </div>
                        <div class="blog-body">
                            <div class="blog-details">
                                <a href="#" class="author"><span><i class="far fa-user"></i></span> <?= get_the_author_meta('display_name',$post_author);?></a>
                                <a href="#" class="comment"><span><i class="far fa-calendar-alt"></i></span> <?php echo get_comments_number($post_id);?> Comments </a>
                            </div>
                            <h4 class="blog-title"><?= get_the_title($post_id);?></h4>
                            <div class="blog-content">
                               <?= $post_content;?>
                            </div>
                           
                            <?php
                            $args = array(
                                'post_id' => $post_id,
                                'status' => 'approve',
                                'number' => 5,
                            );
                            $comments_query = new WP_Comment_Query();
                            $comments       = $comments_query->query($args);
                            ?>
                            <div class="comment-list-box">
                                <h2 class="text-white">Latest Post Reviews</h2>
                            <?php
                            if($comments)
                            {
                            foreach ($comments as $key=>$row_comment) {
                            ?>
                                    <div class="thumblist">
                                        <ul class="p-0">
                                            <li>
                                                
                                                <div class="h4">
                                                    <span class="list-span"><?= ++$key ;?></span>
                                                    
                                                <div class="admin-box">
                                                    <a href="javascript:void(0);"><?= $row_comment->comment_author; ?></a>
                                                    <span><?= human_time_diff(
                                                                get_comment_date('U', $row_comment->comment_ID),
                                                                current_time('timestamp')
                                                            ) ?> ago</span>
                                                            <div class="wm-reviews-text">
                                                    <p><?= $row_comment->comment_content; ?></p>
                                                </div>
                                                </div>
                                                            </div>
                                                
                                            </li>
                                        </ul>
                                    </div>
                            <?php
                            }
                            }else{
                            ?>
                            <h6 class="">Post Comments Not Found.</h6>
                            <?php
                            }
                            ?>
                        </div>
                            <div>
                                <?php comment_form(); ?>
                            </div>
                            
                        </div>
                </div>                
            </div> 
            <div class="col-md-4 col-lg-4 col-xl-4">
                <div class="blog_page_right">
                    <aside>
                        <div class="blog_video mb-3 mb-lg-4">
                            <h5 class="widget_title">
                                Subscribe to our YouTube Channel
                            </h5>
                            <div class="video_embed video_frame">
                                <iframe width="560" height="315"
                                    src="https://www.youtube.com/embed/videoseries?list=PLBF0dPtoinoagp_1ZUzG0A52NDgw8QExA" frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""
                                    data-last-width="230" id="_dytid_7097"></iframe>
                            </div>
                        </div>
                        <div class="blog_recent mb-3 pt-3 mb-lg-4 pt-lg-4">
                            <h5 class="widget_title">
                                Recent posts
                            </h5>
                            <ul>
                                 <?php
                                            $args = array(
                                            'post_type' => 'post', 
                                            'post_status' => 'publish',
                                            'order' => 'disc',
                                            'posts_per_page' => 4,
                                            );
                                          $queries = new wp_Query($args);
                                                      
                                          foreach($queries->posts as $query){
                                              $post_id = $query->ID;
                                              $post_content = $query->post_content;
                                        ?>
                
                                
                                <li>
                                    <a href="<?= get_permalink($post_id);?>"><?= get_the_title($post_id);?></a>
                                    <span class="post-date"><?= get_the_date('d/m/y',$post_id);?></span>
                                </li>
                                <!--<li>-->
                                <!--    <a href="#">Top 5 Elements of a Successful-->
                                <!--        Brand!</a>-->
                                <!--    <span class="post-date">September 24, 2021</span>-->
                                <!--</li>-->
                                <!--<li>-->
                                <!--    <a href="#">What is Personal Branding?</a>-->
                                <!--    <span class="post-date">June 9, 2020</span>-->
                                <!--</li>-->
                                <?php } ?>
                                
                            </ul>
                        </div>

                        <div class="blog_recent mb-3 pt-3 mb-lg-4 pt-lg-4">
                            <h5 class="widget_title">
                                Categories
                            </h5>
                            <ul>
                                <li>
                                 <?php
                                    foreach((get_the_category()) as $category) {
                                    echo $category->cat_name . '';
                          
                                    } ?>
                                </li>
                                <!--<li>-->
                                <!--    <a href="#">Confidence</a> <strong>(26)</strong>-->
                                <!--</li>-->
                                <!--<li>-->
                                <!--    <a href="#">Personal Branding</a> <strong>(28)</strong>-->
                                <!--</li>-->
                                <!--<li>-->
                                <!--    <a href="#">Walking on the Glass Ceiling</a> <strong>(21)</strong>-->
                                <!--</li>-->
                                <!--<li>-->
                                <!--    <a href="#">Women Of Many Shades</a> <strong>(35)</strong>-->
                                <!--</li>-->
                            </ul>
                        </div> 
                        <div class="blog_search mb-3 pt-3 mb-lg-4 pt-lg-4">
                            <h5 class="widget_title">
                                Search
                            </h5>
                            <form action="">
                                <input type="search" name="" id="" class="form-control" placeholder="Search...">
                                <button type="button" class="btn btn_search"><i class="bi bi-search"></i></button>
                            </form>
                        </div>
                        <div class="blog_recent mb-3 pt-3 mb-lg-4 pt-lg-4">
                            <h5 class="widget_title">
                                Archives
                            </h5>
                            <ul>
                                <li><a href="#" class="inited">October <span>2021</span></a>(1)</li>
                                <li><a href="#" class="inited">September <span>2021</span></a>(1)</li>
                                <li><a href="#" class="inited">June <span>2020</span></a>(2)</li>
                                <li><a href="#" class="inited">April <span>2020</span></a>(2)</li>
                                <li><a href="#" class="inited">March <span>2020</span></a>(3)</li>
                                <li><a href="#" class="inited">September <span>2019</span></a>(1)</li>
                                <li><a href="#" class="inited">August <span>2019</span></a>(1)</li>
                                <li><a href="#" class="inited">July <span>2019</span></a>(2)</li>
                                <li><a href="#" class="inited">June <span>2019</span></a>(2)</li>
                                <li><a href="#" class="inited">May <span>2019</span></a>(4)</li>
                                <li><a href="#" class="inited">April <span>2019</span></a>(4)</li>
                                <li><a href="#" class="inited">March <span>2019</span></a>(4)</li>
                                <li><a href="#" class="inited">February <span>2019</span></a>(3)</li>
                                <li><a href="#" class="inited">January <span>2019</span></a>(3)</li>
                                <li><a href="#" class="inited">December <span>2018</span></a>(2)</li>
                                <li><a href="#" class="inited">November <span>2018</span></a>(6)</li>
                                <li><a href="#" class="inited">October <span>2018</span></a>(2)</li>
                                <li><a href="#" class="inited">September <span>2018</span></a>(1)</li>
                                <li><a href="#" class="inited">August <span>2018</span></a>(2)</li>
                                <li><a href="#" class="inited">July <span>2018</span></a>(2)</li>
                                <li><a href="#" class="inited">May <span>2018</span></a>(2)</li>
                                <li><a href="#" class="inited">February <span>2018</span></a>(3)</li>
                                <li><a href="#" class="inited">May <span>2016</span></a>(3)</li>
                                <li><a href="#" class="inited">April <span>2016</span></a>(3)</li>
                            </ul>
                        </div>
                    </aside>
                </div>
            </div>
               
         </div>
      </div>
   </section>
   <!-- innerPage Area End -->
   
   
   
   
     <?php
get_footer();
?> 
   
   
   