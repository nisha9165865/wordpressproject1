<?php
include 'config.php';
require_once('../../../wp-load.php');

// Check if a book was selected via AJAX
if (isset($_GET['bookname'])) {
    global $wpdb;
    
    // Get the selected book from the AJAX request
    $selected_book = sanitize_text_field($_GET['bookname']);

    // Query the database to retrieve the price based on the selected book
    $query = $wpdb->prepare("SELECT bookprice FROM booksdetails WHERE bookname = %s", $selected_book);
    $bookprice = $wpdb->get_var($query);

    if ($bookprice) {
        // Return the book price as a JSON response
        echo json_encode(array('bookprice' => $bookprice));
    } else {
        // If the book price was not found, return an error response
        echo json_encode(array('error' => 'Price not found'));
    }
} else {
    // Handle cases where 'book' is not set in the AJAX request
    echo json_encode(array('error' => 'Book not specified'));
}

?>