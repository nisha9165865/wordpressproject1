<?php
get_header(); 
include 'config.php';
?>
<style>
    .error
    {
        color:#862723 !important;
    }
</style>
 <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->
   
  <section class="sec_padding atoz_section">
   <div class="container">
      <div class="row g-5">
         <div class="col-lg-4 col-md-5">
            <div class="about_right wow bounceInRight">
               <img src="https://nanditapandey.com/wp-content/uploads/2023/10/Untitled-2.jpg" alt="">
            </div>
         </div>
         
         <div class="col-lg-8 col-md-7 form-div">
               <!--<h5>* If above 999, delivery free. Else 250</h5>-->
           <div class="contact_right ">
                <form method="POST" id="mainForm" name="mainForm" enctype="multipart/form-data">
               <div class="row g-4">
                  <div class="col-md-6">
                     <label for="name" class="form-label">Full Name<sup style="color: red;">*</sup></label>
                     <input type="text" name="name" id="name" class="form-control" placeholder="Full Name" required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Email Address<sup style="color: red;">*</sup></label>
                     <input type="email" name="email" id="" class="form-control" placeholder="Email"  required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Mobile Number<sup style="color: red;">*</sup></label>
                     <input type="text" name="mobileno" id="" class="form-control" placeholder="Mobile Number" required>
                  </div>
                  <div class="col-md-6">
                     <label for="" class="form-label">Alternate Number</label>
                     <input type="text" name="alternateno" id="" class="form-control" placeholder="Alternate Number">
                  </div>
                  
                  <div class="col-md-12">
                     <label for="" class="form-label">Shipping Address<sup style="color: red;">*</sup></label>
                  </div>
            <div class="col-md-12">
                      <div class="row g-4">
                      <div class="col-md-6">
                     <input type="text" name="Shippingstreet" id="" class="form-control" style="color:black;" placeholder="Street"  required>
                  </div>
                  <div class="col-md-6">
                     <input type="text" name="Shippingcity" id="" class="form-control" style="color:black;" placeholder="City"  required>
                  </div>
                  <div class="col-md-6">
                     <input type="text" name="Shippingstate" id="" class="form-control" style="color:black;" placeholder="State"  required>
                  </div>
                  <div class="col-md-6">
                      <input type="text" name="Shippingpincode" id="" class="form-control" style="color:black;" placeholder="Pincode" pattern="[0-9]{6}" maxlength="8" required>
                  </div>
                  <div class="col-md-12">
                      <input type="text" name="Shippinglandmark" id="" class="form-control" style="color:black;" placeholder="Landmark (Optional)">
                  </div>
                  </div>
            </div>
                  <div class="col-md-12">
                    <label for="" class="form-label">Billing Address  </label>
                    <input type="checkbox" id="sameAsShipping"> Different to Shipping Address
                    </div>
                  <div id="billingFields" class="col-md-12">
               <div class="row g-4">
                    <div class="col-md-6">
                    <input type="text" name="billing_street" id="billing_street" class="form-control" style="color:black;" placeholder="Street">
                </div>
                <div class="col-md-6">
                    <input type="text" name="billing_city" id="billing_city" class="form-control" style="color:black;" placeholder="City">
                </div>
                <div class="col-md-6">
                    <input type="text" name="billing_state" id="billing_state" class="form-control" style="color:black;" placeholder="State">
                </div>
                <div class="col-md-6">
                    <input type="text" name="billing_pincode" id="billing_pincode" class="form-control" style="color:black;" placeholder="Pincode">
                </div>
                <div class="col-md-12">
                    <input type="text" name="billing_landmark" id="billing_landmark" class="form-control" style="color:black;" placeholder="Landmark (Optional)">
                </div>
               </div>
            </div>
                  <!--<div class="col-md-4">-->
                  <!--   <label for="" class="form-label"> Book Selection:<sup style="color: red;">*</sup></label>-->
                  <!--   <select class="form-select" id="validationCustom04" required>-->
                  <!--     <option selected>--Select Book--</option>-->
                  <!--     <option  value="Book">Book</option>-->
                  <!--     <option value="Journal">Journal</option>-->
                  <!--     <option value="Cards">Cards</option>-->
                  <!--     <option value="Book + Cards">Book + Cards</option>-->
                  <!--     <option value="Book  + Journal">Book  + Journal</option>-->
                  <!--     <option value="Journal + Cards">Journal + Cards</option>-->
                  <!--     <option value="All Three">All Three</option>-->
                  <!--   </select>-->
                  <!--   <div class="invalid-feedback">-->
                  <!--     Please select a valid Book.-->
                  <!--   </div>-->
                  <!--</div>-->
                <!--  <div class="col-md-4">-->
                <!--   <label for="" class="form-label">Quantity</label>-->
                <!--   <input type="number" min="1" name="" id="" class="form-control" placeholder=""  required>-->
                <!--</div>-->
                <!--  <div class="col-md-4">-->
                <!--   <label for="" class="form-label"><i class="bi bi-currency-rupee"></i> Price</label>-->
                <!--   <input type="text" name="" id="" class="form-control" placeholder=""  required>-->
                <!--</div>-->
                
                    <!--start code -->
                        <?php
                $workshops = array();
                $read = "SELECT * FROM `booksdetails`";
                $result = mysqli_query($conn, $read);
            
                ?>
                    <table class="table table-bordered" id="item_table">
                      <tr>
                       <th valign="middle">Selection</th>
                       <th valign="middle">Quantity</th>
                       <th valign="middle"><i class="bi bi-currency-rupee"></i>Price</th>
                       <th valign="middle" class="text-center"><button type="button" name="add" class="btn btn-success btn-sm add">+</button></th>
                      </tr>
                      <tr>
                        <td><select class="form-select item_name" data-search="on" name="item_name[]" required> 
                        <option selected disabled>Select Book</option>
                        <?php foreach ($result as $workshop) { ?>
                       <option  value="<?= $workshop['bookname']; ?>"><?= $workshop['bookname']; ?></option>
                       <!--<option value="Journal">Journal</option>-->
                       <!--<option value="Cards">Cards</option>-->
                       <!--<option value="Book + Cards">Book + Cards</option>-->
                       <!--<option value="Book  + Journal">Book  + Journal</option>-->
                       <!--<option value="Journal + Cards">Journal + Cards</option>-->
                       <!--<option value="All Three">All Three</option>-->
                       <?php } ?>
                        </select></td>
                        <td><input type="number" min="1" name="item_quantity[]" class="form-control item_quantity" placeholder="Enter Quantity" required/></td>
                        <td><input type="text" name="item_price[]" class="form-control item_price" readonly/></td>
                        
                        <!--<td><textarea class="form-control form-control-sm item_remark" name="item_remark[]" id="item_remark" placeholder="Enter Remark" style="height: 47px; min-height: 3px;">test</textarea></td>-->
                        
                        <td width="80" class="text-center"><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</button></td>

                      </tr>
                     </table>
                     <table class="mt-0">
                         <tr>
                          <td style="">
                              <label for="coupon_code" class="form-label me-2">Apply Coupon Code:</label>
                              <input type="text" name="coupon_code" id="coupon_code">
                              <p class="coupon_error" id="coupon_error" style="color:red;display:none;">Coupon Code Invalid.</p>
                              </td>
                              
                              <td style="float:right">
                              <label for="validationServer03" class="form-label me-2">Total Price :</label>
                              <input type="text" name="total_price" id="total_price" readonly>
                              <input type="hidden" name="hidden_total_price" id="hidden_total_price" readonly></td>
                        </tr>
                        </table>
                       <div class="col-md-12 mt-0">
                    <label for="" class="form-label">Do You Want GST Invoice ?</label>
                    <input type="checkbox" id="gstdetail">
                    </div>
                    
                  <div id="gstfields" class="col-md-12">
               <div class="row g-4">
                    <div class="col-md-6">
                    <input type="text" name="companyname" id="companyname" class="form-control" style="color:black;" placeholder="Company Name">
                </div>
                <div class="col-md-6">
                    <input type="text" name="gstnumber" id="gstnumber" class="form-control" style="color:black;" placeholder="GST No.">
                </div>
               </div>
               
            </div>
            

           


<!-- Modal -->

                    <!--END code --!>
                  <!--<div class="col-md-12">-->
                  <!--   <label for="" class="form-label">Shipping Address</label>-->
                  <!--   <textarea type="text" name="" id="" rows="4" class="form-control" placeholder="" required></textarea>-->
                  <!--</div>-->
                  <div class="col-md-12 text-end">
                     <button type="submit" name="submit" class="btn btn_theme" id="submit">Submit<i
                           class="fa-regular fa-paper-plane ms-2"></i></button>
                  </div>
               </div>
                <!-- MODAL-->
            <div class="modal fade barcod-modal" id="myModal" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                    <div class="modal-body">
                        <!--<img src="<?= get_stylesheet_directory_uri();?>/assetss/images/qrcode.jpeg"alt="QR Code">-->
                        <h2>Scan to pay with any UPI app</h2>
                        <p>UPI Name :- Coach Nandita </p>
                        <div class="myqrcode"></div>
                        <div class="row g-4 m-2">
                            <div class="d-flex justify-content-around">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="nextButton" id="nextButton" class="btn btn-primary" >Confirm Payment</button>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
            </div>
            </form>


        
           </div>
         </div>
      </div>
   </div>
</section>
 
 
 <script>


    jQuery(document).ready(function () {
       
           $("#mainForm").validate({
            rules: {
                   name:{
                    required:true
                },
                mobileno:{
                    required:true,
                    minlength: 10,
                   maxlength: 12
                },
                email:{
                    required:true
                },
                Shippingstreet:{
                    required:true
                },
                Shippingcity:{
                    required:true
                },
                Shippingstate:{
                    required:true
                },
                Shippingpincode:{
                    required:true
                },
                item_name:{
                    required:true
                },
                item_price:{
                    required:true
                },
                item_quantity: {
                   required: true,
                },
            },
            // Specify validation error messages
            messages: {
                name: "Please provide a valid name.",
                Shippingstreet: {
                    required: "please provide a street",
                },
                Shippingcity: {
                    required: "please provide a city",
                },
                Shippingstate: {
                    required: "please provide a state",
                },
                Shippingpincode: {
                    required: "please provide a 6 digit pincode",
                },
                item_name: {
                    required: "please select collection",
                },
                item_quantity: {
                    required: "please enter quantity",
                },
                mobileno: {
                    required: "Please provide a phone number",
                    minlength: "Phone number must be min 10 characters long",
                    maxlength: "Phone number must not be more than 12 characters long"
                },
                email: {
                    required: "Please enter your email",
                    minlength: "Please enter a valid email address"
                },
            },
            errorPlacement: function(error, element) {
                error.insertAfter(element); // Display error messages below the respective input fields
            }
          });
          
          
  
        
        // $('#submit').click(function(){
        //     alert("okay");
        //     $('#myModal').modal('show');
        // });
        const modal = $('#myModal');
        const submitButton = $('#submit');

        submitButton.on('click', function () {
            modal.css('display', 'none'); // Show the modal
        });
        
        
    });
  </script>
 
 
 
 
 
 
<script>
    const sameAsShippingCheckbox = document.getElementById("sameAsShipping");
    const billingFields = document.getElementById("billingFields");

    sameAsShippingCheckbox.addEventListener("change", function () {
        if (this.checked) {
            billingFields.style.display = "block";
        } else {
            billingFields.style.display = "none";
        }
    });

    // Initialize the display based on the checkbox state
    if (sameAsShippingCheckbox.checked) {
        billingFields.style.display = "block";
    } else {
        billingFields.style.display = "none";
    }
</script>


<script>
    const gstdetailCheckbox = document.getElementById("gstdetail");
    const gstfields = document.getElementById("gstfields");

    gstdetail.addEventListener("change", function () {
        if (this.checked) {
            gstfields.style.display = "block";
        } else {
            gstfields.style.display = "none";
        }
    });

    // Initialize the display based on the checkbox state
    if (gstdetail.checked) {
        gstfields.style.display = "block";
    } else {
        gstfields.style.display = "none";
    }
</script>







<script>
jQuery(document).ready(function() {
    jQuery(document).on('click', '.add', function(){
        var html = '';
        html += '<tr>';
        html += '<td><select class="form-select item_name" data-search="on" name="item_name[]"> <option selected disabled>Select Book</option> <option value="Book">Book</option><option value="Journal">Journal</option> <option value="Cards">Cards</option><option value="Book + Cards">Book + Cards</option><option value="Book  + Journal">Book  + Journal</option><option value="Journal + Cards">Journal + Cards</option><option value="All Three">All Three</option></select></td>';
        html += '<td><input type="number" min="1" name="item_quantity[]" class="form-control item_quantity" placeholder="Enter Quantity" required/></td>';
        html += '<td><input type="text" class="form-control form-control-sm item_price" name="item_price[]" style="height: 47px; min-height: 47px;"></td>';
        html += '<td width="80" class="text-center"><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</em></button></td></tr>';
        $('#item_table').append(html);

        // Initialize Select2 on the newly added select element
        // $('.form-select').select2();
    });

    $(document).on('click', '.remove', function(){
        $(this).closest('tr').remove();
    });
    
    // $(document).on('click', '.add_price', function(){
    //     var html = '';
    //     html += '<tr>';
    //     html += '<td><select class="form-select" data-search="on" name="item_day_time[]"> <option value="1">1 Day</option> <option value="7">7 Days</option> <option value="15">15 Days</option> <option value="30">30 Days</option> </select></td>';
    //     html += '<td><input type="number" name="tiffine_price[]" class="form-control tiffine_price" placeholder="Enter Price" required/></td>';
    //     html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove"><em class="icon ni ni-trash"></em></button></td></tr>';
    //     $('#price_table').append(html);

    //     // Initialize Select2 on the newly added select element
    //     $('.form-select').select2();
    // });

    // $(document).on('click', '.remove_price', function(){
    //     $(this).closest('tr').remove();
    // });
    
});


jQuery(document).ready(function() {
  function updatePrice() {
    var total = 0; // Initialize the total price to zero

    // Loop through each row in the table
    $('table#item_table tr').each(function() {
      var quantity = parseInt($(this).find('.item_quantity').val());
      var priceField = $(this).find('.item_price');
      var selectedBook = $(this).find('.item_name').val();

      $.ajax({
        type: 'GET',
        url: '/wp-content/themes/storefront/get_book_price.php',
        data: {
          bookname: selectedBook
        },
        success: function(response) {
          var data = JSON.parse(response);
          if (data.bookprice) {
            var totalPrice = quantity * parseFloat(data.bookprice);
            priceField.val(totalPrice.toFixed(2));
            total += totalPrice; // Add the row's total to the overall total
            var is_price = $('#total_price').val(total.toFixed(2)); // Update the total price input field
            $('#hidden_total_price').val(total.toFixed(2))
            if(is_price)
            {
              var updated_code = $('#coupon_code').val(); 
              if(updated_code)
              {
                  getCouponPrice();
              }
            }
          } else {
            priceField.val('Price not found');
          }
        },
        error: function() {
          priceField.val('Error');
        }
      });
    });
  }

  // Initialize the quantity change event for the initial rows
  $(document).on('input', '.item_quantity', updatePrice);

  // Add event listener for adding rows
  jQuery(document).on('click', '.add', function() {
    var newRow = $('table#item_table tr:last')
      .clone()
      .find('.item_quantity')
      .unbind()
      .end()
      .removeClass('add');

    newRow.find('select.item_name').val('Select Book');
    newRow.find('input.item_quantity').val('');
    newRow.find('input.item_price').val('');

    newRow.find('.item_quantity').on('input', updatePrice);

   // $('table#item_table').append(newRow); // Append the new row to the table
  });

  // Add event listener for removing rows
  jQuery(document).on('click', '.remove', function() {
    $(this).closest('tr').remove();
    updatePrice(); // Recalculate prices after row removal
  });
    
  function getCouponPrice(){
      var code = "THANKYOU10";
            var user_code = $('#coupon_code').val();
            var total_amnt = $('#hidden_total_price').val();
            if(user_code){
                if(code === user_code)
                {
                    $("#coupon_error").hide();
                    
                    var discount_amnt = total_amnt*(10/100);
                    var final_amnt = total_amnt-discount_amnt;
                    if(total_amnt)
                    {
                        $('#total_price').val(final_amnt);
                    }else{
                        alert("amount not found");
                    }
                    
                }else{
                    $("#coupon_error").show();
                    $('#total_price').val(total_amnt);
                }
            }else{
                $("#coupon_error").hide();
            }
            
  }
  
  $('#coupon_code').change(function(){
        getCouponPrice();
    });
  
});


jQuery(document).ready(function () {
    const mainForm = document.getElementById('mainForm');
     mainForm.addEventListener('submit', function (e) {
        if ($("#mainForm").valid()) 
        {
           let valdata = $("#total_price").val();
           $.ajax({
              url:"<?= admin_url("admin-ajax.php")?>",
              method:"POST",
              data:{action:"get_totalval_ajax",valdata:valdata},
              success:function(res){
                  console.log(res);
                  
                  $(".myqrcode").html(res);
                //   $(".result-gallery").html(res);
              }
          });
           
        }
        e.preventDefault(); 
    });
    
});


jQuery(document).ready(function () {
     $(".item_name").on('change', function (e) {
        e.preventDefault(); 
        
        $(".item_quantity").val("");
        $(".item_price").val("");
        $("#total_price").val("");
        
        
    });
    
});


jQuery(document).ready(function () {
    const mainForm = document.getElementById('mainForm');
    const modal = $('#myModal');
    const submitButton = $('#submit');
    const nextButton = $('#nextButton');

    // Handle form submission
    mainForm.addEventListener('submit', function (e) {
        if ($("#mainForm").valid()) {
            // Form is valid, open the modal
            modal.modal('show');
        }
        e.preventDefault(); // Prevent the default form submission
    });

    // Handle the "Next" button click inside the modal
    nextButton.on('click', function () {
        // You can perform validation on the data if needed

        // Combine the data from the main form
        const formData = new FormData(mainForm);

        var ajaxurl = "https://nanditapandey.com/wp-content/themes/storefront/page-payment.php";

        // Send the data to the server using AJAX
        $.ajax({
            url: ajaxurl,
            data: formData,
            type: 'POST',
            contentType: false,
            cache: false,
            processData: false,
            success: function (response) {
                // Handle the response from the server
                $("#mainForm")[0].reset()
                window.location.href = "https://nanditapandey.com/thanku/";
            }
        });

        // Close the modal
        modal.modal('hide');
    });
});


    
  jQuery(document).ready(function () {
    // Select the checkbox element
    var $checkbox = $("#sameAsShipping");

    // Select the input fields
    var $billingStreet = $("#billing_street");
    var $billingCity = $("#billing_city");
    var $billingState = $("#billing_state");
    var $billingPincode = $("#billing_pincode");
    var $billingLandmark = $("#billing_landmark");

    // Function to toggle the 'required' attribute based on checkbox state
    function toggleRequired() {
      var isChecked = $checkbox.is(":checked");
      $billingStreet.prop("required", isChecked);
      $billingCity.prop("required", isChecked);
      $billingState.prop("required", isChecked);
      $billingPincode.prop("required", isChecked);
      $billingLandmark.prop("required", isChecked);
    }

    // Initially, set the 'required' attribute based on checkbox state
    toggleRequired();

    // Add a change event listener to the checkbox
    $checkbox.change(function () {
      toggleRequired();
    });
  });    
 
jQuery(document).ready(function () {
    // Select the checkbox element
    var $checkbox = $("#gstdetail");

    // Select the input fields
    var $companyName = $("#companyname");
    var $gstNumber = $("#gstnumber");

    // Function to toggle the 'required' attribute based on checkbox state
    function toggleRequired() {
      var isChecked = $checkbox.is(":checked");
      $companyName.prop("required", isChecked);
      $gstNumber.prop("required", isChecked);
    }

    // Initially, set the 'required' attribute based on checkbox state
    toggleRequired();

    // Add a change event listener to the checkbox
    $checkbox.change(function () {
      toggleRequired();
    });
  });    
    

</script>
 
 <?php
get_footer();
?>



<!--nisha code===================================================-->
<!--jQuery(document).ready(function(e) {-->

<!--       jQuery('#regForm').on('submit',function(e){-->

<!--          e.preventDefault();-->

<!--          var ajaxurl = "https://nanditapandey.com/wp-content/themes/storefront/page-thanku.php"-->

<!--          $.ajax({-->

<!--                    url:ajaxurl,-->

<!--                    data: new FormData(this),-->

<!--                    type:'POST', -->
<!--                    contentType: false,-->

<!--                    cache: false,-->

<!--                    processData:false,-->

<!--                    // beforeSend: function(){-->

<!--                    //   $("#nextBtn1").html('Please wait..');-->

<!--                    // $("#nextBtn1").attr('disabled', 'disabled');-->

<!--                    // },-->

<!--                    success: function(response){-->
<!--                        console.log(response);-->
<!--                        if(response){-->
<!--                            $('#myModal').modal('show');-->
<!--                        }-->

       

<!--             }-->

<!--                  }-->

<!--                );-->

<!--        });-->

<!-- });-->
<!--</script>-->