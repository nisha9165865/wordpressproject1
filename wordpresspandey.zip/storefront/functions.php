<?php
/**
 * Storefront engine room
 *
 * @package storefront
 */

/**
 * Assign the Storefront version to a var
 */
$theme              = wp_get_theme( 'storefront' );
$storefront_version = $theme['Version'];

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 980; /* pixels */
}

$storefront = (object) array(
	'version'    => $storefront_version,

	/**
	 * Initialize all the things.
	 */
	'main'       => require 'inc/class-storefront.php',
	'customizer' => require 'inc/customizer/class-storefront-customizer.php',
);

require 'inc/storefront-functions.php';
require 'inc/storefront-template-hooks.php';
require 'inc/storefront-template-functions.php';
require 'inc/wordpress-shims.php';

if ( class_exists( 'Jetpack' ) ) {
	$storefront->jetpack = require 'inc/jetpack/class-storefront-jetpack.php';
}

if ( storefront_is_woocommerce_activated() ) {
	$storefront->woocommerce            = require 'inc/woocommerce/class-storefront-woocommerce.php';
	$storefront->woocommerce_customizer = require 'inc/woocommerce/class-storefront-woocommerce-customizer.php';

	require 'inc/woocommerce/class-storefront-woocommerce-adjacent-products.php';

	require 'inc/woocommerce/storefront-woocommerce-template-hooks.php';
	require 'inc/woocommerce/storefront-woocommerce-template-functions.php';
	require 'inc/woocommerce/storefront-woocommerce-functions.php';
}

if ( is_admin() ) {
	$storefront->admin = require 'inc/admin/class-storefront-admin.php';

	require 'inc/admin/class-storefront-plugin-install.php';
}

/**
 * NUX
 * Only load if wp version is 4.7.3 or above because of this issue;
 * https://core.trac.wordpress.org/ticket/39610?cversion=1&cnum_hist=2
 */
if ( version_compare( get_bloginfo( 'version' ), '4.7.3', '>=' ) && ( is_admin() || is_customize_preview() ) ) {
	require 'inc/nux/class-storefront-nux-admin.php';
	require 'inc/nux/class-storefront-nux-guided-tour.php';
	require 'inc/nux/class-storefront-nux-starter-content.php';
}

/**
 * Note: Do not add any custom code here. Please use a custom plugin so that your customizations aren't lost during updates.
 * https://github.com/woocommerce/theme-customisations
 */

add_filter('wpcf7_autop_or_not', '__return_false');



// function display_database_records() {
//     global $wpdb;

//     $table_name = $wpdb->prefix . 'formdata'; // Replace 'your_table_name' with your actual table name.

//     $results = $wpdb->get_results("SELECT * FROM $table_name");

//     echo '<div class="wrap">';
//     echo '<h2>Database Table Records</h2>';
    
//     if (!empty($results)) {
//         echo '<table class="widefat">';
//         echo '<thead><tr><th>ID</th><th>Order Id</th><th>Name</th><th>Email</th><th>Mobileno</th><th>AlternateNo</th><th>Shippingstreet</th><th>Shippingcity</th><th>Shippingstate</th><th>Shippingpincode</th><th>Shippinglandmark</th><th>Billingstreet</th><th>Billingcity</th><th>Billingstate</th><th>Billingpincode</th><th>Billinglandmark</th><th>Item Name</th><th>Item Quantity</th><th>Item Price</th><th>Company name</th><th>Gst number</th><th>Total Price</th><th>Payment Status</th></tr></thead>';
//         echo '<tbody>';
        
//         foreach ($results as $row) {
//             echo '<tr>';
//             echo '<td>' . esc_html($row->id) . '</td>';
//             echo '<td>' . esc_html($row->order_id) . '</td>';
//             echo '<td>' . esc_html($row->name) . '</td>';
//             echo '<td>' . esc_html($row->email) . '</td>';
//             echo '<td>' . esc_html($row->mobileno) . '</td>';
//             echo '<td>' . esc_html($row->alternateno) . '</td>';
//             echo '<td>' . esc_html($row->Shippingstreet) . '</td>';
//             echo '<td>' . esc_html($row->Shippingcity) . '</td>';
//             echo '<td>' . esc_html($row->Shippingstate) . '</td>';
//             echo '<td>' . esc_html($row->Shippingpincode) . '</td>';
//             echo '<td>' . esc_html($row->Shippinglandmark) . '</td>';
//             echo '<td>' . esc_html($row->billing_street) . '</td>';
//             echo '<td>' . esc_html($row->billing_city) . '</td>';
//             echo '<td>' . esc_html($row->billing_state) . '</td>';
//             echo '<td>' . esc_html($row->billing_pincode) . '</td>';
//             echo '<td>' . esc_html($row->billing_landmark) . '</td>';
//             echo '<td>' . esc_html($row->item_name) . '</td>';
//             echo '<td>' . esc_html($row->item_quantity) . '</td>';
//             echo '<td>' . esc_html($row->item_price) . '</td>';
//             echo '<td>' . esc_html($row->companyname) . '</td>';
//             echo '<td>' . esc_html($row->gstnumber) . '</td>';
//             echo '<td>' . esc_html($row->total_price) . '</td>';
//             echo '<td>' . esc_html($row->payment_status) . '</td>';
//             echo '</tr>';
//         }

//         echo '</tbody></table>';
//     } else {
//         echo '<p>No records found.</p>';
//     }

//     echo '</div>';
// }

// add_action('admin_menu', 'custom_dashboard_menu');
// function custom_dashboard_menu() {
//     add_menu_page('Custom Dashboard Tables', 'Table Records', 'manage_options', 'custom-dashboard-tables', 'display_database_records');
// }


function display_database_records() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'formdata'; // Replace 'your_table_name' with your actual table name.
    
    $per_page = 10; // Number of records per page
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;

    // Check if the form is submitted to update the payment status
    if (isset($_POST['update_payment_status'])) {
        $order_id = $_POST['order_id'];

        // Get the current payment status
        $current_status = $wpdb->get_var($wpdb->prepare("SELECT payment_status FROM $table_name WHERE order_id = %s", $order_id));

        // Toggle the payment status
        $new_status = ($current_status === 'Not Paid') ? 'Paid' : 'Not Paid';

        // Update the payment status in the database
        $wpdb->update(
            $table_name,
            array('payment_status' => $new_status),
            array('order_id' => $order_id),
            array('%s'),
            array('%s')
        );
    }
    
    $total_records = $wpdb->get_var("SELECT COUNT(*) FROM $table_name ");
    $total_pages = ceil($total_records / $per_page);
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC LIMIT $per_page OFFSET $offset ");
    //$results = $wpdb->get_results("SELECT * FROM $table_name");
    $serial_number = ($current_page - 1) * $per_page + 1;

    echo '<div class="wrap">';
    echo '<h2>Database Table Records</h2>';
    // Export to Excel link
    echo '<a class="button" href="' . esc_url(admin_url('admin-post.php?action=export_excel')) . '">Export to Excel</a>';
    
    if (!empty($results)) {
        echo '<div class="table-responsive" style="overflow-x:auto;">';
        echo '<table class="widefat table">';
        echo '<thead><tr><th>ID</th><th>Order Id</th><th>Name</th><th>Email</th><th>Mobileno</th><th>AlternateNo</th><th>Shippingstreet</th><th>Shippingcity</th><th>Shippingstate</th><th>Shippingpincode</th><th>Shippinglandmark</th><th>Billingstreet</th><th>Billingcity</th><th>Billingstate</th><th>Billingpincode</th><th>Billinglandmark</th><th>Item Name</th><th>Item Quantity</th><th>Item Price</th><th>Company name</th><th>Gst number</th><th>Total Price</th><th>Payment id</th><th>Added On</th><th>Payment Status</th><th>Action</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($results as $row) {
            echo '<tr>';
            echo '<td>' . esc_html($serial_number++) . '</td>';
            echo '<td>' . esc_html($row->order_id) . '</td>';
            echo '<td>' . esc_html($row->name) . '</td>';
            echo '<td>' . esc_html($row->email) . '</td>';
            echo '<td>' . esc_html($row->mobileno) . '</td>';
            echo '<td>' . esc_html($row->alternateno) . '</td>';
            echo '<td>' . esc_html($row->Shippingstreet) . '</td>';
            echo '<td>' . esc_html($row->Shippingcity) . '</td>';
            echo '<td>' . esc_html($row->Shippingstate) . '</td>';
            echo '<td>' . esc_html($row->Shippingpincode) . '</td>';
            echo '<td>' . esc_html($row->Shippinglandmark) . '</td>';
            echo '<td>' . esc_html($row->billing_street) . '</td>';
            echo '<td>' . esc_html($row->billing_city) . '</td>';
            echo '<td>' . esc_html($row->billing_state) . '</td>';
            echo '<td>' . esc_html($row->billing_pincode) . '</td>';
            echo '<td>' . esc_html($row->billing_landmark) . '</td>';
            echo '<td>' . esc_html($row->item_name) . '</td>';
            echo '<td>' . esc_html($row->item_quantity) . '</td>';
            echo '<td>' . esc_html($row->item_price) . '</td>';
            echo '<td>' . esc_html($row->companyname) . '</td>';
            echo '<td>' . esc_html($row->gstnumber) . '</td>';
            echo '<td>' . esc_html($row->total_price) . '</td>';
            echo '<td>' . esc_html($row->payment_id) . '</td>';
            echo '<td>' . esc_html($row->added_on) . '</td>';
            echo '<td>' . esc_html($row->payment_status) . '</td>';
            echo '<td>';
            echo '<form method="post">';
            echo '<input type="hidden" name="order_id" value="' . esc_attr($row->order_id) . '">';
            echo '<input type="submit" name="update_payment_status" class="button" value="Payment Status">';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table></div>';
        echo '<style>
    .pagination {
        margin-top: 20px;
        clear: both;
        text-align: center;
    }
    .pagination a,
    .pagination span {
        padding: 6px 12px;
        margin: 0 3px;
        border: 1px solid #ddd;
        background-color: #f5f5f5;
        color: #333;
        text-decoration: none;
        display: inline-block;
        border-radius: 3px;
    }
    .pagination .current {
        background-color: #0073ea;
        color: #fff;
    }
    .pagination a:hover {
        background-color: #ddd;
    }
</style>';

echo '<div class="pagination">';
echo paginate_links(array(
    'base' => add_query_arg('paged', '%#%'),
    'format' => '',
    'prev_text' => __('&laquo; Previous'),
    'next_text' => __('Next &raquo;'),
    'total' => $total_pages,
    'current' => $current_page,
));
echo '</div>';

    } else {
        echo '<p>No records found.</p>';
    }

    echo '</div>';
}

add_action('admin_menu', 'custom_dashboard_menu');
function custom_dashboard_menu() {
    add_menu_page('Custom Dashboard Tables', 'Table Records', 'manage_options', 'custom-dashboard-tables', 'display_database_records');
}

add_action( 'wp_ajax_nopriv_get_totalval_ajax', 'get_totalval_ajax' );  
add_action( 'wp_ajax_get_totalval_ajax', 'get_totalval_ajax' );

function get_totalval_ajax(){
    
    if(!empty($_POST['valdata']))
    {
        include 'phpqrcode/qrlib.php';
        $totalvalue = $_POST['valdata'];
        $rootpath = get_stylesheet_directory_uri(); 
        $path = "/home1/nandiiqg/public_html/wp-content/themes/storefront/assetss/imagess/"; 
        $fileunique = uniqid().".png";
        $fullpath = "$rootpath/assetss/imagess/$fileunique"; 
        $file = $path.$fileunique;
        $ecc = 'L'; 
        $pixel_Size = 10; 
        $frame_Size = 10; 
        
             
        function generateQRCode($amount,$file,$ecc,$pixel_Size,$frame_Size){
             $upiId = 'nandita.prismatic-2@okicici';//'nandita.prismatic-2@okicici'; // Replace with the actual UPI ID
             
             // UPI payment URL
             $upiUrl = "upi://pay?pa={$upiId}&mc=&tid=&tr=&tn=&am={$amount}&cu=INR";
             
             // Generate QR code
             QRcode::png($upiUrl, $file, $ecc, 10, 10);
        }
        generateQRCode($totalvalue,$file,$ecc,$pixel_Size,$frame_Size);
        ?>
        <img src="<?php echo $fullpath;?>" style="width:300px;height:300px;">
        <?php        
    }
    wp_die();
    
}



use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

add_action('admin_post_export_excel', 'export_excel');

function export_excel() {
    if (!current_user_can('manage_options')) {
        wp_die('Access Denied');
    }

    require_once ABSPATH . 'wp-content/themes/storefront/vendor/autoload.php'; // Adjust the path if necessary

    global $wpdb;

    $table_name = $wpdb->prefix . 'formdata';

    $results = $wpdb->get_results("SELECT * FROM $table_name");

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Fetch field names from the first row of the results
    $fieldNames = array_keys(get_object_vars($results[0]));

    // Add header row with field names
    $columnIndex = 1;
    foreach ($fieldNames as $fieldName) {
        $sheet->setCellValueByColumnAndRow($columnIndex, 1, $fieldName);
        $sheet->getStyleByColumnAndRow($columnIndex, 1)->getFont()->setBold(true);
        $columnIndex++;
    }

    // Add data rows
    $data = array();

    foreach ($results as $row) {
        $data[] = get_object_vars($row);
    }

    $columnIndex = 1;
    $rowIndex = 2; // Start from the row after the header

    foreach ($data as $rowData) {
        foreach ($rowData as $value) {
            $sheet->setCellValueByColumnAndRow($columnIndex, $rowIndex, $value);
            $columnIndex++;
        }
        $columnIndex = 1;
        $rowIndex++;
    }

    $filename = 'table_data.xlsx'; // Change the extension to .xlsx
    $writer = new Xlsx($spreadsheet);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer->save('php://output');
    exit;
}



