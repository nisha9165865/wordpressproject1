<?php
get_header(); ?>

  <!-- Breadcrumb Area Start -->
    <section class="breadcrumb_sec" style="background: url(<?= get_stylesheet_directory_uri();?>/assetss/images/bg/1.png) no-repeat bottom center/ cover;">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-8 col-md-4 col-lg-4 col-xl-4">
               <div class="breadcrumb_wraper">
                  <nav aria-label="breadcrumb">
                     <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url('');?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?= get_the_title();?></li>
                     </ol>
                  </nav>
                  <h1 class="breadcrumb_title"><?= get_the_title();?></h1>
               </div>
            </div>
            <div class="col-4 col-md-6 col-lg-6 col-xl-6 d-none d-lg-block">
               <div class="breadcrumb_figure wow fadeInUp">
                  <div class="breadcrumb_slide owl-carousel owl-theme">
                      
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_banner_head', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $banners = new wp_Query($args);
                              foreach($banners->posts as $banner){
                                  $banner_id = $banner->ID;
                                  $banner_content = $banner->post_content;
                            ?>
                      
                               <div class="item">
                                <h2><?= get_the_title($banner_id);?></h2>
                             </div>
                
                     <?php } ?>
         
                     </div>

                  </div>
                  </div>
               <div class="col-4 col-md-2 col-lg-2 col-xl-2">
                <div class="breadcrumb_figure wow fadeInUp">
                    <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/nandita-1.png" alt="">
                </div>
                </div>
      </div>
       </div>
   </section>
 
   <!-- Breadcrumb Area ENd -->


   <!-- innerPage Area Start -->

   <section class="innerPage_sec sec_padding">
      <div class="container">
         <div class="row g-4 mb-xl-5 mb-3">
            
             
              <?php
                $args = array(
                'post_type' => 'about_me_skills', 
                'post_status' => 'publish',
                'order' => 'ASC',
                'posts_per_page' => -1
                );
                  $queries = new wp_Query($args);
                  foreach($queries->posts as $query){
                      $post_id = $query->ID;
                      $post_content = $query->post_content;
                ?>
                
                <div class="col-6 col-md-3 col-lg-3 col-xl-3">
               <div class="work_wraper wow fadeInUp">
                  <div class="work_icon">
                     <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
                  </div>
                  <h4><?= get_the_title($post_id);?></h4>
               </div>
            </div>
            
            <?php } ?>
                
           
         </div>
         <hr>
         <div class="row mt-xl-4 mt-3 flex-md-row flex-column-reverse g-4">
            <div class="col-md-6 col-lg-4 col-xl-5">
               <div class="m-about me-xl-4 me-lg-4 mb-4 ms-xl-4 wow fadeInLeft">
                  <div class="about-carousel owl-carousel owl-theme">
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_nandita_spe', 
                            'post_status' => 'publish',
                            'order' => 'desc',
                            'posts_per_page' => -1
                            );
                              $queries = new wp_Query($args);
                              foreach($queries->posts as $query){
                              $post_id = $query->ID;
                              $post_content = $query->post_content;
                        ?>
                          <div class="item">
                            <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
                            </div>
                        
                        <?php } ?>
                      
                 
                  </div>
               </div>
            </div>
            <div class="col-md-12 col-lg-12 col-xl-7">
               <div class="innerPage_word wow fadeInRight">
                  <p>Meet Nandita Pandey, a prominent Personal Leadership Transformation Coach and Professional Speaker, renowned for her expertise in Personal Branding. With a successful career in the Corporate World, Nandita transitioned into an inspiring Entrepreneur. Her journey has been marked by trailblazing accomplishments, impactful coaching, and empowering leaders to unlock their potential through the power of personal branding.</p> 
                  
                  <h5 class="text-color-1">Pioneering Initiatives</h5>
                  <p>Nandita's groundbreaking work has left a lasting impact on various fronts. As the first image consultant in Tamil Nadu, she has been a trendsetter in the domain of personal branding. She also holds the distinction of being the first Indian author of a book on Power Dressing, titled <strong>"Dressology - The Science of Power Dressing,"</strong> which has become a definitive guide in the industry. Her co-authorship in <strong>"Shifting Gears – A Winners Playbook to Pivot a Crisis"</strong> showcases her innovative contributions.</p>
                  <h5 class="text-color-1">Breaking Barriers</h5>
                  <p>Nandita's impact reaches beyond the professional realm. She actively mentors women, empowering them to overcome corporate challenges and shatter the 'Glass Ceiling.' Her commitment to gender diversity and inclusivity in leadership has made her an advocate for positive change within organizations. 
                    Nandita's passion for spreading her knowledge has led her to host <strong>India's only Hindi Podcast</strong> on Personal Branding - "Brandify." Through this platform, she shares valuable insights with leaders from diverse industries, leaving a profound impact on the personal branding landscape. She further moderates <strong>"Chronicles of Executive Presence"</strong> a panel discussion featuring Indian CXOs from around the world, fostering cross-industry learnings and leadership excellence.</p>                
               
                  
               </div>
            </div>
            <div class="col-md-12">
               <div class="innerPage_word wow bounceInUp">
                   <h5 class="text-color-1">Recognition and Accolades</h5>
                  <p>Nandita's exceptional contributions have not gone unnoticed. She has been honored with the prestigious <strong>'Super Women Achiever Award'</strong> and '<strong>Pride of Tamil Nadu Award'</strong> by the World HRD Congress. Her remarkable journey has been featured in <strong>Business World Magazine,</strong> further cementing her status as a thought leader in personal branding.</p>
                  <h5 class="text-color-1">Nandita's Career Trajectory</h5>
                  <p>Before venturing into entrepreneurship, Nandita proved her mettle in the Corporate World, working with esteemed global market leaders. This cross-cultural and diverse experience equipped her with the ability to effectively deliver global concepts customized to the Indian environment. Her innate talent for reshaping brand stories has earned her a reputation as a master of personal branding, capable of making individuals 'immortal' brands and expanding their playing field.</p>
                  <h5 class="text-color-1">My Why</h5>
                  <p>“We all get so busy caught up in what we do every day, that we don’t give the time to really reflect on why we do it. Until that day, it is not the “what” that motivates us to jump out of bed in the mornings, it is the “why.” It is not the “what” that drives us to give great service and become expert in our field, it is the “why.”</p>
                  <p>I grew up believing if you are good, you will shine, the world will realize your worth, they will wake up to your brilliance. You will be discovered, outside appearance in frivolous – intelligence and hard work matters. I had never understood that the visual aesthetic we present to others through our appearance and apparel was equally important.</p>
                  <p>I remember the night, after I was denied the opportunity for my excellence and hardwork, and the reason that came across the table from my management was no question about my competency but they doubted if I could represent them internationally for they believed I didn’t know how to carry and project myself. That night seemed to last for an eternity. I’d lie awake all night and stare out the window all day, in the desperate hope that it was not final, everything was normal, and life was fine, the way it always was.</p>
                  <p>That is the time when I realised, yes, the inside matters. But to get a chance your appearance matters, your branding matters. Once you get that chance, you can be a success because of your hard work, competence and intelligence. Upon diving deep into this, I slowly understood that image is everything, at least at first. Right or wrong, we live in an opinionated l world and that first impression goes a long way in shaping how people feel about you until you impress them to think otherwise. You can feel successful people when they walk into a room. Attention goes their way in an instant.</p>
                  <p>Creating an impactful 1st impression is just not about dressing up or looking good. It is a combination. It is combination of creating an image, your skillset and a building a brand around you. This is the combination that defines you and leaves a positive impression. It all lies in how well you project yourself. If you project a loser image, people will treat you like a loser right from the start. You want people to think you are a winner from Day One. Winners get hired. Winners get funding. Winners get promotions. Winners attract top talent. Winners invite opportunity.</p>
                  <p>The world today believes in this, and it is but intelligent that we also project ourselves – not aping but by being authentic and appropriate and consistent. Projecting our values in everything we do and say is the only way to build trust and this trust will build your brand.</p>
                    <p>So, I am basically helping people rediscover who they are, how they want to be remembered and then provide tools and techniques to project themselves that way to the world. They reach their goals – personal, professional, social and spiritual goals – faster and with less effort.</p>
                    
                    <h5 class="text-color-1">Notable Clients</h5>
                    <p>In a span of 11 years, Nandita has been instrumental in the success of more than 85 of India's most efficient CEOs, CXOs, entrepreneurs, and celebrities. Her expertise extends beyond Fortune 500 companies to startups, where her guidance has proven instrumental in achieving leadership excellence and business growth.</p>
                    <p>Nandita's client list for training programs includes esteemed organizations like  Mahindra & Mahindra, Optimas Global Solutions, Hyundai, Ultratech Cements, Larson & Toubro, Société Générale Bank, McKinsey, Nestle, Jubilant Audi, HSBC Bank, Medtronics,  Vodafone, Bajaj Finance,  and many others.</p>
               </div>
            </div>
         </div>
         
         <hr>
        <div class="row align-items-center justify-content-end g-4">
   <div class="col-md-12">
      <div class="sec_title mb-2">
         <h2 class="main_title"><span>Ventures</span></h2>
      </div>
   </div>
   <div class="col-md-6">
      <div class="row mb-4 g-4">
         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <a href="https://prismaticconsulting.in/" target="_blank">
                  <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/Prismatic_logo.png" alt="">
               </a>
            </div>
         </div>
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Founder and Chief Strategist</h5>
                  <h2 class="main_title fs-4">Prismatic Consulting</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Coaching, Mentoring, Executive Presence</p>
            </div>
         </div>
      </div>
      <div class="row mb-4 g-4">
         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/Intellimach_logo.png" alt="">
            </div>
         </div>
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Director</h5>
                  <h2 class="main_title fs-4">Intellimach Pvt. Ltd</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Smart Solutions for Home</p>
            </div>
         </div>
      </div>
      <div class="row g-4">
         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/SVPL_logo.png" alt="">
            </div>
         </div>
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Director</h5>
                  <h2 class="main_title fs-4">SVPL Pvt Ltd.</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Consulting and HR Services to MSMEs</p>
            </div>
         </div>
      </div>
   </div>


   <div class="col-md-6 Ventures-right">
      <div class="row flex-lg-row flex-column-reverse mb-4 g-4">
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Founder</h5>
                  <h2 class="main_title fs-4">Brandify</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Branding Strategy to Individuals, MSMEs, and Corporates, Design Services, Social Media Managemente</p>
            </div>
         </div>
         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <a href="<?= site_url('/brandify/');?>" target="_blank">
                  <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/Brandify_logo.png" alt="">
               </a>
            </div>
         </div>
      </div>
      <div class="row flex-lg-row flex-column-reverse mb-4 g-4">
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Co- founder</h5>
                  <h2 class="main_title fs-4">Global Pupils</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Ed-Tech Platform providing psychometric career guidance and e-courses to young adults.</p>
            </div>
         </div>

         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/Global_logo.png" alt="">
            </div>
         </div>
      </div>

      <div class="row flex-lg-row flex-column-reverse g-4">
         <div class="col-md-6 col-lg-8 col-xl-8">
            <div class="about_left ps-0 wow bounceInUp">
               <div class="sec_title mb-2">
                  <h5 class="fw-bold text-color-1">Director</h5>
                  <h2 class="main_title fs-4">Hypnautyx</h2>
               </div>
               <h5 class="text-color-1">Services</h5>
               <p>Content Strategy and Design Solutions</p>
            </div>
         </div>
         <div class="col-6 col-md-6 col-lg-4 col-xl-4">
            <div class="about_right wow bounceInRight">
               <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/hypnautyx_logo.png" alt="">
            </div>
         </div>
      </div>
   </div>
</div>
  
      </div>
   </section>
   <!-- innerPage Area End -->
      <!-- <section class="work_sec sec_padding">
         <div class="container">
           
         </div>
      </section> -->
      
      <section class="book_selling_sec sec_padding">
         <div class="container-fluid m-0 p-0">
            <div class="row align-items-center justify-content-end g-0 p-0 m-0">
               <div class="col-md-6 col-lg-6 col-xl-6">
                  <div class="book_selling_word wow bounceInUp">
                     <div class="sec_title">
                        <h5 class="text-light">How Coaching Can Benefit You</h5>
                        <h2 class="main_title text-white">Experience winning in your <span class="text-color-2 d-block">Profession & Business</span></h2>
                     </div>
                     <p>Branding is what people say about you, when you are not in the room. Let the world see a bright shining star in you.</p>
                     <p><span class="text-color-2">Are you determined</span> to make your life be what you want it to be!</p>
                     <a href="#" class="btn btn_theme_2 mt-xl-4 mt-3">Learn More<i
                           class="bi bi-chevron-double-right ms-2"></i></a>
                  </div>
               </div>
               <div class="col-md-6 col-lg-6 col-xl-4">
                  <div class="book_selling_figure wow bounceInRight">
                     <img src="<?= get_stylesheet_directory_uri();?>/assetss/images/home/5M4B9649-1024x683.jpg" alt="">
                  </div>
               </div>
            </div>
         </div>
      </section>
      
      <!-- Trusted By Start -->
      <section class="trusted_sec sec_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="sec_title">
                     <h2 class="main_title">Trusted <span class="text-color-1">By</span></h2>
                  </div>
                  <div class="trusted_carousel owl-carousel owl-theme">
                      
                        <?php
                            $args = array(
                            'post_type' => 'about_me_trusted_by', 
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => -1
                            );
                              $queries = new wp_Query($args);
                              foreach($queries->posts as $query){
                              $post_id = $query->ID;
                              $post_content = $query->post_content;
                        ?>
                      
                      
                      <div class="item">
                        <div class="row align-items-center">
                           <div class="col-md-4">
                              <div class="trusted_author">
                                 <div class="trusted_figure">
                                    <img src="<?= get_the_post_thumbnail_url($post_id);?>" alt="">
                                 </div>
                                 <h4> <?= get_the_title($post_id);?></h4>
                                 <p><?= $content = get_post_field( 'post_content', $post_id);?></p>
  
                              </div>
                           </div>
                           <div class="col-md-8">
                              <div class="trusted_word">
                                 <p><?= get_field('trusted_by_comment',$post_id);?></p>
                              </div>
                           </div>
                        </div>
                     </div>
                      
                      
                      <?php } ?>
               

                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Trusted By End -->
<?php
get_footer();