<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package storefront
 */

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
   <meta charset="<?php bloginfo( 'charset' ); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title><?php bloginfo( 'title' ); ?></title>
   <!--<title>Personal Branding Coach in Chennai | Personal Branding Coach in Erode | Executive presence in Delhi in Chennai |-->
   <!--Executive Presence in Delhi | nandita pandey</title>-->
   <meta name="description" content="">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   	<?php wp_head(); ?>
   <link type="text/css" href="<?= get_stylesheet_directory_uri();?>/assetss/css/style.css" rel="stylesheet">
   <link type="text/css" href="<?= get_stylesheet_directory_uri();?>/assetss/css/responsive.css" rel="stylesheet">
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
   <!--<link rel="icon" type="image/png" href="favicon.ico">-->
   <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
    <style>
        .error{
            color: red !important;
        }
    </style>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
   <!-- Header Start -->
   <header class="main_header">
      <div class="container">
         <a href ="<?= site_url('');?>" class="navbar-brand" href="index.php">
            <img class="logo img-fluid" src="<?= get_stylesheet_directory_uri();?>/assetss/images/logo.png" alt="logo">
         </a>
         <div class="main_menu">
            <div class="stellarnav">

		  <?php wp_nav_menu( array( 'container'=>true,'container_class' => true, 'theme_location' => 'primary' ) );?>
               <!-- <ul> -->
                  <!-- <li><a href="#">About Me</a></li>
                  <li><a href="#">Dressology Book</a></li>
                  <li><a href="#">Our Services</a>
                     <ul>
                        <li><a href="#">One To One Coaching</a></li>
                        <li><a href="#">Speaker Assignments</a></li>
                     </ul>
                  </li>                
                  <li><a href="#">Brandify</a></li>
                  <li><a href="#">Media</a>
                     <ul>
                        <li><a href="#">Videos</a></li>
                        <li><a href="#">Podcast</a></li>
                     </ul>
                  </li>
                  <li><a href="#">Blogs</a></li>                  
                  <li><a href="#">Testimonials</a></li>
                  <li><a href="#">Contact Me</a></li> -->
                <!-- </ul> -->
            </div>
         </div>
      </div>
   </header>
   <!-- Header End -->