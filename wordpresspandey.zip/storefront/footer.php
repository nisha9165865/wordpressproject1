<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package storefront
 */

?>
<!-- Footer Area Start -->
<footer class="main_footer">
      <div class="container">
         <div class="row g-4">
            <div class="col-md-12">
               <div class="footer_menu">

			<?php wp_nav_menu( array( 'container'=>true,'main_footer' => true, 'theme_location' => 'secondary' ) );?>
                  <!-- <ul>
                     <li><a href="#">About Us</a></li>
                     <li><a href="#">Dressology Book</a></li>
                     <li><a href="#">One To One Coaching</a></li>
                     <li><a href="#">Speaker Assignments</a></li>
                     <li><a href="#">Brandify</a></li>
                     <li><a href="#">Media</a></li>
                     <li><a href="#">Videos</a></li>
                     <li><a href="#">Podcast</a></li>
                     <li><a href="#">Blogs</a></li>
                     <li><a href="#">Testimonials</a></li>
                     <li><a href="#">Contact Us</a></li>
                  </ul>-->
               </div> 
			
            </div>
            <div class="col-lg-12 col-md-12">
               <ul class="brands">
                  <li><a href="https://www.facebook.com/coachnandita" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                  <li><a href="https://www.instagram.com/coachnandita/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                  <li><a href="https://www.youtube.com/@CoachNandita" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                  <li><a href="https://www.linkedin.com/in/coachnandita/" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>         
                  <li><a href="https://twitter.com/coachnandita" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
               </ul>
               <div class="copyright">
                  <p>Copyright © 2023 Nandita Pandey All rights reserved. | D & D by : <a href="https://v2web.in/" target="_blank">V2web</a></p>
               </div>
            </div>           
         </div>
      </div>
   </footer>

   <!-- Footer Area End -->

   <div class="progress-wrap active-progress">
      <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
         <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"></path>
      </svg>
   </div>

   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/jquery.3.7.0.min.js"></script>
   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/bootstrap.bundle.min.js"></script>
   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/wow.min.js"></script>
   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/owl.carousel.min.js"></script>
   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/stellarnav.js"></script>
   <script src="<?= get_stylesheet_directory_uri();?>/assetss/js/custom.js"></script>
   <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
   <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
   
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>



<?php wp_footer(); ?>

</body>
</html>
